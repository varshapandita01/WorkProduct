package com.cg.dao;

import java.util.List;

import org.springframework.beans.BeansException;
import org.springframework.context.ApplicationContext;

import com.cg.bean.AccountUser;
import com.cg.bean.Transaction;
import com.cg.exception.WalletException;


public interface SpringWalletDao {

	void setApplicationContext(ApplicationContext applicationContext) throws BeansException;

	void printTransaction(int Accno) throws WalletException;

	List<Transaction> getAll();

	void insertIntoTransaction(int Accno, String type, double amount, double balance);

	void fundTransfer(double amount, int accno, int Accno) throws ClassNotFoundException, WalletException;

	void withdrawMoney(double amount, int Accno) throws WalletException, ClassNotFoundException;

	void depositMoney(double amount, int accno) throws WalletException;

	double showBalance(int Accno) throws WalletException;

	boolean validateAccountNo(int Accno) throws WalletException;

	void createUser(AccountUser auU) throws WalletException;

}
