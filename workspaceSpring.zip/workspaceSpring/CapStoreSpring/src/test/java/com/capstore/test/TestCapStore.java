package com.capstore.test;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;

import com.capstore.bean.Merchant;
import com.capstore.dao.MerchantDao;
import com.capstore.service.MerchantService;
import com.capstore.service.MerchantServiceImpl;

public class TestCapStore {

	@Autowired
	private MerchantDao merchantDao;
	
private MerchantService service;

	@Before
	public void setUp() throws Exception {
		service = new MerchantServiceImpl();
	}
	@After
	public void tearDown() throws Exception {
		service = null;
	}

	@Test
	public void getAllEmployeesTest() {

		// given
		Merchant merchant = new Merchant();
		merchant.setId(1);
		merchant.setFirstName("Varsha");
		merchant.setLastName("Pandita");
		merchant.setEmail("varsha@gmail.com");
		merchant.setContact("9096785443");
		merchant.setPassword("123");
	//	service.saveMerchant(merchant);

		// when
	//	Merchant found = service.findById(merchant.getId());
	//	System.out.println(found);
		// then
	//	assertNotEquals(found.getId(), merchant.getId());

	}

	@Test
	public void getEmployeeByIdTest() {
		Merchant	merchant = new Merchant();
		merchant.setId(2);
		merchant.setFirstName("Varsha");
		merchant.setLastName("Pandita");
		merchant.setEmail("varsha@gmail.com");
		merchant.setContact("9096785443");
		merchant.setPassword("123");
		//when(service.findById(1)).thenReturn(new Merchant());

		//Merchant merchant1 = service.findById(1);
	//	assertEquals("Varsha", merchant1.getFirstName());

	}
private Merchant merchant;
	@Test
	public void addMerchantTest() {
		Merchant merchant = new Merchant();
		merchant.setId(111);
		merchant.setFirstName("Varsha");
		merchant.setLastName("Pandita");
		merchant.setEmail("varsha@gmail.com");
		merchant.setPassword("varpandi");
		merchant.setContact("abcdertyin");
		merchantDao.save(merchant);
		

	}
}
