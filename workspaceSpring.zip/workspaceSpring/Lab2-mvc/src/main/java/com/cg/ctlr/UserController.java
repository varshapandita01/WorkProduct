package com.cg.ctlr;

import java.util.ArrayList;
import java.util.List;
import java.util.NoSuchElementException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.entity.Login;
import com.cg.entity.Trainee;
import com.cg.service.TraineeService;

@Scope("session")
@Controller
public class UserController {

	// will inject dao from XML file
	@Autowired
	private TraineeService service;

	Trainee trainee;
	// Array list
	ArrayList<String> domainList;
	ArrayList<String> locationList;

	// Go to login page
	@RequestMapping("/")
	public String homePage(Model model) {
		model.addAttribute("login", new Login());
		return "login";
	}

	/**
	 * For Login
	 * 
	 * @param login
	 * @param m
	 * @return
	 */
	@RequestMapping("/checkLogin")
	public String checkLogin(Login login, Model m) {
		String invalid = "Enter correct Login  Details";
		m.addAttribute("invalid", invalid);
		String msg = "Login Successful";
		m.addAttribute("msg", msg);

		// Logic to validate userName and password against database
		if (login.getUserName().equalsIgnoreCase("varsha") && login.getPassword().equalsIgnoreCase("1234")) {

			return "trainee";
		} else {
			// System.out.println("dnhhgd");
			return "login";
		} // Logic to validate userName and password against database

	}

	/**
	 * Add Details of Trainee
	 * 
	 * @param model
	 * @return
	 */

	/*
	 * It saves object into database. The @ModelAttribute puts request data into
	 * model object. You need to mention RequestMethod.POST method because default
	 * request is GET
	 */
	// Function for add Trainee
	@RequestMapping(path = "add")
	public String save(@ModelAttribute("trainee") Trainee t, Model model) {

		service.addTrainee(t);
		model.addAttribute("login", new Login());
		String add = "Data added  Successfully";
		model.addAttribute("add", add);
		return "trainee";
		// will redirect to trainee request mapping
	}

	@RequestMapping("/addTrainee")
	public String addtrainee(Model model) {
		locationList = new ArrayList<String>();

		locationList.add("Chennai");
		locationList.add("Bangalore");
		locationList.add("Pune");
		locationList.add("Mumbai");

		domainList = new ArrayList<String>();

		domainList.add("Java");
		domainList.add("Struts");
		domainList.add("Spring");
		domainList.add("Hibernate");

		model.addAttribute("domainList", domainList);
		model.addAttribute("locationList", locationList);

		model.addAttribute("trainee", new Trainee());

		return "addTrainee";

	}

	// Function for delete Trainee
	@RequestMapping("/deleteTrainee")
	public String deleteTrainee(Model model) {
		model.addAttribute("trainee");
		return "deleteTrainee";

	}

	// search for delete trainee
	@RequestMapping("/searchDelete")
	public String searchTraineeDelete(Model model, int traineeId) {
		System.out.println(trainee);
		trainee = service.retrievebyId(traineeId);

		model.addAttribute("trainee", trainee);
		return "deleteTrainee";

	}

	// delete trainee finally
	@RequestMapping("delete")
	public String delete(Model model) {
		System.out.println(trainee);
		if (trainee != null) {
			service.deleteTrainee(trainee);
			String delete = "Data deleted  Successfully";
			model.addAttribute("delete", delete);

			return "trainee";
		} else {
			String error = "Provide valid details";
			model.addAttribute("error", error);
			return "deleteTrainee";
		}

	}

	// function for modify trainee
	@RequestMapping("/modifyTrainee")
	public String modifyTrainee(Model model) {
		locationList = new ArrayList<String>();

		locationList.add("Chennai");
		locationList.add("Bangalore");
		locationList.add("Pune");
		locationList.add("Mumbai");

		domainList = new ArrayList<String>();

		domainList.add("Java");
		domainList.add("Struts");
		domainList.add("Spring");
		domainList.add("Hibernate");

		model.addAttribute("domainList", domainList);
		model.addAttribute("locationList", locationList);

		model.addAttribute("trainee", new Trainee());

		return "modifyTrainee";

	}

	// search for modify trainee
	@RequestMapping("/searchModify")
	public String searchTraineeModify(Model model, int traineeId) {
		System.out.println(trainee);
		trainee = service.retrievebyId(traineeId);

		model.addAttribute("trainee", trainee);
		model.addAttribute("domainList", domainList);
		model.addAttribute("locationList", locationList);
		return "modifyTrainee";

	}

	// updated successfully
	@RequestMapping(path = "modify")
	public String modify1(Model model, @ModelAttribute("trainee") Trainee trainee) {
		System.out.println(trainee);
		// service.modifyTrainee(t, traineeId);
		service.addTrainee(trainee);
		String modify = "Data modified Successfully";
		model.addAttribute("modify", modify);
		model.addAttribute("domainList", domainList);
		model.addAttribute("locationList", locationList);

		model.addAttribute("trainee", trainee);
		return "trainee";
	}

	// function for retrieve
	@RequestMapping("/retrieveTrainee")
	public String retrieveTrainee(Model model) {
		model.addAttribute("trainee");
		return "retrieveTrainee";

	}

	// get by id
	@RequestMapping("/getbyId")
	public String getTrainee(int traineeId, Model model) {
		Trainee trainee = service.retrievebyId(traineeId);
		System.out.println(trainee);
		model.addAttribute("trainee", trainee);
		return "retrieveTrainee";

	}

	

	// function for retrieving list
	@GetMapping(path = "retrieveall")
	public String findAll(Model model) {
		model.addAttribute("trainee", new Trainee());
		Iterable<Trainee> list = service.retrieveAll();
		model.addAttribute("lists", list);
		return "retrieveAllTrainee";

	}

}