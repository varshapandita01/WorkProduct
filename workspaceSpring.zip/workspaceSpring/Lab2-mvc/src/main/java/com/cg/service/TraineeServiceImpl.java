package com.cg.service;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.cg.entity.Trainee;
import com.cg.repo.TraineeRepo;

@Repository
@Transactional
public class TraineeServiceImpl implements TraineeService {

	@Autowired
	private TraineeRepo repo;

	@Override
	public void addTrainee(Trainee t) {
		repo.save(t);
	}

	@Override
	public String deleteTrainee(Trainee trainee) {
		repo.delete(trainee);
		return "Album List Deleted Successfully";
	}

	@Override
	public Iterable<Trainee> retrieveAll() {

		return repo.findAll();
	}

	@Override
	public Trainee retrievebyId(int id) {
		return repo.findById(id).get();

	}

	@Override
	public Trainee modifyTrainee(Trainee t, int id) {
		t.setTraineeId(id);
		repo.save(t);
		return t;
	}
}
