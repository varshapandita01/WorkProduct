package com.cg.rest;

import java.util.List;

import javax.websocket.server.PathParam;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cg.entity.Product;
import com.cg.service.ProductService;

@RestController
public class HelloController {

	@Autowired
	private ProductService service;

	@GetMapping("/hola")
	public String sayHello() {
		return "Hello  ,Welcome to Spring Boot";

	}

	@PostMapping("/add")
	public String creta(@RequestParam("name") String name, @RequestParam("price") double price) {
		Product p = new Product();
		p.setName(name);
		p.setPrice(price);
		service.saveProduct(p);
		return "Product Saved";

	}

	@GetMapping(name = "/product", produces = "application/json")
	public Product getProduct(@RequestParam("id") int id) {
		Product p = service.getProduct(id);
		return p;
	}

	@GetMapping(path = "/productAll", produces = "application/json")
	public List<Product> getAllProduct() {

		return service.getAll();
	}

	@PutMapping("/updateAll/{id}")
	public String updateProduct(@PathVariable(value = "id") int id, Product p) {

		service.updateProduct(p);
		return "Data Updated Successfully";
	}

	@DeleteMapping(path = "/deleteProduct")
	public String deleteProduct(@RequestParam("id") int id) {

		return service.deleteProduct(id);
	}

}
