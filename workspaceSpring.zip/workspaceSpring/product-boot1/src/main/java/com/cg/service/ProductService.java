package com.cg.service;

import java.util.List;

import com.cg.entity.Product;

public interface ProductService {
	
	public void saveProduct(Product p);
	public Product getProduct(int id);
	public void updateProduct(Product p);
	public String deleteProduct(int id);
	List<Product> getAll();
}
