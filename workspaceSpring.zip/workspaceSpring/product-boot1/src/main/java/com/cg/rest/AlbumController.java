package com.cg.rest;

public class AlbumController {

}
