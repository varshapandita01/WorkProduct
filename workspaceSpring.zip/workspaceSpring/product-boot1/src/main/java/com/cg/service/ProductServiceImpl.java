package com.cg.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.entity.Product;
import com.cg.repo.ProductRepo;

@Service
public class ProductServiceImpl implements ProductService {
	@Autowired
	ProductRepo  repo;
	@Override
	public void saveProduct(Product p) {
		repo.save(p);
	}

	@Override
	public Product getProduct(int id) {
		Product p=new Product();
		p = repo.findById(id).get();
		return p;
		
	}
	
	@Override
	public List<Product> getAll(){
		List<Product>prodlist=(List<Product>) repo.findAll();
		return prodlist;
	}

	@Override
	public void updateProduct(Product p) {
		repo.save(p);
		
	}

	@Override
	@Transactional
	public String deleteProduct(int id) {
		 repo.deleteById(id);
		return "Data deleted Successfully";
	}
}
