package com.cg.repo;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.cg.entity.Product;

@Repository

public class ProductRepoImpl implements ProductRepo {
	@PersistenceContext(unitName = "SpringJPA")
	private EntityManager em;

	@Transactional(propagation = Propagation.REQUIRED) // CMT: if existing not found it start new transaction
	public Product saveProduct(Product p) {
	
		em.persist(p);
		return p;

	}

	@Transactional(propagation = Propagation.SUPPORTS) // CMT:if not found its ok
	public Product get(int id) {
		return em.find(Product.class, id);

	}

	@Transactional
	public List<Product> getAll() {
		return em.createQuery("from Product").getResultList();
	}

}
