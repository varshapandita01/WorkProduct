package com.cg.rest;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.cg.entity.Product;

import com.cg.repo.ProductRepo;

@RestController
public class ProductController {

	@Autowired
	private ProductRepo repo;

	@GetMapping("/Product")
	public ModelAndView homePage(Model mod) {
		return new ModelAndView("product", "product", new Product());

	}

	@PostMapping("/addProduct")
	public Product addProduct(@ModelAttribute("product") Product product, Model mod) {
		product = repo.saveProduct(product);
		mod.addAttribute("result", "Added Successfully");
		return product;

	}

	@GetMapping(path = "/productsList", produces = "application/json")
	public List<Product> showAllProduct() {
		return repo.getAll();
	}

	@ExceptionHandler({ java.sql.SQLIntegrityConstraintViolationException.class,
			org.springframework.web.util.NestedServletException.class,
			org.springframework.orm.jpa.JpaSystemException.class, javax.persistence.PersistenceException.class,
			org.hibernate.exception.ConstraintViolationException.class })

	public ModelAndView showError(Model mod) {
		return new ModelAndView("error");

	}

}