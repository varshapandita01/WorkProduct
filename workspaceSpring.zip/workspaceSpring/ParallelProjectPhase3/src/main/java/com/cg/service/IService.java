package com.cg.service;

import java.sql.SQLException;
import java.util.List;

import com.cg.bean.Customer;
import com.cg.bean.TransactionEntries;
import com.cg.exception.*;


public interface IService {
	
	String NamePattern = "[a-zA-Z]{2,20}";
	String mobilePattern = "(0/91)?[7-9][0-9]{9}";
	String emailPattern = "^[A-Za-z0-9+_.-]+@(.+)$";
	String userNamePattern = "[a-zA-Z0-9.\\-_]{3,}";
	String passwordPattern = "(?=^.{8,}$)((?=.*\\d)|(?=.*\\W+))(?![.\n])(?=.*[A-Z])(?=.*[a-z]).*$";

	// String passwordPattern =
	boolean validateName(String name);

	boolean validateMobile(String mobile);

	boolean validateEmail(String email);
	

	List<TransactionEntries> printTransaction(long mobNo);

	public String fundTransfer(Customer customer1, Customer customer2, double amount) throws InsuffiecientBalanceException, SenderReceiverSameException;

	Customer login(long mobNo, String password);

	double showBalance(Customer customer) throws SQLException;

	String withdraw(double amount, Customer customer) throws InsuffiecientBalanceException;

	boolean validatePassword(String password);

	Customer insertCustomer(Customer customer) throws CustomerExists;

	Customer checkCredentials(long mobNo) throws SQLException;
	
	String deposit(double amount, Customer customer) throws CustomerNotFoundException;
}
