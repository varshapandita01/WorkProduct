package com.cg.exception;

public class SenderReceiverSameException extends Exception {

	public SenderReceiverSameException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public SenderReceiverSameException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	

}
