package com.cg.dao;

import java.sql.SQLException;
import java.util.List;

import com.cg.bean.Customer;
import com.cg.bean.TransactionEntries;
import com.cg.exception.*;


public interface IDao {
	String withdraw(double amount, Customer customer) throws InsuffiecientBalanceException;

	String deposit(double amount, Customer customer) throws CustomerNotFoundException;

	String fundTransfer(double amount, Customer cust1, Customer cust2)
			throws InsuffiecientBalanceException, SenderReceiverSameException;

	Customer insertCustomer(Customer customer) throws CustomerExists;

	Customer checkCredentials(long mobileNo) throws SQLException;

	public double showBalance(Customer customer) throws SQLException;

	public Customer login(long mobNo, String password) throws CustomerNotFoundException;// throws
																						// CustomerNotFoundException;

	public List<TransactionEntries> printTransaction(long mobNo);
	// boolean login(String mobNo);



}
