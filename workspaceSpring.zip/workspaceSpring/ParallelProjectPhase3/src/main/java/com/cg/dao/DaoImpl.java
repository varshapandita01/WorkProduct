package com.cg.dao;

import java.sql.SQLException;
import java.time.LocalDateTime;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.cg.bean.Customer;
import com.cg.bean.TransactionEntries;
import com.cg.exception.CustomerExists;
import com.cg.exception.CustomerNotFoundException;
import com.cg.exception.InsuffiecientBalanceException;
import com.cg.exception.SenderReceiverSameException;

@Repository("dao")
@Transactional
public class DaoImpl implements IDao,ApplicationContextAware {
	@PersistenceContext(unitName="SpringJPA")	
	EntityManager em;
	
	@Autowired
	private ApplicationContext context;

	
	@Transactional(propagation = Propagation.REQUIRES_NEW)
	public String withdraw(double amount, Customer customer) throws InsuffiecientBalanceException {
		if (customer.getBalance() > amount) {
			customer.setBalance(customer.getBalance() - amount);
			
			TransactionEntries tran = (TransactionEntries)context.getBean(TransactionEntries.class);
			tran.setAmount(amount);
			tran.setMobNo(customer.getMobileNo());
			tran.setBalance(customer.getBalance());
			tran.setType("DR");
			em.merge(customer);
			
			em.persist(tran);

			return "Rs." + amount + " debited from account " + customer.getCustId() + " on " + LocalDateTime.now()
					+ "\nNew Balance is Rs." + customer.getBalance();
		} else {
			throw new InsuffiecientBalanceException("You Have Insufficient Fund.");

		}

	}

	
	@Transactional(propagation = Propagation.REQUIRES_NEW)
	public String deposit(double amount, Customer customer) throws CustomerNotFoundException {
		customer.setBalance(customer.getBalance() + amount);
		
		TransactionEntries tran = (TransactionEntries)context.getBean(TransactionEntries.class);
		tran.setType("CR");
		tran.setMobNo(customer.getMobileNo());
		tran.setAmount(amount);
		tran.setBalance(customer.getBalance());
		em.merge(customer);
		em.persist(tran);

		return "Rs." + amount + " credited on account " + customer.getCustId() + " on " + LocalDateTime.now()
				+ "\nNew Balance is Rs." + customer.getBalance();
	}

	
	@Transactional(propagation = Propagation.REQUIRES_NEW)
	public String fundTransfer(double amount, Customer cust1, Customer cust2)
			throws InsuffiecientBalanceException, SenderReceiverSameException {
		withdraw(amount, cust1);
		try {
			deposit(amount, cust2);
		} catch (CustomerNotFoundException e) {
			e.printStackTrace();
		}

		return null;
	}

	
	@Transactional(propagation = Propagation.REQUIRES_NEW)
	public Customer insertCustomer(Customer customer) throws CustomerExists {
		double custId = Math.floor(Math.random() * 100);
		customer.setCustId(custId);
		em.persist(customer);

		return customer;
	}

	
	@Transactional(propagation = Propagation.REQUIRES_NEW)
	public Customer checkCredentials(long mobileNo) throws SQLException {

		Customer cust = em.find(Customer.class, mobileNo);
		return cust;
	}

	
	@Transactional(propagation = Propagation.REQUIRES_NEW)
	public double showBalance(Customer customer) throws SQLException {
		double bal = em.find(Customer.class, customer.getMobileNo()).getBalance();
		return bal;
	}

	
	@Transactional(propagation = Propagation.REQUIRES_NEW)
	public Customer login(long mobNo, String password) throws CustomerNotFoundException {

		Customer cust = em.find(Customer.class, mobNo);

		if (cust.getPassword().equals(password)) {
			return cust;
		} else {
			throw new CustomerNotFoundException("Customer does not exist");
		}

	}

	
	@Transactional(propagation = Propagation.REQUIRES_NEW)
	public List<TransactionEntries> printTransaction(long mobNo) {
		String qStr = "SELECT tran FROM TransactionEntries tran WHERE tran.mobNo=:mobNo";
		TypedQuery<TransactionEntries> query = em
				.createQuery(qStr, TransactionEntries.class);
		List<TransactionEntries> resultList = query.setParameter("mobNo", mobNo)
				.getResultList();
		
		return resultList ;
	}

	
	public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
		// TODO Auto-generated method stub
		
	}
	
}
