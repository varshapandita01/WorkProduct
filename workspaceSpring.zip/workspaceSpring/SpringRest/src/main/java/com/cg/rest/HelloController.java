package com.cg.rest;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cg.entity.Product;

@RestController
public class HelloController {

	@GetMapping("/hola/{name}")
	public String sayHello(@PathVariable String name) {
		return "Hello " + name + " ,Welcome to Spring Boot";

	}

	@GetMapping("/bye")
	public String sayGoodBye(@RequestParam("name") String name) {

		return "Bye" + name + ",Visit again!";
	}
	/*@GetMapping("/hi")
	public Product get(Product prod) {
		return prod;
		
	}*/
}
