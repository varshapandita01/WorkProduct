package com.capgemini.testCase;



import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import com.capgemini.test.bean.CustomerInfo;
import com.capgemini.xyz.dao.DaoAccountClass;
import com.capgemini.xyz.exception.RecordNotFoundException;

public class ValidateUserTest {
	DaoAccountClass daoA = null;

	@Before
	public void setUp() throws Exception {
		daoA = new DaoAccountClass();
	}

	@After
	public void tearDown() throws Exception {
		daoA = null;
	}

	@Test
	public void testValidCustomerDetails() {
		CustomerInfo cust = new CustomerInfo();
		CustomerInfo requestCust = new CustomerInfo();
		cust.setAddress("Mumbai");
		cust.setAge(24);
		cust.setName("Varsha");
		cust.setEmail("vars@gmnss.com");
		daoA.createAccount(cust);
		int id = cust.getAccountNumber();
		try {
			requestCust = daoA.find(id);
			Assert.assertNotNull(requestCust);
			System.out.println("Test Case Passed");

		} catch (RecordNotFoundException e) {
			System.out.println(e);
		}
	}

	@Test
	public void testInValidCustomerDetails() {
		CustomerInfo cust = new CustomerInfo();
		CustomerInfo requestCust = new CustomerInfo();
		cust.setAddress("Mumbai");
		cust.setAge(24);
		cust.setName("Varsha");
		cust.setEmail("vars@gmnss.com");
		daoA.createAccount(cust);
		try {
			requestCust = daoA.find(23);
			Assert.assertNotNull(requestCust);

		} catch (RecordNotFoundException e) {
			System.out.println(e);
		}
	}

}
