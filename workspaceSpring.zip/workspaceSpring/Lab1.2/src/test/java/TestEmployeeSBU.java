import static org.junit.Assert.assertNotNull;

import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.bean.Employee;
import com.cg.bean.SBU;

public class TestEmployeeSBU {
	@Test
	public void testEmployeeSBU() {
		ApplicationContext ctx = new ClassPathXmlApplicationContext("employeeSBU.xml");
		Employee e = (Employee) ctx.getBean(Employee.class);
		System.out.println("Employee Details");
		System.out.println("--------------------");

		System.out.println(e + " \n");
		assertNotNull(e);
	}
}
