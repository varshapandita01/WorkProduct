package com.cg.controller;

public interface TraineeController {

}
