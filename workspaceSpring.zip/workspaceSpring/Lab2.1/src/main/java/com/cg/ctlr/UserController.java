package com.cg.ctlr;

import java.util.ArrayList;
import java.util.List;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.cg.entity.Login;
import com.cg.entity.Trainee;

@Scope("session")
@Controller

public class UserController {

	ArrayList<String> domainList;
	ArrayList<String> locationList;

	@RequestMapping(value = "checkLogin")
	public String checkLogin(Login login, Model m) {
		String invalid = "Enter correct Details";
		m.addAttribute("invalid", invalid);
		// Logic to validate userName and password against database

		return "trainee";

	}

	@RequestMapping(value = "addTrainee")
	public String addtrainee(Model model) {
		locationList = new ArrayList<String>();

		locationList.add("Chennai");
		locationList.add("Bangalore");
		locationList.add("Pune");
		locationList.add("Mumbai");

		domainList = new ArrayList<String>();

		domainList.add("Java");
		domainList.add("Struts");
		domainList.add("Spring");
		domainList.add("Hibernate");

		model.addAttribute("domainList", domainList);
		model.addAttribute("locationList", locationList);

		model.addAttribute("trainee", new Trainee());

		return "addTrainee";

	}

	@RequestMapping(value = "deleteTrainee")
	public String deleteTrainee() {

		return "deleteTrainee";

	}

	@RequestMapping(value = "modifyTrainee")
	public String modifyTrainee() {

		return "modifyTrainee";

	}

	@RequestMapping(value = "retrieveTrainee")
	public String retrieveTrainee() {

		return "retrieveTrainee";

	}

	@RequestMapping(value = "retrieveAllTrainee")
	public String retrieveAllTrainee(Model m) {
		List<Trainee> list = null;
		m.addAttribute("list", list);
		return "retrieveAllTrainee";

	}

}