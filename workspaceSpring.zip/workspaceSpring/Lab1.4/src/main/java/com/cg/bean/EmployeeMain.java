package com.cg.bean;

import java.util.Scanner;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class EmployeeMain {

	public static void main(String[] args) {
		System.out.println("Enter employee id to display details");
		Scanner sc = new Scanner(System.in);
		
		int id = sc.nextInt();
		
		ApplicationContext ctx = new ClassPathXmlApplicationContext("employee.xml");
		EmployeeCollection e = (EmployeeCollection) ctx.getBean("e7");
		e.check(id);
	}

}
