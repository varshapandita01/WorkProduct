import static org.junit.Assert.assertNotNull;

import java.util.Scanner;

import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.bean.Employee;
import com.cg.bean.EmployeeCollection;

public class TestMain {

	@Test
	public void TestEmployee() {
		System.out.println("Enter employee id to display details");
		Scanner sc = new Scanner(System.in);
		
		int id = sc.nextInt();
		
		ApplicationContext ctx = new ClassPathXmlApplicationContext("employee.xml");
		EmployeeCollection e = (EmployeeCollection) ctx.getBean("e7");
		e.check(id);
		
		//assertNotNull(e);
	}
}
