package com.cg.service;

import java.sql.SQLException;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.bean.AccountUser;
import com.cg.dao.SpringWalletDao;
import com.cg.dao.SpringWalletDaoImpl;
import com.cg.exception.WalletException;

@Service("service")
public class WalletServices implements IWalletServices {

	@Autowired
	SpringWalletDao spring;

	public boolean validateUserName(String userName) {
		if (userName.matches(userNamePattern))
			return true;
		else
			return false;
	}

	public boolean validateUserAge(String userAge) {

		if (userAge.matches(userAgePattern) && Integer.parseInt(userAge) >= 22)
			return true;
		else
			return false;
	}

	public boolean validateUserAddress(String userAddress) {
		if (userAddress.matches(userAddressPattern))
			return true;
		else
			return false;
	}

	public boolean validateUserEmailAddress(String userAddress) {
		if (userAddress.matches(userEmailAddressPattern))
			return true;
		else
			return false;
	}

	public boolean validateChoice(String option) {
		if (option.matches(CHOICE))
			return true;
		else
			return false;
	}

	public boolean validateChoice1(String option1) {
		if (option1.matches(CHOICE1))
			return true;
		else
			return false;
	}

	/*
	 * @Override public void fundTransfer(double amount) { aud.fundTransfer(amount);
	 * }
	 * 
	 * @Override public void printTransaction(int Accno) throws WalletException {
	 * aud.printTransaction(Accno);
	 * 
	 * }
	 */

	public void createUser(AccountUser auU) throws WalletException {
		spring.createUser(auU);
	}

	public boolean validateAccountNo(int Accno) throws WalletException {
		spring.validateAccountNo(Accno);
		return false;
	}

	public double showBalance(int accno) throws WalletException {
		return spring.showBalance(accno);

	}

	public void depositMoney(double amount, int Accno) throws WalletException {
		spring.depositMoney(amount, Accno);

	}

	public void withdrawMoney(double amount, int Accno) throws WalletException, ClassNotFoundException {
		spring.withdrawMoney(amount, Accno);

	}

	public void fundTransfer(double amount, int accno, int Accno) throws ClassNotFoundException, WalletException {
		spring.fundTransfer(amount, accno, Accno);

	}

	public void printTransaction(int Accno) throws WalletException {
		spring.printTransaction(Accno);

	}

	/*
	 * @Override public void withdrawMoney(double amount, int accno) throws
	 * WalletException { aud.withdrawMoney(amount, accno);
	 * 
	 * }
	 */

}
