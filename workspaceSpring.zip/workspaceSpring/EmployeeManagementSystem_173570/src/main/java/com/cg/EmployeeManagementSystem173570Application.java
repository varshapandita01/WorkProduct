package com.cg;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmployeeManagementSystem173570Application {

	public static void main(String[] args) {
		SpringApplication.run(EmployeeManagementSystem173570Application.class, args);
	}

}
