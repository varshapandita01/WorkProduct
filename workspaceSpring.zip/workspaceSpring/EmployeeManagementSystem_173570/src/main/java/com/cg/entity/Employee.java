package com.cg.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "Employee")
public class Employee {

	@Id
	/**
	 * Auto Generated Id for employee ID
	 */
	@GeneratedValue
	/**
	 * Specifies Column name and length
	 */
	@Column(name = "EMP_ID")
	private int empId;

	@Column(name = "NAME", length = 20)
	private String name;

	@Column(name = "DESIGNATION", length = 20)
	private String designation;

	@Column(name = "DEPT_NAME", length = 25)
	private String deptName;

	@Column(name = "SALARY", length = 8)
	private int salary;

	/**
	 * Getter and Setters
	 * 
	 * @return
	 */
	public int getEmpId() {
		return empId;
	}

	public void setEmpId(int empId) {
		this.empId = empId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDesignation() {
		return designation;
	}

	public void setDesignation(String designation) {
		this.designation = designation;
	}

	public String getDeptName() {
		return deptName;
	}

	public void setDeptName(String deptName) {
		this.deptName = deptName;
	}

	public int getSalary() {
		return salary;
	}

	public void setSalary(int salary) {
		this.salary = salary;
	}

}
