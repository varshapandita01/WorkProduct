package com.cg.service;

import java.util.NoSuchElementException;

import com.cg.entity.Employee;

public interface EmployeeService {

	void createEmployee(Employee e);

	public Employee updateEmployee(Employee e, int id);

	public String deleteEmployee(int id);

	Iterable<Employee> viewEmployeesList();

	Employee findEmployee(int id);

	Employee findByDepartmentName(String deptName) throws NoSuchElementException;
}
