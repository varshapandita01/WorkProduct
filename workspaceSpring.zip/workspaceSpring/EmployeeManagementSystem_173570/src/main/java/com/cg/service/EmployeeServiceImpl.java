package com.cg.service;

import java.util.NoSuchElementException;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.cg.entity.Employee;
import com.cg.repo.EmployeeRepo;

@Repository
@Transactional
public class EmployeeServiceImpl implements EmployeeService {

	/**
	 * annotation for spring bean autowiring
	 */
	@Autowired
	private EmployeeRepo repo;

	/**
	 * Used CRUD Operations for all methods using spring boot
	 * 
	 */

	@Override
	public void createEmployee(Employee e) {
		repo.save(e);
	}

	@Override
	public Employee updateEmployee(Employee e, int id) {

		e.setEmpId(id);
		repo.save(e);
		System.out.println("Employee Updated Successfully");
		return e;

	}

	/**
	 * Deletes specific employee for that id
	 */
	@Override
	public String deleteEmployee(int id) {
		repo.deleteById(id);
		return "Employee Data Deleted Successfully";

	}

	/**
	 * Fetches all specific database table i.e.employee
	 */
	@Override
	public Iterable<Employee> viewEmployeesList() {

		return repo.findAll();
	}

	/**
	 * Exception Handling if ID NOT FOUND
	 */
	@Override
	public Employee findEmployee(int id) throws NoSuchElementException {
		try {
			return repo.findById(id).get();
		} catch (NoSuchElementException e) {
			throw new NoSuchElementException("No Such ID Found ");
		}
	}

	/**
	 * Exception Handling if Department Name NOT FOUND
	 */
	@Override
	public Employee findByDepartmentName(String deptName) throws NoSuchElementException {
		try {
			return repo.findBydeptName(deptName);
		} catch (NoSuchElementException e) {
			throw new NoSuchElementException("No Such Department Name Found");
		}
	}

}
