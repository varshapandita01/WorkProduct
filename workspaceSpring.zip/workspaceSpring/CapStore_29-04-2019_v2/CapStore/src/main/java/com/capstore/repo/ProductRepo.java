package com.capstore.repo;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import com.capstore.bean.Product;

public interface ProductRepo extends CrudRepository<Product, Integer> {

	@Query(value = "from Product p where p.name like %:query%")
	Iterable<Product> findByProdName(@Param("query") String productName);

	@Query(value = "from Product p where p.brand like %:query%")
	Iterable<Product> findByProdBrand(@Param("query") String productBrand);
}
