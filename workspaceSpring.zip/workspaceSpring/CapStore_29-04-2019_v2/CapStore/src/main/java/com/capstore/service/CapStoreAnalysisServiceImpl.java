package com.capstore.service;

import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capstore.bean.Inventory;
import com.capstore.bean.Merchant;
import com.capstore.bean.MostView;
import com.capstore.bean.Order;
import com.capstore.bean.Product;
import com.capstore.repo.CustomerRepo;
import com.capstore.repo.InventoryRepo;
import com.capstore.repo.MerchantRepo;
import com.capstore.repo.MostViewRepo;
import com.capstore.repo.OrderRepo;
import com.capstore.repo.ProductRepo;

@Service
@Transactional
public class CapStoreAnalysisServiceImpl implements ICapStoreAnalysisService {

	@Autowired
	CustomerRepo custRepo;
	@Autowired
	InventoryRepo inventoryRepo;
	@Autowired
	MerchantRepo merchantRepo;
	@Autowired
	MostViewRepo mostViewRepo;
	@Autowired
	OrderRepo orderRepo;
	@Autowired
	ProductRepo productRepo;

	@Override
	public List<Product> getAllProductOfMerchant(int merchantId) {
		Merchant merchant = merchantRepo.findById(merchantId).get();
		Iterable<Inventory> inv = merchant.getInventory();
		List<Product> products = new ArrayList<Product>();
		for (Inventory inventory : inv) {
			products.add(inventory.getProduct());
		}
		return products;
	}

	@Override
	public List<MostView> getAllMostViewed() {

		return (List<MostView>) mostViewRepo.findAll();
	}

	@Override
	public List<Order> getAllOrder() {

		return (List<Order>) orderRepo.findAll();
	}

	@Override
	public Iterable<MostView> viewByProduct() {
		Iterable<MostView> mostViews = mostViewRepo.findAll();
		return mostViews;
	}

}
