package com.capstore.repo;

import org.springframework.data.repository.CrudRepository;

import com.capstore.bean.Admin;

public interface AdminRepo extends CrudRepository<Admin, Integer> {

	Admin findByEmailAndPassword(String email, String password);
}
