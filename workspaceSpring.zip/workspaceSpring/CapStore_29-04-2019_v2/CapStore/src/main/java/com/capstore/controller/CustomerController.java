package com.capstore.controller;

import java.util.List;
import java.util.NoSuchElementException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.capstore.bean.Address;
import com.capstore.bean.Customer;
import com.capstore.service.CustomerService;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/customer")
public class CustomerController {

	@Autowired
	CustomerService service;

	@PostMapping(path = "/add", consumes = "application/json", produces = "application/json")
	public ResponseEntity<Customer> saveCustomer(@RequestBody Customer customer) {
		service.saveCustomer(customer);
		return new ResponseEntity<Customer>(customer, HttpStatus.OK);

	}

	@GetMapping(path = "/{id}")
	public ResponseEntity<?> getCustomer(@PathVariable("id") int id) {
		try {
			Customer cust = service.getCustomer(id);
			return new ResponseEntity<Customer>(cust, HttpStatus.OK);
		} catch (NoSuchElementException e) {
			return new ResponseEntity<String>("Sorry. No Such Customer Found", HttpStatus.NOT_FOUND);
		}

	}

	@GetMapping(path = "/")
	public ResponseEntity<?> validateCustomer(@RequestParam("email") String email,
			@RequestParam("password") String password) {
		try {
			Customer customer = service.getByEmailAndPass(email, password);
			return new ResponseEntity<Customer>(customer, HttpStatus.OK);
		} catch (NoSuchElementException e) {
			return new ResponseEntity<String>("Sorry. No Such Customer Found", HttpStatus.NOT_FOUND);
		}
	}

	@DeleteMapping(path = "/{id}")
	public void deleteCustomer(@PathVariable("id") int id) {
		service.deleteCustomer(id);
	}

	@GetMapping(path = "/all")
	public Iterable<Customer> getAllCustomer() {
		return service.getAll();
	}

	@PostMapping(path = "/address/{custId}")
	public ResponseEntity<Customer> addAddress(@RequestBody Address address, @PathVariable("custId") int custId) {
		Customer cust = service.getCustomer(custId);
		cust.addAddress(address);
		service.saveCustomer(cust);
		return new ResponseEntity<Customer>(cust, HttpStatus.OK);
	}

	@GetMapping(path = "/getaddress/{custId}")
	public ResponseEntity<List<Address>> getAddress(@PathVariable int custId) {
		Customer cust = service.getCustomer(custId);
		return new ResponseEntity<List<Address>>(cust.getAddress(), HttpStatus.OK);
	}

	@DeleteMapping(path = "/address/{addressId}")
	public ResponseEntity<String> deleteAddress(@PathVariable("addressId") int addId) {
		service.deleteAddress(addId);
		return new ResponseEntity<String>("Address deleted successfully", HttpStatus.OK);
	}

	@PutMapping(path = "/address/{custId}")
	public ResponseEntity<Customer> updateAddress(@RequestBody Address address, @PathVariable("custId") int custId) {
		Customer cust = service.getCustomer(custId);
		cust.addAddress(address);
		service.saveCustomer(cust);
		return new ResponseEntity<Customer>(cust, HttpStatus.OK);
	}

	/**
	 * @author Ankush Dhodi
	 * @param id
	 * @param email
	 * @param password
	 */
	@PutMapping(path = "/update", produces = "application/json")
	public ResponseEntity<String> updatePassword(@RequestParam("id") int id, @RequestParam("email") String email,
			@RequestParam("password") String password) {

		return new ResponseEntity<String>(service.changePassword(id, email, password), HttpStatus.OK);

	}
}
