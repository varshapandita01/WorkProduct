package com.capstore.repo;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.capstore.bean.Order;

public interface OrderRepo extends CrudRepository<Order, Integer> {

	@Modifying
	@Query(value = "update inventory set product_quantity=product_quantity- ?1 where  MERCHANT_ID=?2 and PRODUCT_ID=?3", nativeQuery = true)
	void updateInventory(Integer quantity, Integer merchId, Integer productId);
}
