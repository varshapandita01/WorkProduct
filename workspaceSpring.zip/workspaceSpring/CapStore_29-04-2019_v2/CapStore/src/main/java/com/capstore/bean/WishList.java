/*
 * Author :- Mayuresh Shinde 173560
 * version:- 1.0.2
 */
package com.capstore.bean;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonManagedReference;

@Entity
@Table(name = "wishlist")
@SequenceGenerator(name = "wlseq", sequenceName = "wishlist_seq", initialValue = 101)
public class WishList {

	@Id
	@Column(name = "wishlist_id", length = 10)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "wlseq")
	private int id;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public Customer getCustomer() {
		return customerFromWishList;
	}

	public void setCustomer(Customer customer) {
		this.customerFromWishList = customer;
	}

	@JsonIgnore
	public Customer getCustomerFromWishList() {
		return customerFromWishList;
	}

	public void setCustomerFromWishList(Customer customerFromWishList) {
		this.customerFromWishList = customerFromWishList;
	}

	public List<ProductWishList> getProductsWishList() {
		return productsWishList;
	}

	public void setProductsWishList(List<ProductWishList> productsWishList) {
		this.productsWishList = productsWishList;
	}

	public void addProduct(ProductWishList prodWish) {
		prodWish.setWishList(this);
		this.getProductsWishList().add(prodWish);
	}

	/************** Relationships ******************/

	@JsonManagedReference(value = "customer-wishlist")
	@OneToMany(mappedBy = "wishList", fetch = FetchType.LAZY, cascade = CascadeType.ALL)
	private List<ProductWishList> productsWishList = new ArrayList<ProductWishList>();

	@JsonBackReference(value = "cust-wish")
	@OneToOne
	@JoinColumn(name = "customer_id")
	private Customer customerFromWishList;
}
