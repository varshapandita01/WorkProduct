/*
 * Author :- Mayuresh Shinde 173560
 * version:- 1.0.2
 */
package com.capstore.bean;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonManagedReference;

@Entity
@Table(name = "cart")
@SequenceGenerator(name = "cartseq", sequenceName = "cart_seq", initialValue = 101)
public class Cart {

	@Id
	@Column(name = "cart_id", length = 10)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "cartseq")
	private int id;

	/************** Relationships ******************/
	@JsonBackReference(value = "cust-cart")
	@OneToOne(cascade = CascadeType.PERSIST)
	@JoinColumn(name = "customer_id")
	private Customer customerFromCart;

	@JsonManagedReference(value = "cart_product")
	@OneToMany(mappedBy = "cart", fetch = FetchType.LAZY, cascade = CascadeType.ALL)
	private List<CartProduct> cartProducts = new ArrayList<CartProduct>();

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public Customer getCustomerFromCart() {
		return customerFromCart;
	}

	public void setCustomerFromCart(Customer customerFromCart) {
		this.customerFromCart = customerFromCart;
	}

	public List<CartProduct> getCartProducts() {
		return cartProducts;
	}

	public void setCartProducts(List<CartProduct> cartProducts) {
		this.cartProducts = cartProducts;
	}

	public void addCartProduct(CartProduct cartProd) {
		cartProd.setCart(this);
		this.getCartProducts().add(cartProd);
	}

}
