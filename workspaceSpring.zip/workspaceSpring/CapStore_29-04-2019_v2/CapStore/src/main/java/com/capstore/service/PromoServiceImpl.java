/**
 * @Author Laxmi Bugade
 * @version: 1.0.0
 * It is service implementation of promo
 */

package com.capstore.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.capstore.bean.Promo;
import com.capstore.repo.PromoRepo;

@Service
@Transactional
public class PromoServiceImpl implements PromoService {
	@Autowired
	private PromoRepo repo;

	@Override
	public void savePromo(Promo promo) {
		repo.save(promo);
	}

	@Override
	public Promo get(int promoId) {
		return repo.findById(promoId).get();
	}

}
