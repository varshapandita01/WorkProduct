package com.capstore.service;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capstore.bean.WishList;
import com.capstore.repo.WishListRepo;

@Service
@Transactional
public class WishListServiceImpl implements IWishListService {

	@Autowired
	WishListRepo repo;

	public void saveWishList(WishList wishList) {
		repo.save(wishList);
	}
}
