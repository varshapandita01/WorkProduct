/**
 * @Author Laxmi Bugade
 * @version: 1.0.0
 * It is bean class of promo
 */

package com.capstore.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "Promo")
@SequenceGenerator(name = "proseq", sequenceName = "promo_seq", initialValue = 101)
public class Promo {

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "proseq")
	@Column(name = "promo_id", length = 10)
	private int promoId;

	@Column(name = "promo_title", length = 30)
	private String promoTitle;

	@Column(name = "promo_description", length = 100)
	private String promoDescription;

	@Column(name = "product_name", length = 50)
	private String productName;

	@Column(name = "category", length = 50)
	private String category;

	@Column(name = "discount_amount", columnDefinition = "Decimal(10,2)")
	private double discountAmount;

	@Column(name = "expiry_date", length = 10)
	private String expiryDate;

	public int getPromoId() {
		return promoId;
	}

	public void setPromoId(int promoId) {
		this.promoId = promoId;
	}

	public String getPromoTitle() {
		return promoTitle;
	}

	public void setPromoTitle(String promoTitle) {
		this.promoTitle = promoTitle;
	}

	public String getPromoDescription() {
		return promoDescription;
	}

	public void setPromoDescription(String promoDescription) {
		this.promoDescription = promoDescription;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public double getDiscountAmount() {
		return discountAmount;
	}

	public void setDiscountAmount(int discountAmount) {
		this.discountAmount = discountAmount;
	}

	public String getExpiryDate() {
		return expiryDate;
	}

	public void setExpiryDate(String expiryDate) {
		this.expiryDate = expiryDate;
	}

}
