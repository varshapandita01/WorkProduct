/*
 * Author :- Mayuresh Shinde 173560
 * version:- 1.0.3
 */
package com.capstore.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name = "Review")
@SequenceGenerator(name = "reviewseq", sequenceName = "review_seq", initialValue = 101)
public class Review {

	@Id
	@Column(name = "review_id")
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "reviewseq")

	private int id;

	@Column(name = "customer_firstname", length = 20)
	private String customerFirstName;

	@Column(name = "product_rating")
	private double productRating;

	@Column(name = "product_comment")
	private String productComment;

	public int getReviewId() {
		return id;
	}

	public void setReviewId(int reviewId) {
		this.id = reviewId;
	}

	@JsonIgnore
	public Product getProduct() {
		return productFromReview;
	}

	public void setProduct(Product product) {
		this.productFromReview = product;
	}

	public String getCustomerFirstName() {
		return customerFirstName;
	}

	public void setCustomerFirstName(String customerFirstName) {
		this.customerFirstName = customerFirstName;
	}

	public double getProductRating() {
		return productRating;
	}

	public void setProductRating(int productRating) {
		this.productRating = productRating;
	}

	public String getProductComment() {
		return productComment;
	}

	public void setProductComment(String productComment) {
		this.productComment = productComment;
	}

	/************** Relationships ******************/
	@JsonBackReference(value = "product-review")
	@ManyToOne
	@JoinColumn(name = "product_id")
	private Product productFromReview;

}