/*
 * Author :- Mayuresh Shinde 173560
 * version:- 1.0.2
 */
package com.capstore.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name = "most_viewed")
@SequenceGenerator(name = "mvseq", sequenceName = "mostview_seq", initialValue = 101)
public class MostView {

	@Id
	@Column(name = "viewed_id")
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "mvseq")
	private int id;

	@Column(name = "view_count")
	private long viewCount;

	@Column(name = "sold_count")
	private long soldCount;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public long getViewCount() {
		return viewCount;
	}

	public void setViewCount(long viewCount) {
		this.viewCount = viewCount;
	}

	public long getSoldCount() {
		return soldCount;
	}

	public void setSoldCount(long soldCount) {
		this.soldCount = soldCount;
	}

	@JsonIgnore
	public Product getProductFromMostView() {
		return productFromMostView;
	}

	public void setProductFromMostView(Product productFromMostView) {
		this.productFromMostView = productFromMostView;
	}

	/************** Relationships ******************/
	@JsonBackReference(value = "mostview")
	@OneToOne
	@JoinColumn(name = "product_id")
	private Product productFromMostView;
}
