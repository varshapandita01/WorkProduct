package com.capstore.service;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capstore.bean.Order;
import com.capstore.repo.OrderRepo;

@Service
@Transactional
public class OrderServiceImpl implements IOrderService {

	@Autowired
	private OrderRepo repo;

	@Override
	public Order saveOrder(Order order) {
		return repo.save(order);
	}

	@Override
	public Order getOrder(int id) {
		return repo.findById(id).get();
	}

	public void updateInventory(int quantity, int merchId, int productId) {
		repo.updateInventory(quantity, merchId, productId);
	}
}
