package com.capstore.repo;

import org.springframework.data.repository.CrudRepository;

import com.capstore.bean.Customer;

public interface CustomerRepo extends CrudRepository<Customer, Integer> {

	Customer findByEmailAndPassword(String email, String password);
}
