/**
 * @Author Laxmi Bugade
 * @version: 1.0.0
 * It is service interface of promo
 */

package com.capstore.service;

import com.capstore.bean.Promo;


public interface PromoService {
	
    void savePromo(Promo promo);
	
	Promo get(int promoId);
	
}
