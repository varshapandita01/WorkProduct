package com.capstore.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.capstore.bean.Review;
import com.capstore.service.IReviewService;

/**
 * @author Saikat , Sushen
 *
 */

@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/review")
public class ReviewController {

	@Autowired
	private IReviewService service;

	@PostMapping(path = "/add/{productId}", produces = "application/json", consumes = "application/json")
	public String createReview(@RequestBody Review review, @PathVariable("productId") int productId) {
		return service.addReview(productId, review);
	}

	@PutMapping(path = "/update", consumes = "application/json")
	public String updateEmployee(@RequestBody Review review) {
		return service.updateReview(review);
	}

	@DeleteMapping(path = "/delete/{id}")
	public String deleteReview(@PathVariable("id") int reviewId) {
		try {
			return service.deleteReview(reviewId);
		} catch (Exception e) {
			return "No such review found for " + reviewId;
		}
	}

	@GetMapping(path = "/get/{productId}")
	public List<Review> getreview(@PathVariable("productId") int productId) {
		List<Review> allReviews = service.getProductReviewById(productId);
		return allReviews;
	}
}
