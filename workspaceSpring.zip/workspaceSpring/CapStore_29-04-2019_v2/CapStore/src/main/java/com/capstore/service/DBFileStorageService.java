package com.capstore.service;

import java.io.IOException;

import javax.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import org.springframework.web.multipart.MultipartFile;

import com.capstore.bean.DBFile;
import com.capstore.exception.FileStorageException;
import com.capstore.exception.MyFileNotFoundException;
import com.capstore.repo.DBFileRepository;

/**
 * 
 * This is the service Implementation for the image upload
 * 
 * @author yash naik
 *
 */
@Service
@Transactional
public class DBFileStorageService {

	/**
	 * Autowiring the repository
	 */
	@Autowired
	private DBFileRepository dbFileRepository;

	/**
	 * This is The Logic to Store the image in database
	 * 
	 * @param file
	 * @return
	 */
	public DBFile storeFile(MultipartFile file) {
		// Normalize file name
		String fileName = StringUtils.cleanPath(file.getOriginalFilename());

		try {
			// Check if the file's name contains invalid characters
			if (fileName.contains("..")) {
				throw new FileStorageException("Sorry! Filename contains invalid path sequence " + fileName);
			}

			DBFile dbFile = new DBFile(fileName, file.getContentType(), file.getBytes());

			return dbFileRepository.save(dbFile);
		} catch (IOException ex) {
			throw new FileStorageException("Could not store file " + fileName + ". Please try again!", ex);
		}
	}

	/**
	 * This is the logic to find the product on the basis of Id
	 * 
	 * @param fileId
	 * @return file
	 */
	public DBFile getFile(String fileId) {
		return dbFileRepository.findById(fileId)
				.orElseThrow(() -> new MyFileNotFoundException("File not found with id " + fileId));
	}

}
