package com.capstore.repo;

import org.springframework.data.repository.CrudRepository;

import com.capstore.bean.Image;

public interface ImageRepo extends CrudRepository<Image, Integer> {

}
