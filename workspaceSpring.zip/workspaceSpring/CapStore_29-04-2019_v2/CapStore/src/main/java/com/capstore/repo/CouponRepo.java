package com.capstore.repo;

import org.springframework.data.repository.CrudRepository;

import com.capstore.bean.Coupon;

public interface CouponRepo extends CrudRepository<Coupon, Integer> {

}
