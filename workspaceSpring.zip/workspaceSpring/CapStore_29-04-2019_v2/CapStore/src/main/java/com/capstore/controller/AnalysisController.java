package com.capstore.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.capstore.bean.MostView;
import com.capstore.bean.Order;
import com.capstore.bean.Product;
import com.capstore.service.ICapStoreAnalysisService;

@RestController
@CrossOrigin(origins = "http://localhost:4200")
@RequestMapping("/analyse")
public class AnalysisController {

	@Autowired
	ICapStoreAnalysisService service;

	@GetMapping(path = "/productofmerchant/{merchantid}")
	public List<Product> getAllProductOfMerchant(@PathVariable("merchantid") int merchantId) {

		return service.getAllProductOfMerchant(merchantId);
	}

	@GetMapping(path = "/productsoldgraph")
	public List<MostView> getAllMostViewed() {

		return service.getAllMostViewed();

	}

	@GetMapping(path = "/allorders")
	public List<Order> getAllOrder() {
		return service.getAllOrder();

	}

	@GetMapping(path = "/viewbyproduct")
	public Iterable<MostView> viewByProduct() {
		return service.viewByProduct();
	}

}
