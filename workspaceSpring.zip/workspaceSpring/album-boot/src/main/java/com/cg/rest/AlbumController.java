package com.cg.rest;

import java.util.NoSuchElementException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.cg.entity.AlbumEntity;
import com.cg.service.AlbumService;

@RestController
public class AlbumController {
/*
	@ResponseStatus(value = HttpStatus.NOT_FOUND, reason = "Album with this id not present")
	@ExceptionHandler({ Exception.class })
	public void handleException() {
	}

	@ResponseStatus(value = HttpStatus.BAD_REQUEST, reason = "Album with this id not present")
	@ExceptionHandler({ Exception.class })
	public void badException() {
	}
*/
	@Autowired
	private AlbumService service;

	@PostMapping(path = "/add", consumes = "application/json")
	public String saveAlbum(@RequestBody AlbumEntity a) {
		service.saveAlbum(a);
		return "Album Successfully Added";

	}

	@GetMapping(path = "/get/{id}", produces = "application/json")
	public ResponseEntity<AlbumEntity> getAlbum(@PathVariable("id") int id) {
		try {
			AlbumEntity a = service.get(id);
			return new ResponseEntity<AlbumEntity>(a, HttpStatus.OK);
		} catch (NoSuchElementException e) {
			return new ResponseEntity(e.getMessage(), HttpStatus.NOT_FOUND);
		}
	}

	@GetMapping(path="/getName/{name}", produces = "application/json")
	public ResponseEntity<AlbumEntity> getAlbum(@PathVariable("name") String name) {
		try {
			AlbumEntity a = service.getByName(name);
			return new ResponseEntity<AlbumEntity>(a, HttpStatus.OK);
		} catch (NoSuchElementException e) {
			return new ResponseEntity(e.getMessage(), HttpStatus.NOT_FOUND);
		}
	}
	@GetMapping(path = "/getAll", produces = "application/json")
	public Iterable<AlbumEntity> getAllAlbum() {
		return service.getAll();

	}

	@PutMapping(path = "/update/{id}", consumes = "application/json")
	public AlbumEntity updateAlbum(@RequestBody AlbumEntity a, @PathVariable("id") int id) {

		return service.updateAlbum(a, id);

	}

	@DeleteMapping(path = "/delete", consumes = "application/json")
	public String deleteAlbum(@RequestParam("id") int id) {
		return service.deleteAlbum(id);

	}
	
	
}
