package com.cg.service;

import java.util.NoSuchElementException;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.cg.entity.AlbumEntity;
import com.cg.repo.AlbumRepo;

@Repository
@Transactional
public class AlbumServiceImpl implements AlbumService {

	@Autowired
	private AlbumRepo repo;

	@Override
	public void saveAlbum(AlbumEntity a) {
		repo.save(a);
	}

	@Override
	public AlbumEntity get(int id) throws NoSuchElementException {
		try {
			return repo.findById(id).get();
		} catch (NoSuchElementException e) {
			throw new NoSuchElementException("No Such Element Found Exception");
		}
	}

	@Override
	public Iterable<AlbumEntity> getAll() {

		return repo.findAll();
	}

	@Override
	public String deleteAlbum(int id) {

		repo.deleteById(id);
		return "Album List Deleted Successfully";
	}

	@Override
	public AlbumEntity updateAlbum(AlbumEntity a, int id) {
		a.setId(id);
		repo.save(a);
		return a;

	}

	@Override
	public AlbumEntity getByName(String name) throws NoSuchElementException {
		try {
			return repo.findByalbumArtist(name);
		} catch (NoSuchElementException e) {
			throw new NoSuchElementException("No Such Element Found Exception");
		}
	}

}
