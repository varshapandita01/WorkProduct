package com.cg.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="album_details")
public class AlbumEntity {
	
	@Id
	@GeneratedValue
	private int id;
	
	@Column(length=20)
	private String albumTitle;
	
	@Column(length=20)
	private String albumArtist;
	
	@Column
	private int albumprice;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getAlbumTitle() {
		return albumTitle;
	}

	public void setAlbumTitle(String albumTitle) {
		this.albumTitle = albumTitle;
	}

	public String getAlbumArtist() {
		return albumArtist;
	}

	public void setAlbumArtist(String albumArtist) {
		this.albumArtist = albumArtist;
	}

	public int getAlbumprice() {
		return albumprice;
	}

	public void setAlbumprice(int albumprice) {
		this.albumprice = albumprice;
	}
	
	
}
