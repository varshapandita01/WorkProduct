package com.cg.repo;

import org.springframework.data.repository.CrudRepository;

import com.cg.entity.AlbumEntity;

public interface AlbumRepo extends CrudRepository<AlbumEntity, Integer> {
	
	public AlbumEntity findByalbumArtist(String artist);
}
