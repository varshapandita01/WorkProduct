package com.cg.service;

import com.cg.entity.AlbumEntity;

public interface AlbumService {

	void saveAlbum(AlbumEntity a);

	AlbumEntity get(int id);

	Iterable<AlbumEntity> getAll();

	public String deleteAlbum(int id);

	public AlbumEntity updateAlbum(AlbumEntity a, int id);

	AlbumEntity getByName(String albumArtist);
	
	
}
