package com.cg;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MvcBoot1Application {

	public static void main(String[] args) {
		SpringApplication.run(MvcBoot1Application.class, args);
	}

}
