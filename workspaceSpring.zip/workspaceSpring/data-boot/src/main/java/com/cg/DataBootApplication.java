package com.cg;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;

import com.cg.entity.Product;
import com.cg.repo.ProductRepo;


@SpringBootApplication
@EntityScan("com.cg.entity")
public class DataBootApplication implements CommandLineRunner {

	@Autowired
	private ProductRepo repo;

	public static void main(String[] args) {
		SpringApplication.run(DataBootApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		// Save data in database
		/*
		 * Product p= new Product(); p.setName("iphone"); p.setPrice(12000);
		 * 
		 * repo.save(p);
		 */

		// find data from database by ID
		Product p = repo.findById(101).get();
		System.out.println(p.getName() + " : " + p.getPrice());
	}
}
