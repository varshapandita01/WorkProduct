package com.cg.Rest;

import java.util.List;

import javax.persistence.PostPersist;
import javax.xml.ws.RequestWrapper;

import org.aspectj.lang.annotation.RequiredTypes;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.boot.test.autoconfigure.web.client.RestClientTest;


import com.cg.entity.Product;
import com.cg.repo.ProductRepo;



@RestClientTest
public class HelloController {

	@Autowired
	private ProductRepo repo;

/*	@PostPersist
	public String get(@RequiredTypes("name") String name, @RequestParam("price") double price) {
		Product p = new Product();
		p.setName(name);
		p.setPrice(price);
		repo.saveProduct(p);
		return "Product Saved";

	}*/
}
