import { MostView } from './MostView';

export class Product{
  id:number;
  name:string;
  brand:string;
 mostView:MostView;
}
