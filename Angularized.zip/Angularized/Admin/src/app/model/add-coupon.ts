export class CouponFields {
    couponId: number;
    couponCode: string;
    couponExpiry: string;
    couponIsUsed: string;
}