export class Merchant {
	public id: number;
	public firstName: String;
	public lastName: String;
	public email: String;
	public password: String;
	public contact: String;
	public isActive: String;
}