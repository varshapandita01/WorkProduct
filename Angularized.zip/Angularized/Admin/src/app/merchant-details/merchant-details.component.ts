import { Component, OnInit } from '@angular/core';
import { CustomerModel } from '../model/customer';
import { MerchantModel } from '../model/merchant';
import { Merchant } from '../model/ManageMerchant';

import { CommonAdminService } from '../service/common-admin.service';
import { Router } from '@angular/router';
import { MerchantServiceService } from '../Service/merchant-service.service';

@Component({
  selector: 'app-merchant-details',
  templateUrl: './merchant-details.component.html',
  styleUrls: ['./merchant-details.component.css']
})
export class MerchantDetailsComponent implements OnInit {
  //merchantArr: MerchantModel[];
 
  merchantArr: Merchant[];
  merchant = new Merchant();

  constructor(private service: CommonAdminService, private router : Router, private merchantService: MerchantServiceService) {
    this.merchantArr = [];
   
  }

  ngOnInit() {
    
    this.service.getMerchantDetails().subscribe(data => {
      this.merchantArr = data;
    });
   
  }
  navigateTo(path: string) {
    this.router.navigate(['/' + path]);
  }
  // add merchant id through loop displayed in html
  delete(id:number) {
    this.merchantService.delete(id).subscribe(
      res => {
        console.log("Deleted succesfully"),
        alert("Deleted Successfully"),
        this.router.navigate(['/merchantdetails']);
        window.location.reload();
      }, error => { console.log(error) }
    )
   
   
  }

  getAll() {
    this.merchantService.getAll().subscribe(
      result => { this.merchantArr = result; },
      error => { console.log(error) }
    )
  }
} 
