import { Injectable } from '@angular/core';
import { ReportModel } from '../model/reportmodel';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class ReportService {
  reportArray: ReportModel[];
  // This is counter for Report Id
  // Report Id automatically starts from 1000
  static counter: number = 1000;
  constructor(private router: Router) {
    this.reportArray = [];

  }
  // This method is to add report and also navigate to next page
  add(report: ReportModel) {
    report.reportId = ReportService.counter++;
    this.reportArray.push(report);
    this.router.navigate(['/addreport']);
  }
  // This method is to display report details
  display() {
    return this.reportArray;
  }
}
