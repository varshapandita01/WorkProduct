import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ReportModel } from '../model/reportmodel';
import { ReportService } from '../service/report.service';

@Component({
  selector: 'app-report',
  templateUrl: './report.component.html',
  styleUrls: ['./report.component.css']
})
export class ReportComponent implements OnInit {
  newReport: ReportModel;
  constructor(private router: Router, private reportservice: ReportService) {
    this.newReport = new ReportModel();
  }


  ngOnInit() {
  }
  // This method is for go back button which will navigate to main page 
  goBack() {
    this.router.navigate(['']);
  }
  // This method is for Report Button which will navigate to form page
  report() {
    this.reportservice.add(this.newReport);


  }

}
