import { Component, OnInit } from '@angular/core';
import {MatDialog, MAT_DIALOG_DATA} from '@angular/material';

@Component({
  selector: 'app-refund',
  templateUrl: './refund.component.html',
  styleUrls: ['./refund.component.css']
})
export class RefundComponent implements OnInit {

  payment: string;
  refunds: string[] = ['Credit Card', 'Debit Card', 'Cash On Delivery'];
  

  constructor() { }

  ngOnInit() {
  }


  
}
