import { Injectable } from '@angular/core';
import { Merchant } from '../model/ManageMerchant';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';





@Injectable({
  providedIn: 'root'
})
export class MerchantServiceService {

 

  constructor(private http: HttpClient, private routes: Router) { }
  baseHref = "http://localhost:8080/merchant";

  add(merchant: Merchant) {
    console.log(merchant);
    var body = {
      firstName: merchant.firstName,
      lastName: merchant.lastName,
      email: merchant.email,
      password: merchant.password,
      contact: merchant.contact,
      isActive: "yes"
    }
    return this.http.post<Merchant>(this.baseHref + "/add", body);
  }






  searchMerchant(id: number) {
    this.routes.navigate(['/delete']);
    return this.http.get<Merchant>(`${this.baseHref}/get/${id}`);
  }

  getAll() {
    return this.http.get<Merchant[]>(this.baseHref + "/all");
  }
  delete(id: number) {
    
    console.log(id);
    return this.http.delete(`${this.baseHref}/${id}`);
  }

  sendInvitation(mobile: number) {
    
    var body = {
     
    }
    
    return this.http.post(`${this.baseHref }/sendSmsInvitation/${mobile}`, body);


  }
}
