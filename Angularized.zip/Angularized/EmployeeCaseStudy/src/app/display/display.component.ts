import { Component, OnInit } from '@angular/core';
import { EmployeeModel } from '../model/Employee';
import { EmployeeService } from '../service/employee.service';

@Component({
  selector: 'app-display',
  templateUrl: './display.component.html',
  styleUrls: ['./display.component.css']
})
export class DisplayComponent implements OnInit {

  employeeArr:EmployeeModel[]

  constructor(private empService:EmployeeService) {
    
   }

  ngOnInit() {
    this.employeeArr=this.empService.display();
  }

}
