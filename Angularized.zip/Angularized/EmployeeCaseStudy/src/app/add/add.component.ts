import { Component, OnInit } from '@angular/core';
import { EmployeeModel } from '../model/Employee';
import { EmployeeService } from '../service/employee.service';

@Component({
  selector: 'app-add',
  templateUrl: './add.component.html',
  styleUrls: ['./add.component.css']
})
export class AddComponent implements OnInit {

  employee: EmployeeModel

  constructor(private empService: EmployeeService) {
    //object
    this.employee = new EmployeeModel()
  }

  ngOnInit() {
  }
  insertEmployee() {
    this.empService.add(this.employee)
  }

}
