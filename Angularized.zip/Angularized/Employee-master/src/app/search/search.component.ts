import { Component, OnInit } from '@angular/core';
import { EmployeeService } from '../services/employee.service';
import { EmployeeModel } from '../models/Employee';

@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css']
})
export class SearchComponent implements OnInit {

  employeeSearched: EmployeeModel;
  constructor(private empService:EmployeeService) { 
    this.employeeSearched = new EmployeeModel();
  }

  ngOnInit() {
  }

  searchEmp(id:number)
  {
    this.employeeSearched = this.empService.searchEmp(id);
  }

}
