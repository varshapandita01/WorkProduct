import { Component, OnInit } from '@angular/core';
import { CustomerModel } from '../model/customer';
import { CustomerService } from '../services/customer.service';

@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css']
})
export class SearchComponent implements OnInit {

  customerSearched: CustomerModel;
  constructor(private empService:CustomerService) { 
    this.customerSearched = new CustomerModel();
  }

  ngOnInit() {
  }

  searchCust(id:number)
  {
    this.customerSearched = this.empService.searchCust(id);
  }
}
