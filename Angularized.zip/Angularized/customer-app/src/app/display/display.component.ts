import { Component, OnInit } from '@angular/core';
import { CustomerModel } from '../model/customer';
import { CustomerService } from '../services/customer.service';

@Component({
  selector: 'app-display',
  templateUrl: './display.component.html',
  styleUrls: ['./display.component.css']
})
export class DisplayComponent implements OnInit {

  customerArr:CustomerModel[];
  customerToEdit:CustomerModel;
  isEditing:boolean;

  constructor(private empService:CustomerService) { 
    this.customerArr = [];
    this.customerToEdit = new CustomerModel()
  }

  ngOnInit() {
    this.customerArr = this.empService.getEmployees();
  }

  delete(index: number) {
    this.empService.delete(index);
   }
 
   edit(id:number)
   {
     this.isEditing = true;
     this.customerToEdit = this.empService.edit(id);
   }

   sortCust()
  {
    this.empService.sortCust();
  }
}
