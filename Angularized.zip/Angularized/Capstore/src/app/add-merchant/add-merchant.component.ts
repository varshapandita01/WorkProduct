import { Component, Input, OnInit } from '@angular/core';
import { Merchant } from '../Model/Merchant';
import { MerchantServiceService } from '../Service/merchant-service.service';

@Component({
  selector: 'app-add-merchant',
  templateUrl: './add-merchant.component.html',
  styleUrls: ['./add-merchant.component.css']
})
export class AddMerchantComponent implements OnInit {

  
  merchant = new Merchant();
  merchantArr: Merchant[] = [];
 //to create new merchant
 //@Input() merchant: Merchant;
  constructor(private merchantService: MerchantServiceService) { 

    this.merchant = new Merchant();
  }

  ngOnInit() {
  }


  addMerchant() {
   
    this.merchantService.add(this.merchant).subscribe(
      result => {
        console.log(result)
        console.log("Added Successfully")
      }, error => { console.log(error) }
    )
    alert("Data Added Successfully")
    this.merchant = new Merchant();
  }

  /*addMerchant() {
    this.merchantService.add(this.merchant);
    this.merchant = new Merchant();
  }*/

}
