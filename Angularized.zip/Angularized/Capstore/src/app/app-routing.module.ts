import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AddMerchantComponent } from './add-merchant/add-merchant.component';
import { DeleteMerchantComponent } from './delete-merchant/delete-merchant.component';

const routes: Routes = [
  {path:'',redirectTo:'',pathMatch: 'full'},
  {path:'add',component: AddMerchantComponent,pathMatch:'full'},
  {path:'delete',component: DeleteMerchantComponent,pathMatch:'full'},
  {path:'**',redirectTo:'/add',pathMatch:'full'}



];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
