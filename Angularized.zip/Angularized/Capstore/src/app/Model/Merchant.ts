export class Merchant{
    public  merchantId:number;
    public  merchantFirstName:String;
	public  merchantLastName:String;
	public  merchantEmail:String;
	public  merchantPassword:String;
	public  merchantContact:String;
	public  isMerchantActivated:boolean=true; 	
}