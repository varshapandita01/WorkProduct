import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {RouterModule, Routes, ROUTES} from '@angular/router';
import { AddComponent } from '../add/add.component';
import { SortComponent } from '../sort/sort.component';
import { SearchComponent } from '../search/search.component';
const routes:Routes = [
  {path:'',redirectTo:'',pathMatch: 'full'},
  {path:'add',component: AddComponent,pathMatch:'full'},
  {path:'sort',component: SortComponent,pathMatch:'full'},
  {path:'search',component: SearchComponent,pathMatch:'full'},
  {path:'**',redirectTo:'/add',pathMatch:'full'}
  ];

@NgModule({
  imports: [
    CommonModule,
    RouterModule.forRoot(routes)
  ],
  exports:[RouterModule],
  declarations: []
})
export class AppRoutingModule { }
