import { Injectable } from '@angular/core';
import { EmployeeModel } from '../Model/Employee';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class EmployeeService {
  employeeArr: EmployeeModel[];
    
    constructor(private routes:Router) {
      this.employeeArr = [];
    }
  
    add(employee: EmployeeModel) {
      employee.employeeId = Math.floor(Math.random() * 100);
      this.employeeArr.push(employee);
      this.routes.navigate(['/sort']);
    }
   
    getEmployees() {
      return this.employeeArr;
    }
    edit(id: number) {
      return this.employeeArr.find(x => x.employeeId == id);
    }
    delete(index: number) {
      this.employeeArr.splice(index, 1);
    }

    searchemp(id: number) {
      var result = this.employeeArr.find(x => x.employeeId == id);
      if (result == null)
        return null; //if not found
      else
        return result; //if found then store it
    }

    sortEmpById() {
      this.employeeArr.sort((a, b) =>( a.employeeId - b.employeeId));
      return this.employeeArr;
    }
    sortEmpByName() {
      this.employeeArr.sort((a, b) =>( a.employeeName.localeCompare(b.employeeName)) );
      return this.employeeArr;
    }

    sortEmpBySalary() {
      this.employeeArr.sort((a, b) =>( a.employeeSalary - b.employeeSalary));
      return this.employeeArr;
    }

}
