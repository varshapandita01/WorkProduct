package com.capgemini.xyz.service;

import java.util.Map;
import java.util.Random;

import com.capgemini.test.bean.CustomerInfo;
import com.capgemini.test.bean.Transaction;
import com.capgemini.xyz.dao.DaoAccountClass;
import com.capgemini.xyz.exception.BalanceException;
import com.capgemini.xyz.exception.RecordNotFoundException;

public class ServiceAccount implements IServiceAccount {
	CustomerInfo customer = new CustomerInfo();
	DaoAccountClass dao = new DaoAccountClass();

	@Override
	public boolean validateChoice(String setChoice) {
		if (setChoice.matches(choicePattern))
			return true;
		else
			return false;
	}

	@Override
	public boolean validateUserName(String setCustName) {
		if (setCustName.matches(userNamePattern))
			return true;
		else
			return false;
	}

	@Override
	public boolean validateUserAge(String setCustAge) {
		if (setCustAge.matches(userAgePattern)
				&& Integer.parseInt(setCustAge) >= 18)
			return true;
		else

			return false;
	}

	@Override
	public boolean validateEmail(String setEmail) {
		if (setEmail.matches(userEmailPattern))
			return true;
		else

			return false;
	}

	@Override
	public boolean validateAddress(String setAddress) {
		if (setAddress.matches(userAddressPattern))
			return true;
		else

			return false;
	}

	@Override
	public boolean validateMobile(String setMobileNumber) {
		if (setMobileNumber.matches(userMobilePattern))
			return true;
		else

			return false;
	}

	@Override
	public boolean validatePincode(String setPincode) {
		if (setPincode.matches(userPincodePattern))
			return true;
		else

			return false;
	}

	public void createAccount(CustomerInfo customer1) {
		dao.createAccount(customer1);
	}

	int balance;

	public void showBalance() {
		dao.showBalance();

	}

	public void deposit(double amount) {
		dao.deposit(amount);
	}

	public void withdraw(double amount) throws BalanceException {
		dao.withdraw(amount);
	}

	public void fundTransfer(int custId, double amount) {
		dao.fundTransfer(custId, amount);
	}

	public Map<Integer, CustomerInfo> displayPersons() {

		return dao.displayCustomerDetails();
	}

	public void printTransaction() {
		dao.printTransaction();
	}

	public CustomerInfo find(int id) throws RecordNotFoundException {
		return dao.find(id);
	}

	@Override
	public boolean validateChoice1(String userChoice) {
		
		if (userChoice.matches(choicePattern1))
			return true;
		else

			return false;
	}
}

/*
 * public String createUserAccountNumber() { // String SALTCHARS = StringBuilder
 * account = new StringBuilder(); Random rnd = new Random(); while
 * (account.length() < 18) { // length of the random string. int index = (int)
 * (rnd.nextFloat() * userAccountNumber.length());
 * account.append(userAccountNumber.charAt(index)); } String accountNumber =
 * account.toString(); customer.setAccountNumber(accountNumber);
 * System.out.println(customer.getAccountNumber()); //
 * System.out.println(saltStr); return "Account Number is : " + accountNumber; }
 */