import java.time.LocalTime;
import java.time.temporal.ChronoUnit;


public class DemoLocalTime {

	public static void main(String[] args) {
		LocalTime now=LocalTime.now();
		System.out.println(now);
		
		LocalTime sixThirty =LocalTime.parse("06:30");
		System.out.println(sixThirty);
		
		LocalTime sixForty =LocalTime.of(6, 40);
		System.out.println(sixForty);
		
		LocalTime sevenThirty =LocalTime.parse("06:30").plus(1,ChronoUnit.HOURS);
		System.out.println(sevenThirty);
		
		System.out.println(LocalTime.parse("06:30").getHour());
		
		LocalTime maxTime =LocalTime.MAX;
		System.out.println(maxTime);
			

	}

}
