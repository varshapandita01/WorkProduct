import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Base64;
import java.util.Base64.Decoder;
import java.util.Base64.Encoder;


public class LoginEncodePassword {

	public static void main(String[] args) {
		private String username,password;
		
		String sql = "insert into login values(?,?)";
		
	

		Encoder encoder = Base64.getEncoder();
		String encodePassword = encoder.encodeToString(password.getBytes());

		//System.out.println(encodePassword);

		Decoder decoder = Base64.getDecoder();
		String decodePassword = new String(decoder.decode(encodePassword
				.getBytes()));

	//	System.out.println(decodePassword);
		
		
		Connection conn = null;
		try {
			conn = JdbcFactory.getConnection();
			PreparedStatement stmt = conn.prepareStatement(sql);
			// replacing placeholder with cmd line args values
			stmt.setString(1, args[0]);
			stmt.setInt(2, Integer.parseInt(args[1]));
			stmt.setString(3, args[2]);

			stmt.executeUpdate();
			System.out.println("Record Inserted...");
		}catch (SQLException e) {
			System.out.println("Connection Failed due to...");// optional
		} finally {
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {

					e.printStackTrace();
				}
			}
		}

	}

}


	}

}
