
public class FileInputDemo {

	public static void main(String[] args) {
		String path="link.txt";
	}

}
