import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;


public class SerializationDemo {

	public static void main(String[] args) throws  IOException, ClassNotFoundException {
		Person p=new Person("Polo", 21);
		System.out.println(p);
		
		String path="pers.dat";
		ObjectOutputStream ostream=null;
		ObjectInputStream istream=null;
		
		//Serialization code
				
		
		 ostream=new ObjectOutputStream(new FileOutputStream(path));
		ostream.writeObject(p);
		ostream.close();
		System.out.println("Object Serialized..........");
	
		//Deserialozation Code
		
		istream=new ObjectInputStream(new FileInputStream(path));
		Object obj=istream.readObject();//Deserialization object
		System.out.println(obj);
		istream.close();
	}

}
