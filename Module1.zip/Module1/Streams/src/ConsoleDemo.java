import java.io.Console;


public class ConsoleDemo {

	public static void main(String[] args) {
	Console console=System.console();
	System.out.println("Enter Name: ");
	String name =console.readLine();
	
	System.out.println("Your Name: "+name);
	}

}
