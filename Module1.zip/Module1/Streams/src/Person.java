import java.io.Serializable;

public class Person implements Serializable{
	private String name;
	private transient int age;//data will not be serialised for this variable transient

	public Person(String name, int age) {

		this.name = name;
		this.age = age;
	}

	public Person() {

	}

	@Override
	public String toString() {
		return "Name: " + name + "\tAge: " + age;
	}
}
