package com.insurance.dao;

import java.util.ArrayList;
import java.util.List;



import com.insurance.Exception.RecordNotFoundException;
import com.insurance.bike.BikeDetails;

public class InsuranceDaoClass implements InsuranceDaoInterface {
	List<BikeDetails> list = new ArrayList<>();

	@Override
	public void storeIntoList(BikeDetails bike) {

		list.add(bike);

	}

	@Override
	public List<BikeDetails> displayDetails() {

		return list;
	}
	

}