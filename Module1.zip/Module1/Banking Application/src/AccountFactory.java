public final class AccountFactory {
	private AccountFactory() {

		
	}

	public static Bank1 openAccount(String type, String holder) {
		Bank1 acnt = null;

		if (type.equalsIgnoreCase("current")) 
			acnt = new Current1(holder);

		 else
			acnt = new Savings1(holder);
		
		return acnt;
	
	
	}
}
