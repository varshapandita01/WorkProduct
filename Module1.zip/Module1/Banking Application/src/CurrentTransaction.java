
public class CurrentTransaction extends Transactions {
	protected double overDraft;
	public CurrentTransaction() {
			}
	public CurrentTransaction(String type, double amount, double balance,double overDraft) {
		super( type,  amount,  balance);
		this.overDraft = overDraft;
	}
	/*public void print() {
		System.out.println(type + "\t" + amount + "\t" + balance +"\t" +overDraft);

	}*/
	public String print() {
		return super.print()+"\t" +overDraft;

	}
}
