public class Current1 extends Account1 {
	private double overDraft;
	private static int CurrentCounter = INIT_CURRENT_ACNT;

	// public Current1(){}
	public Current1(String holder) {
		super(CurrentCounter++, holder, INIT_CURRENT_BALANCE);
		this.overDraft = OVERDRAFT_LIMIT;
		txns = new CurrentTransaction[10];

		txns[idx++] = new CurrentTransaction("CR", INIT_CURRENT_BALANCE, balance,overDraft);
	}

	@Override
	public void summary() {
		super.summary();
		System.out.println("overDraft::" + overDraft);
	}

	@Override
	public void deposit1(double amount) {
		overDraft += amount;
		if (overDraft > OVERDRAFT_LIMIT) {
			balance += (overDraft - OVERDRAFT_LIMIT);
			overDraft = OVERDRAFT_LIMIT;
			
		}
		txns[idx++] = new CurrentTransaction("CR", amount, balance,overDraft);
	}

	@Override
	public void withDraw1(double amount) throws BalancedException {
		if (amount <= (balance + overDraft)) {
			balance -= amount;
			if (balance < MIN_CURRENT_BALANCE) {
				overDraft += balance;
				balance = MIN_CURRENT_BALANCE;
				
			}
			txns[idx++] = new CurrentTransaction("DR", amount, balance,overDraft);
			}
			else {
				throw new BalancedException("Insuficient Funds!!!");
			}
		
	}
}
