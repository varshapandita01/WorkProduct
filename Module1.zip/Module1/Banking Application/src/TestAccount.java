public class TestAccount {

	public static void main(String[] args) {
		//AccountFactory factory=new AccountFactory();
	//	Bank1 s=factory.openAccount("savings"," holder");
		Bank1 s=new Savings1("Polo");
		try {
			//s.deposit1(2000);
			s.withDraw1(1001);
		} catch (BalancedException e) {
			// TODO Auto-generated catch block
		//	e.printStackTrace(); //developer --troubleShooting
			System.out.println(e.toString());//logging Purpose --Audit
			System.out.println(e.getMessage());//endUser
	
		}
		
	/*	Account1 s1 = new Savings1("PoLo");
		s1.deposit1(2000);
		s1.withDraw1(500);
		s1.deposit1(1500);
		s1.withDraw1(1200);
		s1.statement();*/
	//	s1.summary();

		/*Account1 c1 = new Current1("Lili");
		c1.withDraw1(3000);
		c1.withDraw1(5000);
		c1.deposit1(2000);
		c1.deposit1(4000);
		c1.statement();*/
		
		/*c1.withDraw1(3000);
		c1.withDraw1(5000);
		c1.summary();

		c1.deposit1(2000);
		c1.deposit1(4000);
		c1.summary();
*/	}

}
