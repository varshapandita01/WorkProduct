import java.util.Scanner;

class Account {
	int AccountNumber;
	String AccountHolder;
	double Balance;
}

class Savings extends Account {
	double Balance = 1000;

	void Deposit(double amount) {
		Balance = Balance + amount;
		System.out.println(Balance);
	}

	void withDraw(double amount) {
		if (Balance < amount && Balance < 1000) {
			System.out.println("insuficient Balance");
		} else {
			Balance = Balance - amount;
			System.out.println("Processing.....");
			System.out.println(Balance);
		}

	}

	void Summary() {
		Scanner scan = new Scanner(System.in);

		System.out.println("Do you Want to Print your Balance ");
		String choice = scan.next();
		if (choice.equalsIgnoreCase("YES")) {
			System.out.println("Your Balance is::" + Balance);
		}

	}
}

class Current extends Account {
	double OverDraft = 10000;
	double Balance = 1000;

	void Deposit(double amount) {

		if (OverDraft < 10000) {
			OverDraft += amount;
			System.out.println("OverDraft::::" + OverDraft);

		} else {
			Balance += amount;
			System.out.println("Balance:::" + Balance + "      OverDraft::::"
					+ OverDraft);
		}
	}

	void withDraw(double amount) {
		if (Balance > 0) {
			Balance -= amount;
		} else if (Balance == 0 && OverDraft > 0) {
			OverDraft -= amount;
		} else {
			System.out.println("Insufficient Balance");

		}
	}

	void Summary() {
		Scanner scan = new Scanner(System.in);

		System.out.println("Do you Want to Print your Balance ");
		String choice = scan.next();
		if (choice.equalsIgnoreCase("YES")) {
			System.out.println("Your Balance is::" + Balance);
		}

	}

}

public class Bank {
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.println("Eneter the choice");
		System.out.println("Savings OR CURREnt");
		String choice = scan.next();
		System.out.println("Enter your Amount");
		int Amount = scan.nextInt();
		if (choice.equalsIgnoreCase("Savings")) {
			Savings savings = new Savings();
			
			System.out.println("Eneter the choice");
			System.out.println("Deposit or WithDraw");
			String choice1 = scan.next();
			if (choice1.equalsIgnoreCase("Deposit")) {
				savings.Deposit(Amount);
			} else {
				savings.withDraw(Amount);
			}
		} else {
			Current current = new Current();
			System.out.println("Eneter the choice");
			System.out.println("Deposit or WithDraw");
			String choice1 = scan.next();
			if (choice1.equalsIgnoreCase("Deposit")) {
				current.Deposit(Amount);
			} else {
				current.withDraw(Amount);
			}
		}
	}
}