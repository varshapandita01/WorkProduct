public class Savings1 extends Account1 {
	private static int SavingCounter = INIT_SAVING_ACNT;

	// public Savings1(){}
	public Savings1(String holder) {
		super(SavingCounter++, holder, MIN_SAVING_BALANCE);
		txns = new Transactions[10];

		txns[idx++] = new Transactions("CR", MIN_SAVING_BALANCE, balance);
		/*
		 * Transactions txn=new
		 * Transactions("CR",MIN_SAVING_BALANCE,MIN_SAVING_BALANCE);
		 * txns[idx]=txn; idx++;
		 */// BOTH ARE DOING SAME THING
	}

	@Override
	public void deposit1(double amount) {
		balance += amount;
		txns[idx++] = new Transactions("CR", amount, balance);
	}

	@Override
	public void withDraw1(double amount) throws BalancedException {
		if (amount <= balance) {
			balance -= amount;
			txns[idx++] = new Transactions("DR", amount, balance);
		} else {
			throw new BalancedException("Insuficient Funds!!!");
		}
	}
}