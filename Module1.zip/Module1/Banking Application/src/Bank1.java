public interface Bank1 {
	void deposit1(double amount);

	void withDraw1(double amount) throws BalancedException;

	void summary();

	void statement();
	// constants
	int INIT_SAVING_ACNT = 1001;// by default "public static final" as in
								// interface
	int INIT_CURRENT_ACNT = 2001;
	double MIN_SAVING_BALANCE = 1000;
	double INIT_CURRENT_BALANCE = 5000;
	double MIN_CURRENT_BALANCE = 0;
	double OVERDRAFT_LIMIT = 10000;

}
