public abstract class Account1 implements Bank1 {
	private int acntNo;
	private String holder;
	protected double balance;

	protected Transactions[] txns;
	protected  int idx;
	//protected CurrentTransaction[] Ctxn;
	@Override
	public void statement() {
		System.out.println("Statement of A/C: "+acntNo);
		for(int i=0;i<idx;i++){
			System.out.println(txns[i].print());
		}
	}

	public Account1() {
	}

	public Account1(int acntNo, String holder, double balance) {
		this.acntNo = acntNo;
		this.holder = holder;
		this.balance = balance;

	}

	public void summary() {
		System.out.println("AccountNo::" + acntNo);
		System.out.println("Holder::" + holder);
		System.out.println("balance::" + balance);
	}
}
