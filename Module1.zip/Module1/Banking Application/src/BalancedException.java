
public class BalancedException extends Exception {

	public BalancedException() {
		
		
	}

	public BalancedException(String message) {
		super(message);
		
	}

}
