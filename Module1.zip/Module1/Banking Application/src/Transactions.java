public class Transactions {
	protected String type;
	protected double amount;
	protected double balance;

	public Transactions() {

	}

	public Transactions(String type, double amount, double balance) {
		this.type = type;
		this.amount = amount;
		this.balance = balance;

	}

	/*public void print() {
		System.out.println(type + "\t" + amount + "\t" + balance);

	}*/

	
	public String print() {
		return type + "\t" + amount + "\t" + balance ;

	}
}

