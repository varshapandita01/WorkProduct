package com.capgemini.xyz.bean;

import java.sql.SQLException;
import java.util.Map;

import com.capgemini.test.bean.Person;
import com.capgemini.test.exception.RecordNotFoundException;
import com.capgemini.xyz.dao.*;

;

public class Customer implements CustomerInterface {

	@Override
	public boolean validateUserName(String setCustName) {
		if (setCustName.matches(userNamePattern))
			return true;
		else
			return false;
	}

	DaoClass dao = new DaoClass();

	@Override
	public boolean validateUserAge(String setCustAge) {
		if (setCustAge.matches(userAgePattern)
				&& Integer.parseInt(setCustAge) >= 22)
			return true;
		else

			return false;
	}

	@Override
	public boolean validateEmail(String setEmail) {
		if (setEmail.matches(userEmailPattern))
			return true;
		else

			return false;
	}

	@Override
	public boolean validateAddress(String setAddress) {
		if (setAddress.matches(userAddressPattern))
			return true;
		else

			return false;
	}

	@Override
	public boolean validateChoice(String setChoice) {
		if (setChoice.matches(choicePattern))
			return true;
		else
			return false;
	}

	/*public void storeIntoMap(Person person) {
		dao.storeIntoMap(person);
	}*/

	public Map<Integer, Person> displayPersons() {

		return dao.displayPersons();
	}

	public String display() {
		return dao.display();
	}

	public Person find(int id) throws RecordNotFoundException {
		return dao.find(id);
	}
	JdbcDaoClass jdbcdao=new JdbcDaoClass();
	
	public void storeIntoMap(Person person) throws ClassNotFoundException, RecordNotFoundException, SQLException {
		jdbcdao.storeIntoMap(person);
	}
}
