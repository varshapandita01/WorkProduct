package com.capgemini.xyz.bean;

import java.sql.SQLException;
import java.util.Map;

import com.capgemini.test.bean.Person;
import com.capgemini.test.exception.RecordNotFoundException;



public interface CustomerInterface {
	String userNamePattern="[A-Z][a-z]{1,}";
	String userAgePattern="[0-9]{2}";
	String userAddressPattern="[A-Z a-z 0-9]{1,35}";
	String userEmailPattern="[A-Za-z]{4,}[@]{1}[A-Za-z]{3,15}[.]{1}[A-Z a-z]{2,4}";
	String choicePattern="[1-2]{1}";
	boolean validateUserName(String userNamePattern);
	boolean validateUserAge(String userAgePattern);
	boolean validateEmail(String userEmailPattern);
	boolean validateAddress(String userAddressPattern);
	void storeIntoMap(Person person)throws ClassNotFoundException, RecordNotFoundException, SQLException ;
	boolean validateChoice(String userChoice);
	//public abstract
	Map<Integer,Person> displayPersons();
}
