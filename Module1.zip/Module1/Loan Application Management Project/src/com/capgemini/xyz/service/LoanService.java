package com.capgemini.xyz.service;

import java.util.Map;

import com.capgemini.test.bean.Person;
import com.capgemini.xyz.bean.Customer;
import com.capgemini.xyz.bean.Loan;
import com.capgemini.xyz.dao.LoanDao;

public class LoanService implements ILoanService{
	LoanDao loandao=new LoanDao();
	@Override
	public void applyLoan(Loan loan) {
		
		 loandao.applyLoan(loan);
	}
public Map<Integer, Loan> displayLoan() {
		
		return loandao.displayLoan();
	}

public String display() {
		return loandao.display();
	}
	@Override
	public Customer validateCustomer(Customer customer) {
		
		return customer;
	}

	@Override
	public long insertCust(Customer cust) {
		
		return 0;
	}

	@Override
	public double calculateEMI(int amount, int duration) {
		double r=9.5/(12*100);
		//double r1=1+r;
		//p*r*(1+r)^n/(1+r)^n-1
		double emiPerMonth = ((amount*r*(Math.pow((1+r), (duration*12))))/(Math.pow((1+r), (duration*12) - 1)));
		return emiPerMonth;
	}

	@Override
	public boolean validateCustomerLoan(String userLoanValidation) {
		if(userLoanValidation.matches(amount))
		return true;
		else
		return false;
	}

	@Override
	public boolean validateCustomerLoanTime(String userLoanValidationTime) {
		if(userLoanValidationTime.matches((duration)))
			return true;
			else
		return false;
	}


	
	
	
	
	
	
	

}
