package com.capgemini.xyz.service;

import com.capgemini.xyz.bean.Customer;
import com.capgemini.xyz.bean.Loan;

public interface ILoanService {
	public void applyLoan (Loan loan);
	public Customer validateCustomer(Customer customer);
	public long insertCust(Customer cust);
	public double calculateEMI(int amount,int duration);
	
	String amount="[0-9]{2,10}";
	boolean validateCustomerLoan(String userLoanValidation);
	String duration="[0-9]{1,2}";
	boolean validateCustomerLoanTime(String userLoanValidationTime);

}
