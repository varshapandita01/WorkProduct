package com.capgemini.xyz.dao;

import java.util.HashMap;
import java.util.Map;

import com.capgemini.test.bean.Person;
import com.capgemini.xyz.bean.Customer;
import com.capgemini.xyz.bean.Loan;

public class LoanDao implements ILoanDao {
	private Map<Integer, Loan> loans = new HashMap<>();

	@Override
	public  void applyLoan(Loan loan) {
		int key=(int)(Math.random() * 1000);
		loans.put( key, loan);
		System.out.println("Your Loan request is generated. ");
		System.out.println("Your Loan ID is " +loans.keySet());
	//	return "Your Loan ID is " +loans.keySet();
	}

	public Map<Integer,Loan>displayLoan(){
		return loans;
		
		
	}

	@Override
	public long insertCust(Customer cust) {

		return 0;
	}

	public String display() {
		System.out.println("Customer Loan Applied successfully.");
		return "YOUR Loan ID IS:: " + loans.keySet();

	}

}
