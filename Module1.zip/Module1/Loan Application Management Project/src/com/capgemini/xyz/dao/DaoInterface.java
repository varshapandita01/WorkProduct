package com.capgemini.xyz.dao;

import java.sql.SQLException;
import java.util.Map;

import com.capgemini.test.bean.Person;
import com.capgemini.test.exception.RecordNotFoundException;

public interface DaoInterface {
	
	void storeIntoMap(Person person)throws RecordNotFoundException,ClassNotFoundException,SQLException;
	Map<Integer, Person> displayPersons();
	Person find(int id) throws RecordNotFoundException;
}
