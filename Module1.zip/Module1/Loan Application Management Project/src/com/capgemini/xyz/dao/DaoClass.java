package com.capgemini.xyz.dao;

import java.util.HashMap;
import java.util.Map;

import com.capgemini.test.bean.Person;
import com.capgemini.test.exception.RecordNotFoundException;

public class DaoClass implements DaoInterface {
	private Map<Integer, Person> persons = new HashMap<>();

	@Override
	public void storeIntoMap(Person person) {
		int key=(int)(Math.random()*1000);
		person.setCustomerId(key);
		persons.put(key, person);
	}

	public Map<Integer, Person> displayPersons(){
		return persons;
		
		
	}
public String display(){
	System.out.println("Customer information saved successfully.");
	return "YOUR CUSTOMER ID IS:: "+persons.keySet();
	
} 
public Person find(int id) throws RecordNotFoundException {
	Person p=persons.get(id);
	if(p!=null){
	return p;
	}
	else{
		throw new RecordNotFoundException("Record Not Found");
	}
}

}
