package com.capgemini.xyz.dao;

import java.util.HashMap;
import java.util.Map;

import com.capgemini.xyz.bean.Customer;
import com.capgemini.xyz.bean.Loan;

public interface ILoanDao {
		Map<Double,Customer> customerEntry=new HashMap<>();
	 Map<Double,Loan> loanEntry=new HashMap<>();

	public void applyLoan (Loan loan);
	public  long insertCust(Customer cust);

}
