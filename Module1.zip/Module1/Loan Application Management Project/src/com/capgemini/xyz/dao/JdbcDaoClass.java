package com.capgemini.xyz.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Map;
import java.util.logging.Logger;

import com.capgemini.test.bean.Person;
import com.capgemini.test.exception.RecordNotFoundException;
import com.capgemini.xyz.utility.JdbcUtil;


public class JdbcDaoClass implements DaoInterface{
//	static Logger logger = Logger.getLogger(DaoClass.class);
	
	/**
	 * method name : insertCustomerDetail argument : CabRequest class object return
	 * type : int author : Capgemini date : 19-02-2019
	 * 
	 * description : This method will take the CabRequest Class(in bean package)
	 * object as an argument and returns the generated id to the user
	 * @throws ClassNotFoundException 
	 */
@Override
	public void storeIntoMap(Person person)
			throws RecordNotFoundException, ClassNotFoundException, SQLException {
		

	Connection connection = null;
	PreparedStatement statement = null;


		
		connection = JdbcUtil.getConnection();
		

		
		try {
			statement = 
					connection.prepareStatement
					(QueryMapper.insertDetails);
		
			int key=(int)(Math.random()*1000);
			person.setCustomerId(key);
			statement.setInt(1, person.getCustomerId());
			statement.setString(2, person.getName());
			statement.setInt(3, person.getAge());
			statement.setString(4, person.getAddress());
			statement.setString(5, person.getEmail());
			//statement.setString(6, person.);

			statement.executeUpdate();
			

			
		} catch (SQLException e) {
			System.err.println("Unable to fetch data" + e);
			
		} finally {

			try {
				statement.close();
			} catch (SQLException e) {
			
				throw new RecordNotFoundException("unable to close statement object");
			}

			try {
				connection.close();
			} catch (SQLException e) {
			
				throw new RecordNotFoundException("unable to close connection object");
			}
		}

		
	}

	@Override
	public Map<Integer, Person> displayPersons() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Person find(int id) throws RecordNotFoundException {
		// TODO Auto-generated method stub
		return null;
	}
}
