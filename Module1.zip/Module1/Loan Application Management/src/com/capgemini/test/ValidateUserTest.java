package com.capgemini.test;



import junit.framework.Assert;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;





import com.capgemini.test.bean.Person;
import com.capgemini.test.exception.RecordNotFoundException;
import com.capgemini.xyz.dao.DaoClass;

public class ValidateUserTest {

		DaoClass dao=null;
		@Before
		public void setUp() throws Exception {

			dao= new DaoClass();
		}
		@After
		public void tearDown() throws Exception {
			dao = null;
		}
		@Test
		public void testValidCustomerDetails() {
			Person cust=new Person();
			Person requestCust=new Person();
			cust.setAddress("Mumbai");
			cust.setAge(24);
			cust.setName("Varsha");
			cust.setEmail("vars@gmnss.com");
			dao.storeIntoMap(cust);
			int id=cust.getCustomerId();
			try{
				requestCust=dao.find(id);
				Assert.assertNotNull(requestCust);
				System.out.println("Test Case Passed");
				
			}
			catch(RecordNotFoundException e){
				System.out.println(e);
			}
		}
		@Test
		public void testInvalidCustomerDetails() {
			Person cust=new Person();
			Person requestCust=new Person();
			cust.setAddress("Mumbai");
			cust.setAge(24);
			cust.setName("Varsha");
			cust.setEmail("vars@gmnss.com");
			dao.storeIntoMap(cust);
			//int id=cust.getCustomerId();
			try{
				requestCust=dao.find(32);
				Assert.assertNotNull(requestCust);
				System.out.println("Test Case Passed");
				
			}
			catch(RecordNotFoundException e){
				System.out.println(e);
			}
		}
		
		

	
	
}
