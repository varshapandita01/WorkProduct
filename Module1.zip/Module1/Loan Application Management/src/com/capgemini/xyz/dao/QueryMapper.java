package com.capgemini.xyz.dao;

public interface QueryMapper {
	String insertDetails =
			"insert into person_details"
			+ "(cust_ID,customer_name,"
			+ "age,address,"
			+ "email)"
			+ " values"
			+ "(?,?,?,?,?)";;
			
		/*	Insert into patient values
			(124,�patient 2�,13,9898989898,�unwell�,sysdate
		*/	
			
			
			
			
			
			
			
			
	String selectcustomerId = "select * from person_details where cust_ID=?";
}
