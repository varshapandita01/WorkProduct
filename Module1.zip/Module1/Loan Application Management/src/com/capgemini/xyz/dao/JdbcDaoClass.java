package com.capgemini.xyz.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Map;
import java.util.logging.Logger;

import com.capgemini.test.bean.Person;
import com.capgemini.test.exception.RecordNotFoundException;
import com.capgemini.xyz.utility.JdbcUtil;


public class JdbcDaoClass implements DaoInterface{
//	static Logger logger = Logger.getLogger(DaoClass.class);

	Connection connection = null;
	PreparedStatement statement = null;

	/**
	 * method name : insertCustomerDetail argument : CabRequest class object return
	 * type : int author : Capgemini date : 19-02-2019
	 * 
	 * description : This method will take the CabRequest Class(in bean package)
	 * object as an argument and returns the generated id to the user
	 * @throws ClassNotFoundException 
	 */
@Override
	public void storeIntoMap(Person person)
			throws RecordNotFoundException, ClassNotFoundException, SQLException {
		


		
		connection = JdbcUtil.getConnection();
		

		
		try {
			statement = 
					connection.prepareStatement
					(QueryMapper.insertDetails);
		
			int key=(int)(Math.random()*1000);
			person.setCustomerId(key);
			statement.setInt(1, person.getCustomerId());
			statement.setString(2, person.getName());
			statement.setInt(3, person.getAge());
			statement.setString(4, person.getAddress());
			statement.setString(5, person.getEmail());
			//statement.setString(6, person.);

			statement.executeUpdate();
			

			
		} catch (SQLException e) {
			System.err.println("Unable to fetch data" + e);
			
		} finally {

			/*try {
				statement.close();
			} catch (SQLException e) {
			
				throw new RecordNotFoundException("unable to close statement object");
			}

			try {
				connection.close();
			} catch (SQLException e) {
			
				throw new RecordNotFoundException("unable to close connection object");
			}*/
		}

		
	}

	@Override
	public Map<Integer, Person> displayPersons() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Person find(int id) throws RecordNotFoundException {
		// TODO Auto-generated method stub
		return null;
	}
	
	public Person displayresult (int custID) throws SQLException, RecordNotFoundException {
	Person Cust=new Person();
	try{
		statement = 
				connection.prepareStatement
				(QueryMapper.selectcustomerId);
		statement.setInt(1,custID);
		ResultSet resultSet = statement.executeQuery();
		if(resultSet.next())//takes the record pointer to the first row and then on  next  row
		Cust.setCustomerId(resultSet.getInt(1));
		Cust.setName(resultSet.getString(2));
		Cust.setAge(resultSet.getInt(3));
		Cust.setAddress(resultSet.getString(4));
		Cust.setEmail(resultSet.getString(5));
		
		
		//String var = Rs.getstring(2);
		

	}


	catch (SQLException e) {
		System.err.println("Unable to fetch data" + e);
		
	} finally {

		try {
			statement.close();
		} catch (SQLException e) {
		
			throw new RecordNotFoundException("unable to close statement object");
		}

		try {
			connection.close();
		} catch (SQLException e) {
		
			throw new RecordNotFoundException("unable to close connection object");
		}
	}


		return Cust;
		
	}
}
