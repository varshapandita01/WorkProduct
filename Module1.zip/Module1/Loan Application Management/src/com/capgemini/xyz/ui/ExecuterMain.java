package com.capgemini.xyz.ui;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.sql.SQLException;
import java.util.Scanner;

import com.capgemini.test.bean.Person;
import com.capgemini.test.exception.RecordNotFoundException;
import com.capgemini.xyz.bean.Customer;
import com.capgemini.xyz.bean.Loan;
import com.capgemini.xyz.service.LoanService;

public class ExecuterMain {

	public static void main(String[] args) {
		System.out.println("XYZ Finance Company welcomes you");
		Scanner scan = new Scanner(System.in);
		System.out.println("1. REGISTER");
		System.out.println("2. EXIT");
		
		
		//BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		

			Customer service = new Customer();
			String Choice;
			while(true){
				System.out.println("ENTER YOUR CHOICE:: 1->REGISTER  2->EXIT");
			
			 Choice = scan.next();
			boolean isValid = service.validateChoice(Choice);
			if (isValid)
				break;
			
			else{
				System.out.println("Your have taken Wrong choice");
			}
			}
			// service.test();//error
			String name;
			if (Choice.equalsIgnoreCase("1")) {
			while (true) {

				System.out.println("REGISTER HERE");
				System.out.println("Enter Customer Name");
				name = scan.next();

				boolean isValid = service.validateUserName(name);
				if (isValid)
					break;
				else
					System.out.println("Customer Name should have atmost 10 letters and first letter must be Capital");
			}
			String age;

			while (true) {

				System.out.println(" Enter AGE");
				age = scan.next();

				boolean isValid = service.validateUserAge(age);
				if (isValid)
					break;
				else
					System.out.println("Age above 22  is valid");
			}
			
			
			String address;
			
			while (true) {

				System.out.println(" Enter Address");
				address = scan.next();

				boolean isValid = service.validateAddress(address);
				if (isValid)
					break;
				else
					System.out.println("Max 35 Characters");
			}
			

			String email;
			while (true) {

				System.out.println("Enter Email");
				email = scan.next();

				boolean isValid = service.validateEmail(email);
				if (isValid)
					break;
				else
					System.out.println("EmailID should have 1 @ and . abd letters before @must not less than  4");
			}

			Person person = new Person();
			person.setAge(Integer.parseInt(age));
			person.setName(name);
			person.setAddress(address);
			person.setEmail(email);

			try {
				service.storeIntoMap(person);
			} catch (ClassNotFoundException | RecordNotFoundException
					| SQLException e1) {
				// TODO Auto-generated catch block
			//System.out.println(e);
			}
			System.out.println(person.getCustomerId());
			try {
				System.out.println(service.displayresult(person.getCustomerId()));
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			} catch (RecordNotFoundException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			//System.out.println(service.displayPersons());

			//System.out.println(service.display());
			
			
			String Choice1;
			while(true){
				System.out.println("Do you Wish To Apply for Loan::");
				System.out.println("ENTER YOUR CHOICE:: 1->Yes  2->No");
			  Choice1 = scan.next();
				boolean isValid = service.validateChoice(Choice1);
				if (isValid)
					break;
				
				else{
					System.out.println("Your have taken Wrong choice");
				}
				}
			
			
			
			
			
			if (Choice1.equalsIgnoreCase("1")) {
				LoanService loanService=new LoanService();
				
				
				String amount;
				String loanDuration;
				while (true) {

					System.out.println("Enter the loan amount");
					 amount=scan.next();
					boolean isValid = loanService.validateCustomerLoan(amount);
					if (isValid)
						break;
					else
						System.out.println("Loan Amount is not Limit");
				}
				
				while (true) {

					System.out.println("Enter the loan duration");
					loanDuration=scan.next();
					boolean isValid = loanService.validateCustomerLoanTime(loanDuration);
					if (isValid)
						break;
					else
						System.out.println("Loan Duration is not Limit");
				}
				
			
				System.out.println(loanService.calculateEMI(Integer.parseInt(amount), Integer.parseInt(loanDuration)));
				
				
				String Choice3;
				while(true){
					System.out.println("Do you wish to apply for Loan");
					System.out.println("1.YEs 2. No");
				  Choice3 = scan.next();
					boolean isValid = service.validateChoice(Choice1);
					if (isValid)
						break;
					
					else{
						System.out.println("Your have taken Wrong choice");
					}
					}
				
				
					if(Choice3.equalsIgnoreCase("1")){
					Loan l1=new Loan();
					l1.setLoanAmount(Integer.parseInt(amount));
					l1.setDuration(Integer.parseInt(loanDuration));
					loanService.applyLoan(l1);
					System.out.println(loanService.displayLoan());
					System.out.println("CustomerDetails:");
					System.out.println(service.displayPersons());
					
					System.out.println(loanService.display());
					
					
					System.out.println("Enter Custmor Id");
					int id=scan.nextInt();
					try {
						System.out.println(service.find(id));
					} catch (RecordNotFoundException e) {
						System.out.print(e.getMessage());
					}
					
					
					
				}
				else{
					System.out.println(service.displayPersons());
					System.out.println("Thanks For Visiting");
					System.exit(0);
				}
			} else {
				System.out.println(service.display());
				System.out.println("Thanks for visiting and Registering....");
				System.exit(0);
			}

		} else {
			System.out.println("Thanks for Visiting....");
			System.exit(0);
		}
	}

}
