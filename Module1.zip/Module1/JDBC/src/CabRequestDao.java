package com.capgemini.cab.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Logger;

import com.capgemini.cabs.bean.CabRequest;
import com.capgemini.cabs.exception.CRAException;

import com.capgemini.cab.utility.JdbcUtility;

public class CabRequestDao implements ICabRequestDao {

	static Logger logger = Logger.getLogger(CabRequestDao.class);
	Connection connection = null;
	PreparedStatement statement = null;

	/**
	 * method name : insertCustomerDetail argument : CabRequest class object return
	 * type : int author : Capgemini date : 19-02-2019
	 * 
	 * description : This method will take the CabRequest Class(in bean package)
	 * object as an argument and returns the generated id to the user
	 */
	@Override
	public int insertCustomerDetail(CabRequest cabRequest1)
			throws CRAException {
		

		

		
		connection = JdbcUtil.getConnection();
		

		
		try {
			statement = 
					connection.prepareStatement
					(QuerryMapper.insertDetails);
		

			statement.setString(1, cabRequest1.getCustName());
			statement.setString(2, cabRequest1.getPhoneNo());
			statement.setString(3, requestStatus);
			statement.setString(4, cabNumber);
			statement.setString(5, cabRequest1.getAddress());
			statement.setString(6, cabRequest1.getPincode());

			statement.executeUpdate();
			

			
		} catch (SQLException e) {
			System.err.println("Unable to fetch data" + e);
			
		} finally {

			try {
			
			} catch (SQLException e) {
			
				throw new CRAException("unable to close resultset object");
			}

			try {
				statement.close();
			} catch (SQLException e) {
			
				throw new CRAException("unable to close statement object");
			}

			try {
				connection.close();
			} catch (SQLException e) {
			
				throw new CRAException("unable to close connection object");
			}
		}

		return generatedId;
	}
}
