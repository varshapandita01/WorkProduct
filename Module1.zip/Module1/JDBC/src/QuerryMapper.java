package com.capgemini.cab.dao;

public interface QuerryMapper {

	String insertDetails =
			"insert into cab_request"
			+ "(request_id,customer_name,phone_number,"
			+ "date_of_request,request_status,"
			+ "cab_number,address_of_pickup,pincode)"
			+ " values"
			+ "(seq_request_id.nextval,?,?,sysdate,?,?,?,?)";;
			
		/*	Insert into patient values
			(124,�patient 2�,13,9898989898,�unwell�,sysdate
		*/	
			
			
			
			
			
			
			
			
	String selectGeneratedId = "select seq_request_id.CURRVAL from dual";
}
