package com.insurance.Service;

import java.util.List;

import com.insurance.bike.BikeDetails;

public interface InsuranceServiceInterface {
	double depraciatePrice(double bikePrice, int bikeYear);

	double compensationInsurance(double depriciatedPrice);

	double thirdPartyInsurance(double depriciatedPrice);

	void storeIntoList(BikeDetails bike);

	List<BikeDetails> displayDetails();
}
