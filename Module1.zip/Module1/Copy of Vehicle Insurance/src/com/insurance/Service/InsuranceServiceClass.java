package com.insurance.Service;

import java.util.List;


import com.insurance.bike.BikeDetails;
import com.insurance.dao.InsuranceDaoClass;

public class InsuranceServiceClass implements InsuranceServiceInterface {
	InsuranceDaoClass dao = new InsuranceDaoClass();

	@Override
	public double depraciatePrice(double bikePrice, int bikeYear) {
		int presentYear = 2019;
		int year = presentYear - bikeYear;
		double depreciatedPrice = 0;
		if (year <= 3) { // if year differnce is less than or equal 3 then 5%
							// depriciation
			depreciatedPrice = (5 * year * bikePrice) / 100;
			depreciatedPrice = bikePrice - depreciatedPrice;
		} else {// if year differnce is greater than 3 then 5% for 3yr and 10%
				// for remaining depriciation
			depreciatedPrice = (5 * 3 * bikePrice) / 100;

			if (year > 3) {
				year = year - 3;
				depreciatedPrice += (10 * year * bikePrice) / 100;
			}
			depreciatedPrice = bikePrice - depreciatedPrice;
		}
		/*
		 * switch (year) { case 1: depreciatedPrice = (5 * bikePrice) / 100;
		 * depreciatedPrice = bikePrice - depreciatedPrice; break; case 2:
		 * depreciatedPrice = (5 * 5 * bikePrice) / 100; depreciatedPrice =
		 * bikePrice - depreciatedPrice; break; case 3: depreciatedPrice = (5 *
		 * 5 * 5 * bikePrice) / 100; depreciatedPrice = bikePrice -
		 * depreciatedPrice; break; case 4: depreciatedPrice = (5 * 5 * 5 * 10 *
		 * bikePrice) / 100; depreciatedPrice = bikePrice - depreciatedPrice;
		 * break; case 5: depreciatedPrice = (5 * 5 * 5 * 10 * 10 * bikePrice) /
		 * 100; depreciatedPrice = bikePrice - depreciatedPrice; break; default:
		 * break; }
		 */
		return depreciatedPrice;

	}

	@Override
	public double compensationInsurance(double depriciatedPrice) {
		double comprehensivePrice = 0;
		comprehensivePrice = (5 * depriciatedPrice) / 100;// if compensation
															// then 5%
		return comprehensivePrice;
	}

	@Override
	public double thirdPartyInsurance(double depriciatedPrice) {
		double thirdPartyPrice = 0;
		thirdPartyPrice = (3 * depriciatedPrice) / 100;// if thirdParty then 3%
		return thirdPartyPrice;
	}

	@Override
	public void storeIntoList(BikeDetails bike) {
		dao.storeIntoList(bike); // store value in map

	}

	@Override
	public List<BikeDetails> displayDetails() {

		return dao.displayDetails();// display Final Details
	}


}
