package com.insurance.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.insurance.bike.BikeDetails;

public class InsuranceDaoClass implements InsuranceDaoInterface {
	List<BikeDetails> list = new ArrayList<>();
	Map<Integer, String> map=new HashMap<Integer, String>();
	public Map<Integer,String> BikeName() {
		map.put(1, "KTM250");
		map.put(2, "Pulsar220");
		map.put(3, "CBR250");
		map.put(4, "Unicorn150");
		map.put(5, "Splendor220");
		return map;
	}
	@Override
	public void storeIntoList(BikeDetails bike) {

		list.add(bike);

	}

	@Override
	public List<BikeDetails> displayDetails() {

		return list;
	}

}
