package com.insurance.dao;

import java.util.ArrayList;
import java.util.List;

import com.insurance.bike.BikeDetails;

public interface InsuranceDaoInterface {
	List<BikeDetails> list=new ArrayList<>();
	void storeIntoList(BikeDetails bike);
	List<BikeDetails> displayDetails();
}
