package com.insurance.UI;

import java.io.BufferedReader;
import java.util.Scanner;

import com.insurance.Service.InsuranceServiceClass;
import com.insurance.bike.BikeDetails;

public class ExecuteMainUi {

	public static void main(String[] args) {
		InsuranceServiceClass insurance = new InsuranceServiceClass();
		BikeDetails bike = new BikeDetails();
		Scanner scan = new Scanner(System.in);
		System.out.println("1. KTM250");
		System.out.println("2. Pulsar220");
		System.out.println("3. CBR150");
		System.out.println("4. Unicorn150");
		System.out.println("5. Splendor220");
		System.out.println("Enter Bike Name:");
		String bikeChoice = scan.next();// choice for bike Name
		switch (bikeChoice) {
		case "KTM250":
			bike.setBikeName(bikeChoice);// set BikeName
			double bikePrice = 150000;
			bike.setBikePrice(bikePrice);// setBike Price
			System.out.println("Enter the Year bike is bought");
			int bikeYear = scan.nextInt();
			bike.setBikeYear(bikeYear);
			double depriciatedPrice = insurance.depraciatePrice(bikePrice,
					bikeYear); // implement Depriciation
			System.out
					.println("Depriciated Bike Price is: " + depriciatedPrice);
			bike.setDepreciatedBikePrice(depriciatedPrice);
			double comprehensivePrice = insurance
					.compensationInsurance(depriciatedPrice);// implement
																// compensation
																// Insurance
			System.out.println("Compensation Insurance Price is: "
					+ comprehensivePrice);
			// bike.setComprehensivePrice(comprehensivePrice);
			double thirdPartyPrice = insurance
					.thirdPartyInsurance(depriciatedPrice);// implement
															// thirdParty
															// Insurance
			System.out.println("ThirdParty Insurance is: " + thirdPartyPrice);
			// bike.setThirdPartyPrice(thirdPartyPrice);
			System.out
					.println("Do you want to go for CompensationInsurance or ThirdParty::");
			String choice = scan.next();
			if (choice.equalsIgnoreCase("CompensationInsurance")) {
				bike.setFinalInsurancePrice(comprehensivePrice);
				insurance.storeIntoList(bike);
				System.out.println(insurance.displayDetails());

			} else {
				bike.setFinalInsurancePrice(thirdPartyPrice);
				insurance.storeIntoList(bike);
				System.out.println(insurance.displayDetails());
			}
			break;
		case "Pulsar220":
			bike.setBikeName(bikeChoice);// set BikeName
			bikePrice = 120000;
			bike.setBikePrice(bikePrice);// setBike Price
			System.out.println("Enter the Year bike is bought");
			bikeYear = scan.nextInt();
			bike.setBikeYear(bikeYear);
			depriciatedPrice = insurance.depraciatePrice(bikePrice, bikeYear);
			bike.setDepreciatedBikePrice(depriciatedPrice);
			comprehensivePrice = insurance
					.compensationInsurance(depriciatedPrice);
			System.out.println("Compensation Insurance Price is: "
					+ comprehensivePrice);
			// bike.setComprehensivePrice(comprehensivePrice);
			thirdPartyPrice = insurance.thirdPartyInsurance(depriciatedPrice);
			System.out.println("ThirdParty Insurance is: " + thirdPartyPrice);
			System.out
					.println("Do you want to go for CompensationInsurance or ThirdParty::");
			choice = scan.next();
			if (choice.equalsIgnoreCase("CompensationInsurance")) {
				bike.setFinalInsurancePrice(comprehensivePrice);
				insurance.storeIntoList(bike);
				System.out.println(insurance.displayDetails());
			} else {
				bike.setFinalInsurancePrice(thirdPartyPrice);
				insurance.storeIntoList(bike);
				System.out.println(insurance.displayDetails());
			}
			break;
		case "CBR250":
			bike.setBikeName(bikeChoice);// set BikeName
			bikePrice = 110000;
			bike.setBikePrice(bikePrice);// setBike Price
			System.out.println("Enter the Year bike is bought");
			bikeYear = scan.nextInt();
			bike.setBikeYear(bikeYear);
			depriciatedPrice = insurance.depraciatePrice(bikePrice, bikeYear);
			bike.setDepreciatedBikePrice(depriciatedPrice);
			comprehensivePrice = insurance
					.compensationInsurance(depriciatedPrice);
			System.out.println("Compensation Insurance Price is: "
					+ comprehensivePrice);
			// bike.setComprehensivePrice(comprehensivePrice);
			thirdPartyPrice = insurance.thirdPartyInsurance(depriciatedPrice);
			System.out.println("ThirdParty Insurance is: " + thirdPartyPrice);
			System.out
					.println("Do you want to go for CompensationInsurance or ThirdParty::");
			choice = scan.next();
			if (choice.equalsIgnoreCase("CompensationInsurance")) {
				bike.setFinalInsurancePrice(comprehensivePrice);
				insurance.storeIntoList(bike);
				System.out.println(insurance.displayDetails());
			} else {
				bike.setFinalInsurancePrice(thirdPartyPrice);
				insurance.storeIntoList(bike);
				System.out.println(insurance.displayDetails());
			}
			break;
		case "Unicorn250":
			bike.setBikeName(bikeChoice);// set BikeName
			bikePrice = 90000;
			bike.setBikePrice(bikePrice);// setBike Price
			System.out.println("Enter the Year bike is bought");
			bikeYear = scan.nextInt();
			bike.setBikeYear(bikeYear);
			depriciatedPrice = insurance.depraciatePrice(bikePrice, bikeYear);
			bike.setDepreciatedBikePrice(depriciatedPrice);
			comprehensivePrice = insurance
					.compensationInsurance(depriciatedPrice);
			System.out.println("Compensation Insurance Price is: "
					+ comprehensivePrice);
			// bike.setComprehensivePrice(comprehensivePrice);
			thirdPartyPrice = insurance.thirdPartyInsurance(depriciatedPrice);
			System.out.println("ThirdParty Insurance is: " + thirdPartyPrice);
			System.out
					.println("Do you want to go for CompensationInsurance or ThirdParty::");
			choice = scan.next();
			if (choice.equalsIgnoreCase("CompensationInsurance")) {
				bike.setFinalInsurancePrice(comprehensivePrice);
				insurance.storeIntoList(bike);
				System.out.println(insurance.displayDetails());
			} else {
				bike.setFinalInsurancePrice(thirdPartyPrice);
				insurance.storeIntoList(bike);
				System.out.println(insurance.displayDetails());
			}
			break;
		case "Splendor220":
			bike.setBikeName(bikeChoice);// set BikeName
			bikePrice = 60000;
			bike.setBikePrice(bikePrice);// setBike Price
			System.out.println("Enter the Year bike is bought");
			bikeYear = scan.nextInt();
			bike.setBikeYear(bikeYear);
			depriciatedPrice = insurance.depraciatePrice(bikePrice, bikeYear);
			bike.setDepreciatedBikePrice(depriciatedPrice);
			comprehensivePrice = insurance
					.compensationInsurance(depriciatedPrice);
			System.out.println("Compensation Insurance Price is: "
					+ comprehensivePrice);
			// bike.setComprehensivePrice(comprehensivePrice);
			thirdPartyPrice = insurance.thirdPartyInsurance(depriciatedPrice);
			System.out.println("ThirdParty Insurance is: " + thirdPartyPrice);
			System.out
					.println("Do you want to go for CompensationInsurance or ThirdParty::");
			choice = scan.next();
			if (choice.equalsIgnoreCase("CompensationInsurance")) {
				bike.setFinalInsurancePrice(comprehensivePrice);
				insurance.storeIntoList(bike);
				System.out.println(insurance.displayDetails());
			} else {
				bike.setFinalInsurancePrice(thirdPartyPrice);
				insurance.storeIntoList(bike);
				System.out.println(insurance.displayDetails());
			}
			break;
		default:
			break;
		}

	}

}
