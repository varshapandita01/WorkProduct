package com.insurance.bike;

public class BikeDetails {

	private String bikeName;
	private double bikePrice;
	private double depreciatedBikePrice;
	private double finalInsurancePrice;

	private int bikeYear;

	public int getBikeYear() {
		return bikeYear;
	}

	public void setBikeYear(int bikeYear) {
		this.bikeYear = bikeYear;
	}

	public String getBikeName() {
		return bikeName;
	}

	public void setBikeName(String bikeName) {
		this.bikeName = bikeName;
	}

	public double getBikePrice() {
		return bikePrice;
	}

	public void setBikePrice(double bikePrice) {
		this.bikePrice = bikePrice;
	}

	public double getDepreciatedBikePrice() {
		return depreciatedBikePrice;
	}

	public void setDepreciatedBikePrice(double depreciatedBikePrice) {
		this.depreciatedBikePrice = depreciatedBikePrice;
	}

	public double getFinalInsurancePrice() {
		return finalInsurancePrice;
	}

	public void setFinalInsurancePrice(double finalInsurancePrice) {
		this.finalInsurancePrice = finalInsurancePrice;
	}

	@Override
	public String toString() {
		return "BikeDetails [bikeName=" + bikeName + ", bikePrice=" + bikePrice
				+ ", depreciatedBikePrice=" + depreciatedBikePrice
				+ ", finalInsurancePrice=" + finalInsurancePrice
				+ ", bikeYear=" + bikeYear + "]";
	}

}
