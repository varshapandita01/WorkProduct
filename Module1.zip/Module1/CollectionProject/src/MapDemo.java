import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Queue;
import java.util.TreeMap;

public class MapDemo {

	public static void main(String[] args) {
		HashMap<String, String> map = new HashMap<>();

		map.put("jack", "Jill");
		map.put("scott", "tiger");
		map.put("java", "duke");
		map.put("jack", "rose");

		System.out.println(map.get("scott"));
		System.out.println(map.get("java"));
		System.out.println(map.get("jack"));
		System.out.println("---------HashMap-------");
		for (String key : map.keySet()) {
			System.out.println(key + ": " + map.get(key));
		}
		TreeMap<String, String> map1 = new TreeMap<>();
		map1.put("jack", "Jill");
		map1.put("scott", "tiger");
		map1.put("java", "duke");
		map1.put("jack", "rose");
		System.out.println("----------------TreeMAp-------------");
		for (String key : map1.keySet()) {
			System.out.println(key + ": " + map1.get(key));
		}
		Queue< String>que=new LinkedList();
		//add elements in the list
		que.add("zubair");
		que.offer("natasha");
		que.add("taniya");
		que.offer("taniya");
		que.add("pallavi");
		System.out.println("----------Queue:::::");
		String s=que.peek();
		System.out.println(s);
		String s1=que.poll();
		System.out.println(s);
		String s2=que.poll();
		//String s3=que.remove();
	
		//System.out.println(s);
		System.out.println("Queue:::: after peek and poll:"); 
		for (String key : que){
			System.out.println(key);
		}
		System.out.println(s1);
		System.out.println(s2);
	}

}
