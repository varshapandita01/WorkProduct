import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.TreeSet;
import java.util.Vector;
import java.util.function.Consumer;

public class CollectionDemo {

	public static void main(String[] args) {
		
		
		Vector<String> V = new Vector<>();
		V.add("Apple");
		V.add("Oracle");
		V.add("Google");
		V.add("Microsoft");
		V.add("Apache");
		System.out.println("--Traversing over Vector using for-loop");
		for (int i = 0; i < V.size(); i++) {
			System.out.println(V.get(i));
		}
		System.out.println("--Traversing over Vector using iterator");
		Iterator<String> itr = V.iterator();
		while (itr.hasNext()) {
			System.out.println(itr.next());
		}
		System.out.println("--Traversing over Vector using foreachloop");
		for (String node : V) {
			System.out.println(node);
		}

		ArrayList<String> lst = new ArrayList<String>();
		lst.add("Facebook");
		lst.add("Google");
		lst.add("Amazon");
		V.addAll(lst);
		
		System.out
				.println("--Traversing over updated Vector using foreachloop");
		for (String node : V) {
			System.out.println(node);
		}

		// converting Collection type
		HashSet<String> set = new HashSet<>(V);
		System.out.println("--Traversing over hashSet using foreachloop");
		for (String node : set) {
			System.out.println(node);
		}

		TreeSet<String> tree = new TreeSet<>(set);
		
	//	tree.add("1");
		
		System.out.println("--Traversing over TreeSet using foreachloop");
		for (String node : tree.descendingSet()) {
			
			
			System.out.println(node);
		}
  
		
		System.out.println("----Traversing in Java 8 style");
		tree.forEach(System.out::println);
		
		System.out.println("----Traversing in Java 8 style using consumer");
// different styles of using Lambda Expression
		Consumer<String> consumerTest=new Consumer<String>() {
			
			@Override
			public void accept(String t) {
				System.out.println(t);
				
			}
		};
		
		System.out.println("----Traversing in Java 8 style using consumerAAA");
		
		Consumer<String> consumerTest1=(str)->System.out.println(str);
		tree.forEach(consumerTest1);
		System.out.println("----Traversing in Java 8 style using consumerBBB");
		
		class ConsumerImpl implements  Consumer<String>{
			@Override
			public void accept(String t) {
				System.out.println(t);}
		}
	}

}
