import java.util.Locale;
import java.util.ResourceBundle;

public class LocaleDemo {

	public static void main(String[] args) {
		ResourceBundle bundle = ResourceBundle.getBundle("msgs");
		System.out.println(bundle.getString("greetings"));
		System.out.println(bundle.getString("message"));

		ResourceBundle bundle1 = ResourceBundle
				.getBundle("msgs", Locale.FRENCH);
		System.out.println(bundle1.getString("greetings"));
		System.out.println(bundle1.getString("message"));

		Locale hilo = new Locale("hi");
		ResourceBundle bundle2 = ResourceBundle.getBundle("msgs", hilo);
		System.out.println(bundle2.getString("greetings"));
		System.out.println(bundle2.getString("message"));

	}

}
