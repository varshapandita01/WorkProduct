import java.util.Set;
import java.util.TreeSet;
class GenericDemo<t>{
	t data;
	public GenericDemo(t data){
		this.data=data;
	}
}

public class dd {

	public static void main(String[] args) {
		Set set=new TreeSet<>();
		set.add("dd");
		set.add("edd");
		set.add("cdd");
		for(Object  str:set){
			System.out.println(str+" ");
		}
	}

}
