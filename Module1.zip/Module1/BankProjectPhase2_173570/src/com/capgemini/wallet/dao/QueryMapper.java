package com.capgemini.wallet.dao;

public interface QueryMapper {

	public static String insertDetails = "insert into bankaccount;"
			 + " values(?,?,?,?,?,?)";
	
	public String sql= "select name,age,address,email,ACCOUNT_NUMBER from bankaccount; where ACCOUNT_NUMBER=?";

	String Accno = "select*from bankaccount where ACCOUNT_NUMBER = ?";
	
	String Balance = "update bankaccount set balance=balance+? where ACCOUNT_NUMBER =?";
	
	String ShowBalance ="select balance from bankaccount where ACCOUNT_NUMBER = ?";
	
	String WithDraw = "update bankaccount set balance=balance-? where ACCOUNT_NUMBER =?";
	
	String Transaction = "insert into Transaction12"
			 + " values(SeqTrans.nextval,?,?,?,?)";
	
	String PrintTrans = "select * from Transaction12 where ACCNO= ?";
}
