package com.capgemini.test.bean;

import com.capgemini.xyz.service.ServiceAccount;

public class CustomerInfo {
	private String name;
	private int age;
	private String address;
	private String email;
	private String pincode;
	private String mobile;
	private int accountNumber;
	private double balance;



	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPincode() {
		return pincode;
	}

	public void setPincode(String pincode) {
		this.pincode = pincode;
	}

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	public void setAccountNumber(int accountNumber) {
		this.accountNumber = accountNumber;
	}

	public int getAccountNumber() {
		return accountNumber;
	}
	public Transaction[] txns;
	public  int idx;
	@Override
	public String toString() {
		return "CustomerInfo [name=" + name + ", age=" + age + ", address="
				+ address + ", email=" + email + ", pincode=" + pincode
				+ ", mobile=" + mobile + ", accountNumber=" + accountNumber
				+ "]";
	}

}
