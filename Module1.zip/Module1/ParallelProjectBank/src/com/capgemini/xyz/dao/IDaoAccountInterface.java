package com.capgemini.xyz.dao;

import java.util.HashMap;
import java.util.Map;

import com.capgemini.test.bean.CustomerInfo;




public interface IDaoAccountInterface {
	void createAccount(CustomerInfo customer1);
	 Map<Integer, CustomerInfo> displayCustomerDetails();
	 Map<Integer, Double> balance = new HashMap<>();
	 void showBalance();
	 void deposit(double amount);
	 void withdraw(double amount);
	 void fundTransfer(int custId,double amount);
	 
}
