package com.capgemini.xyz.dao;




import java.util.HashMap;
import java.util.Map;

import com.capgemini.test.bean.CustomerInfo;
import com.capgemini.test.bean.Transaction;


public class DaoAccountClass implements IDaoAccountInterface {
	CustomerInfo customers = new CustomerInfo();

	
	double amount;

	private Map<Integer, CustomerInfo> customer = new HashMap<>();
	private Map<Integer, Double> balance = new HashMap<>();
	
	//create account
	@Override
	public void createAccount(CustomerInfo customers) {
		int accountNumber=(int)(Math.random()*1000000);
		customers.setAccountNumber(accountNumber);
		customer.put(accountNumber, customers);

	}

	public Map<Integer, CustomerInfo> displayCustomerDetails() {
		return customer;
	}

	

	public void showBalance() {
		System.out.println(customers.getBalance());
	}
	
	//To deposit

	public void deposit(double amount) {
		customers.setBalance((customers.getBalance()+amount));
		balance.put(customers.getAccountNumber(), customers.getBalance());
		customers.txns[customers.idx++] = new Transaction("CR", amount,customers.getBalance());
	}
//For WithDraw
	public void withdraw(double amount) {
		if (amount <= customers.getBalance()){
			customers.setBalance(customers.getBalance()-amount ) ;
			balance.put(customers.getAccountNumber(), customers.getBalance());
			customers.txns[customers.idx++] = new Transaction("DR",amount,customers.getBalance());
		}
		else
			System.out.println("Insuficient Balance");
	}
	
	public void fundTransfer(int custId,double amount){
		
		if (amount <= customers.getBalance()){
			customers.setBalance(customers.getBalance()-amount ) ;
			balance.put(customers.getAccountNumber(), customers.getBalance());
			System.out.println("Amount Transferred Successfully.../n CustomerId : "+custId+ " Amount Transferred : "+amount );
			customers.txns[customers.idx++] = new Transaction("DR",amount,customers.getBalance());
		}
		else
			System.out.println("Insuficient Balance you cannot transfer....");
	
		
	}
	
	public DaoAccountClass() {
		customers.txns = new Transaction[10];

		customers.txns[customers.idx++] =new Transaction("CR", amount,customers.getBalance());
	}
}
