package com.capgemini.xyz.service;

import java.util.Map;

import com.capgemini.test.bean.CustomerInfo;



public interface IServiceAccount {
	String userAccountNumber="ABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890";
	String userNamePattern="[A-Z][a-z]{1,}";
	String userAgePattern="[0-9]{2}";
	String userAddressPattern="[A-Z a-z 0-9]{1,35}";
	String userEmailPattern="[A-Za-z]{4,}[@]{1}[A-Za-z]{3,15}[.]{1}[A-Z a-z]{2,4}";
	String userMobilePattern="[0-9]{10}";
	String userPincodePattern="[0-9]{6}";
	String choicePattern="[1-6]{1}";
	boolean validateChoice(String userChoice);
	boolean validateUserName(String userNamePattern);
	boolean validateUserAge(String userAgePattern);
	boolean validateEmail(String userEmailPattern);
	boolean validateAddress(String userAddressPattern);
	boolean validateMobile(String userMobilePattern);
	boolean validatePincode(String userPincodePattern);
//	String createUserAccountNumber();
	 void createAccount(CustomerInfo customer1);
	 Map<Integer, CustomerInfo> displayPersons() ;
	 void showBalance();
	 void deposit(double amount) ;
	 void withdraw(double amount);
	 void fundTransfer(int custId,double amount);
}
