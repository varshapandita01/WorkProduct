package com.capgemini.xyz.exception;

public class RecordNotFounException extends Exception{

	public RecordNotFounException() {
		super();
	
	}
	public RecordNotFounException(String msg) {
		super(msg);
	
	}
}
