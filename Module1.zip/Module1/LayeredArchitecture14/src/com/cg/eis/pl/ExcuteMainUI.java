package com.cg.eis.pl;

import java.util.Scanner;

import com.cg.eis.bean.Employee;
import com.cg.eis.service.EmployeeService;

public class ExcuteMainUI {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		EmployeeService service = new EmployeeService();
		System.out.println("Enter Employee id");
		int id = scan.nextInt();
		System.out.println("Enter Employee Name:");
		String employeeName;
		String employeeAge;
		while (true) {
			employeeName = scan.next();
			boolean isValid = service.validateName(employeeName);
			if (isValid)
				break;
			else
				System.out
						.println("Customer Name should have atmost 10 letters and first letter must be Capital");

		}
		System.out.println("Enter Employee Age:");
		while (true) {
			employeeAge = scan.next();
			boolean isValid = service.validateAge(employeeAge);
			if (isValid)
				break;
		}
		System.out.println("Enter employee Salary");
		double salary = scan.nextDouble();
		System.out.println("Enter Designation");
		String designation = scan.next();
		String insurance = service.validation(salary, designation);
		Employee emp = new Employee();
		emp.setId(id);
		emp.setName(employeeName);
		emp.setAge(employeeAge);
		emp.setSalary(salary);
		emp.setDesignation(designation);
		emp.setInsuranceScheme(insurance);
		service.addDetail(emp);
		System.out.println(service.displaydetails());
	}

}
