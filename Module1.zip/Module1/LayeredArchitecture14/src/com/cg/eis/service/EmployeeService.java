package com.cg.eis.service;

import java.util.List;


import com.cg.eis.bean.Employee;
import com.cg.eis.dao.EmployeeDao;

public class EmployeeService implements EmployeeServiceInterface {
Employee emp= new Employee();
EmployeeDao dao=new EmployeeDao();
	@Override
	public boolean validateName(String userName) {
		if (userName.matches(employeeName))
			return true;
		else
			return false;
	}

	@Override
	public boolean validateAge(String userAge) {
		if (userAge.matches(employeeAge))
			return true;
		else
			return false;
	}

	@Override
	public String validation(double salary,String designation) {
		if(salary >5000 && salary < 20000 & designation.equalsIgnoreCase("System Associate"))
		{
			emp.setInsuranceScheme("Scheme C");
			System.out.println("Insurance Scheme: Scheme C");
		}
		else if(salary >=20000 && salary <40000 & designation.equalsIgnoreCase("Programmer"))
		{
			emp.setInsuranceScheme("Scheme B");
			System.out.println("Insurance Scheme: Scheme B");
		}
		else if(salary >=40000 && designation.equalsIgnoreCase("Manager"))
		{
			emp.setInsuranceScheme("Scheme A");
			System.out.println("Insurance Scheme: Scheme A");
		}
		else if(salary <5000  && designation.equalsIgnoreCase("Clerk"))
		{
			emp.setInsuranceScheme("No Scheme");
			System.out.println("No Insurance Scheme");
		}
		else{
			System.out.println("Some Mismatch in salary and Designation");
		}
		return emp.getInsuranceScheme();
	}
	
	public void addDetail(Employee emp) {
		dao.addDetail(emp);
	}
	@Override
	public List<Employee> displaydetails(){
		return dao.displayDetails();
	}

}
