package com.cg.eis.service;

import java.util.List;

import com.cg.eis.bean.Employee;

public interface EmployeeServiceInterface {
	String employeeName = "[A-Z][A-Z a-z]{2,15}";
	String employeeAge = "[0-9]{1,2}";

	boolean validateName(String userName);

	boolean validateAge(String userAge);

	String validation(double salary, String designation);

	List<Employee> displaydetails();

}
