package com.cg.eis.dao;

import java.util.ArrayList;
import java.util.List;

import com.cg.eis.bean.Employee;

public class EmployeeDao {
	Employee emp= new Employee();
	List<Employee>listEmp=new ArrayList<>();

	public void addDetail(Employee emp) {
		listEmp.add(emp);
	}
public List<Employee> displayDetails(){
	
	return listEmp;
	
}
}
