public class DaemonThread extends Thread {
	private int limit;

	public DaemonThread(String name, int limit) {
		super(name);
		this.limit = limit;
	}

	@Override
	public void run() {
		String name = Thread.currentThread().getName();
		for (int i = 1; i <= limit; i++) {
			System.out.println(name + ":" + i);
		}
	}

	public static void main(String[] args) {
		DaemonThread d1 = new DaemonThread("First", 50);
		DaemonThread d2 = new DaemonThread("Second", 100);
		DaemonThread d3 = new DaemonThread("Third", 75);

		DaemonThread d4 = new DaemonThread("Daemon", 500000);

		d4.setDaemon(true);// if set false then it will run till 5000000 as it
							// it is true it will work till last value ends

		d1.start();
		d2.start();
		d3.start();
		d4.start();
	}

}
