import java.util.concurrent.Executor;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MyExecutor {

	public static void main(String[] args) {

		// Executor executor = Executors.newSingleThreadExecutor();
		// this is
		// also ryt but in this execution keeps on runnung so for shutdown we
		// use Executor service
		ExecutorService executor = Executors.newSingleThreadExecutor();// Concurrency
		// Used here
		// only single
		// will be
		// executed

		ExecutorService executor1 = Executors.newFixedThreadPool(2);
		Runnable runnable = () -> System.out.println("Hello Pool");
		
		Runnable runnable1 = () -> System.out.println("Two Pools");
		try {
			Thread.sleep(3000);
		}catch (InterruptedException e) {}
		
		executor.execute(runnable);
		executor.execute(runnable);
		
		executor.shutdown();
		
		executor1.execute(runnable1);
		executor1.execute(runnable1);
		
		executor1.shutdown();
	}

}
