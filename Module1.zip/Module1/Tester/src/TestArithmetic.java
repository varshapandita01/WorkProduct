import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

public class TestArithmetic {
	private Arithmetic obj;
	
	@Before
	public void setUp(){
		obj=new Arithmetic();
	}
	@After
	public void tearDown(){
		obj=null;
	}
	
	@Test
	public void testAddition(){
		assertEquals(5,obj.addition(3, 2));
	}
	@Test
	public void testSubtraction(){
		assertEquals(1, obj.subtraction(3, 2));
	}

}
