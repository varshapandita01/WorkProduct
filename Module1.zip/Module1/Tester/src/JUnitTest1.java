import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.Collection;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;

public class JUnitTest1 {
	private Collection<String> collection;

	@BeforeClass
	public static void oneTimeSetUp() {
		// one-time initialization code
		System.out.println("@BeforeClass - OneTimeSetUp");
	}

	@AfterClass
	public static void oneTimeTearDown() {
		// one-time clean up code
		System.out.println("@AfterClass - oneTimeTearDown");
	}

	@Before
	public void setUp() {
		collection = new ArrayList<String>();
		// collection.add("aapple");
		System.out.println("@before - setUp");
	}

	@After
	public void tearDown() {
		collection.clear();
		System.out.println("@After - tearDown");
	}

	@Test
	public void testEmptyCollection() {
		// collection.add("ds");
		assertTrue(collection.isEmpty());
		System.out.println("@Test - testEmptyCollection");
	}

	@Test
	public void testOneItem() {
		collection.add("itemA");
		collection.add("itemB");
		assertEquals(2, collection.size());
		System.out.println("@Test - testOneItemCollection");
	}

	@Ignore("nOT rEADY TO RUN")
	@Test
	public void divisionWithException() {
		System.out.println("Method is not ready to Run");
	}
}
