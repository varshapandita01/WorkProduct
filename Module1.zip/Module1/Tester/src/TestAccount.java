import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.*;

public class TestAccount {
	private Account obj;

	@Before
	public void setUp() {
		obj = new Account(3000);

	}

	@After
	public void tearDown() {
		obj = null;
	}

	@Test
	public void testAccountBalance() {

	}

	@Test
	public void testAccountDeposit() {
		//assertNull(obj.deposit(1000));
		//obj.deposit(1000);
		assertEquals(4000,(int)obj.deposit(1000));
	}

	@Test
	public void testAccountWithdraw() throws BalanceException {
		
		assertEquals(1000,(int)obj.withdraw(2000));
	}
	@Test(expected = BalanceException.class)
	public void testAccountWithdrawException() throws BalanceException {
		
		obj.withdraw(4000);
	}
}
