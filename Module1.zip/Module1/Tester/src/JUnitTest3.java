import org.junit.Ignore;
import org.junit.Test;

public class JUnitTest3 {
	@Ignore("nOT rEADY TO RUN")
	@Test
	public void divisionWithException() {
		System.out.println("Method is not ready to Run");
	}
}
