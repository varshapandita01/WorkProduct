import org.junit.Test;

public class JUnitTest2 {
	@Test(expected = ArithmeticException.class)
	public void divisionWithException() {
		int i = 1 / 0;
	}
}
