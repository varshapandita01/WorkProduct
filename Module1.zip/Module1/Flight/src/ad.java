class Alpha{
	void demo(){
		System.out.println("ji");
	}
} 
class Beta extends Alpha {
	 void demo(){
		 System.out.println("jnjh");
	 }
}
public class ad {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Alpha ab= new Alpha();
//		Beta bv=(Beta)ab;//DownCasting
		
		Beta b=new Beta();
			Alpha abc=b;//UpCasting
			abc.demo();
			Beta bvc=(Beta)abc;//DownCasting
			
	}

}
