
public class CancelTicket extends BookTicket{
	int noofSeatsCancels;
	
	int AvailableSeats=super.AvailableSeats;

	public CancelTicket(int noofSeatsCancels, String PassengerName) {
		super(noofSeatsCancels, PassengerName);
		// TODO Auto-generated constructor stub
		this.noofSeatsCancels=noofSeatsCancels;
	}
	
	public void CancelTickets(){
		if(AvailableSeats>=TotalSeats){
		//this.noofSeatsCancels=noofSeatsCancels;
			System.out.println("Seats Canot get Cancelled");
		//System.out.println("Seats Cancelled Succesfully");
		}
		else{
			AvailableSeats+=noofSeatsCancels;
			
		}
	}
	public void summary(){
		super.summary();
		System.out.println("Seats Cancelled::"+noofSeatsCancels);
		System.out.println("Seats Avaible::"+AvailableSeats);
	}
}
