import java.util.Scanner;

public class FinalAvailabilty {

	public static void main(String[] args) {
		// Scanner scan=new Scanner (System.in);
		// System.out.println("Enter Choice BOOK TICKET OR CANCEL");
		// String choice=scan.next();
		// int process=scan.nextInt();

		BookTicket b1 = new BookTicket(5, "Evan");

		b1.BookTickets();

		b1.CancelTickets(2);
		b1.summary();

		// CancelTicket c1=new CancelTicket(1,"Evan");
		// c1.CancelTickets();
		// c1.summary();
	}

}
