
public class Flight {
	protected int TotalSeats=500;
	protected int AvailableSeats=TotalSeats;
	protected int process;
	private String PassengerName;

	public Flight(int process, String PassengerName) {
		this.process=process;
		this.PassengerName=PassengerName;
	
		
	}

public void summary(){
	System.out.println("PassengerName::"+PassengerName);
	//System.out.println("AvailableSeats::"+AvailableSeats);

}
}
