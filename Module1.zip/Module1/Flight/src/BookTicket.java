
public class BookTicket extends Flight {
	int NoOfBookings;
	int AvailableSeats=super.AvailableSeats;

	public BookTicket(int NoOfBookings, String PassengerName) {
		super(NoOfBookings, PassengerName);
		this.NoOfBookings=NoOfBookings;
	}
	//int NoOfBookings;
	public void BookTickets(){
		//this.NoOfBookings=NoOfBookings;
		if(AvailableSeats<=TotalSeats){
		if(AvailableSeats>0){
			AvailableSeats-=NoOfBookings;
			System.out.println("Booked Ticket Scuccesfully");
		//	System.out.println("Seats Avaible::"+AvailableSeats);
		}
		else{
			System.out.println("Seats Not Available");
		}
		}
		else{
			System.out.println("Seats UnAvailable");
		}
	}
	int noofSeatsCancels;
	public void CancelTickets(int noofSeatsCancels){
		if(AvailableSeats>=TotalSeats){
		
			System.out.println("Seats Canot get Cancelled");
		
		}
		else{
			AvailableSeats+=noofSeatsCancels;
			System.out.println("Seats  got Cancelled Successfully");
			
		}
	}
	
	public void summary(){
		super.summary();
		System.out.println("Seats Booked::"+NoOfBookings);
		System.out.println("Seats Cancelled::"+noofSeatsCancels);
		System.out.println("Seats Avaible::"+AvailableSeats);

	}	
}
