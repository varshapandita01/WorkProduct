import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;


public class DemoLocaleData {

	public static void main(String[] args) {
	LocalDate localDate1=LocalDate.now();
	System.out.println(localDate1);

	LocalDate localDate2=LocalDate.of(2015, 02, 20);
	System.out.println(localDate2);
	
	LocalDate localDate3=LocalDate.parse("2015-02-20");
	System.out.println(localDate3);
	
	LocalDate tomorrow=LocalDate.now().plusDays(1);
	System.out.println(tomorrow);
	
	LocalDate previousMonthSameDay=LocalDate.now().minus(1, ChronoUnit.MONTHS);
	System.out.println(previousMonthSameDay);
	
	DayOfWeek sunday=LocalDate.parse("2016-06-12").getDayOfWeek();
	System.out.println(sunday);
	
	System.out.println(LocalDate.parse("2016-06-12").getDayOfMonth());
	
	System.out.println(LocalDate.now().isLeapYear());
	}

}
