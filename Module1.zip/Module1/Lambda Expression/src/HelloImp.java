import java.util.function.BiFunction;
import java.util.function.Consumer;
import java.util.function.Predicate;


public class HelloImp {

	public static void main(String[] args) {
		
		class HelloTest implements Hello{

			@Override
			public String sayHello() {
				
				return "HelloWorld";
			}
			
		}// Below is the short way using Lambda expression and it should bbe a inner class
		Hello h=()->"Hello WOrld";  //implementation
		System.out.println(h.sayHello()); //invocation);
		h.greeting("varsha");
	System.out.println(Hello.calSquare(5));
	
	
	// Functins of functional Interface
	Consumer<String> consumer = (String str)-> System.out.println(str);//consumer returns the value
	consumer.accept("Hello LE!");
	
	java.util.function.Supplier<String> supplier = () -> "Hello from Supplier!";//supplier takes value and return using consumer
	consumer.accept(supplier.get());
	
	Predicate<Integer> predicate = num -> num%2==0;
	System.out.println(predicate.test(24));//return boolean value
	System.out.println(predicate.test(19));
	
	BiFunction<Integer, Integer, Integer> maxFunction = (x,y)->x>y?x:y;
	System.out.println(maxFunction.apply(25, 14));//pass 2 values and return only one
	}

}
