@FunctionalInterface
public interface Hello {
	String sayHello();

	String toString();// @Functional Interface so thats why another method
						// declared

	default void greeting(String name) {
		System.out.println("Welcome " + name); // declaring method in interface
												// is possible only by using
												// default keyword
		System.out.println( name+"  Welcome " + sayHello()); //sayhello() called only when this method is already implemnetd
	}
	
	static int calSquare(int num){
		return num*num;
	}
}
