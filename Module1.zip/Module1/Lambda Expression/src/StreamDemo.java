import java.util.stream.Stream;


public class StreamDemo {

	public static void main(String[] args) {
		Stream<Integer> numbers=Stream.of(3,5,6,3,57,9,4,52);
	/*	numbers.forEach(System.out::println);*/
		/*numbers.sorted().forEach(System.out::println);*/
		//numbers.forEachOrdered(System.out::println);

		//numbers.distinct().forEach(System.out::println);
	//	numbers.r
	}

}
