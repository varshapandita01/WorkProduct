import java.util.Arrays;
import java.util.List;
import java.util.stream.Collector;
import java.util.stream.Collectors;


public class SecondAttempt {

	public static void main(String[] args) {
		String array[]={"Foo","Alfa","Romeo","Indigo","Beta","King","g"};
		
		List<String> input =Arrays.asList(array);
		/*System.out.println("-----PRINT-----------");
		input.forEach(System.out::println);
		System.out.println("------UPPERCASE----------");		
		input.stream().map(alpha -> alpha.toUpperCase()).forEach(System.out::println);
		System.out.println("-------SORTED UPPERCASE---------");
		input.stream().map(alpha -> alpha.toUpperCase()).sorted().forEach(System.out::println);
		System.out.println("--------STREAM--------");
		input.stream().forEach(System.out::println);*/
		System.out.println("--------PARALLEL--------");
		input.stream().parallel().forEach(System.out::println);
		
		System.out.println("--------CollectorLength NAd store in List--------");
		List<Integer> lengths=input.stream().map(str ->str.length()).collect(Collectors.toList());
	lengths.forEach(System.out::println);
	}

}
