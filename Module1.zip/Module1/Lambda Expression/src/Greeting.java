@FunctionalInterface
public interface Greeting {
void print(String message);
}

