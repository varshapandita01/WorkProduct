package com.cg.mobshop.ui;//package containing main class

import java.util.Scanner;

import com.cg.mobshop.Exception.RecordNotFoundException;
import com.cg.mobshop.dto.Mobiles;
import com.cg.mobshop.service.MobileService;
import com.cg.mobshop.service.MobileServiceImpl;

public class MainUI {

	public static void main(String[] args) {// to display menu and accept the
											// details from user

		MobileService service = new MobileServiceImpl();
		Mobiles mobile = new Mobiles();
		Scanner scan = new Scanner(System.in);
		String choice;
		int criteria;
		System.out.println("Welcome to Mobile Shopee");

		System.out.println(service.getMobileLists());
		System.out
				.println("Which operation Do you want to perform \n 1.Sorting \n 2.Delete");
		while (true) {

			System.out.println("Enter your Choice::");
			choice = scan.next();// enter choice for soting or deletion
			boolean isValid = service.validateChoice(choice);
			if (isValid)
				break;

			else {
				System.out.println("Please Enter between 1 to 2");
			}
		}
		if (choice.equalsIgnoreCase("1")) {

			System.out
					.println("Whic Sorting Criteria you want to choose:: \n 1.Mobile Name \n 2.Mobile Price \n 3.Mobile Id  ");
			criteria = scan.nextInt();//enter choice for type of sorting

			try {
				service.sortList(criteria);// Fetch Record in sorted way
											// according to criteria
			} catch (RecordNotFoundException e) {
				System.out.println(e);
			}
		} else if (choice.equalsIgnoreCase("2")) {

			System.out
					.println("Delete the record from Collection by passing MobileId");
			int mobcode = scan.nextInt();
			mobile.setMobileId(mobcode);
			try {
				System.out.println(service.deleteMobile(mobcode));// delete the
																	// record
			} catch (RecordNotFoundException e) {
				System.out.println(e);
			}
		}

	}
}
