package com.cg.mobshop.service;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.TreeSet;

import com.cg.mobshop.Exception.RecordNotFoundException;
import com.cg.mobshop.Util.Util;
import com.cg.mobshop.dao.MobileDAOImpl;
import com.cg.mobshop.dto.Mobiles;

public class MobileServiceImpl implements MobileService {
	Util records = new Util();
	Mobiles mobile = new Mobiles();
	List<Mobiles> list = new ArrayList<Mobiles>();
	Map<Integer, Mobiles> map = new HashMap<Integer, Mobiles>();
	MobileDAOImpl dao = new MobileDAOImpl();

	// Validations
	@Override
	public boolean validateChoice(String userChoice) {
		if (userChoice.matches(choicePattern))
			return true;
		else
			return false;
	}

	@Override
	public boolean validateCriteria(String userChoice) {
		if (userChoice.matches(criteria))
			return true;
		else
			return false;
	}

	@Override
	public List<Mobiles> getMobileList() {

		return list;

	}

	// Display details
	@Override
	public Map<Integer, Mobiles> getMobileLists() {

		return Util.getMobileEntries();

	}

	// Delete the data from map
	@Override
	public Mobiles deleteMobile(int mobcode) throws RecordNotFoundException {

		return dao.deleteMobile(mobcode);
	}

	@Override
	public List<Mobiles> sortList(int criteria) throws RecordNotFoundException {

		return dao.sortList(criteria);
	}

	public Mobiles find(int id) throws RecordNotFoundException {
		return dao.find(id);
	}

}
