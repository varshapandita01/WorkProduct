package com.cg.mobshop.service;

import java.util.List;
import java.util.Map;

import com.cg.mobshop.Exception.RecordNotFoundException;
import com.cg.mobshop.dto.Mobiles;

public interface MobileService {
	String choicePattern="[1-2]{1}";
	String criteria="[1-3]{1}";
	boolean validateChoice(String userChoice);
	boolean validateCriteria(String userChoice);
	public List<Mobiles> getMobileList();

	public Mobiles deleteMobile(int mobcode) throws RecordNotFoundException;

	public List<Mobiles> sortList(int criteria) throws RecordNotFoundException;

	Map<Integer, Mobiles> getMobileLists();
}
