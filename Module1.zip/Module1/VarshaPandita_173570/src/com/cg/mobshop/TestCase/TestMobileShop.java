package com.cg.mobshop.TestCase;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import com.cg.mobshop.Exception.RecordNotFoundException;
import com.cg.mobshop.dao.MobileDAOImpl;
import com.cg.mobshop.dto.Mobiles;

public class TestMobileShop {

	MobileDAOImpl dao = null;

	@Before 
	public void setUp() throws Exception {

		dao = new MobileDAOImpl();
	}

	@After
	public void tearDown() throws Exception {
		dao = null;
	}

	@Test
	public void testValidCustomerDetails() {
		Mobiles cust = new Mobiles();
		Mobiles requestCust = new Mobiles();

		int id = cust.getMobileId();
		try {
			requestCust = dao.find(id);
			Assert.assertNotNull(requestCust);
			System.out.println("Test Case Passed");

		} catch (RecordNotFoundException e) {
			System.out.println(e);
		}
	}

	@Test
	public void testInvalidCustomerDetails() {
		Mobiles cust = new Mobiles();
		Mobiles requestCust = new Mobiles();
		try {
			requestCust = dao.find(101);
			Assert.assertNotNull(requestCust);
			System.out.println("Test Case Passed");

		} catch (RecordNotFoundException e) {
			System.out.println(e);
		}
	}

}
