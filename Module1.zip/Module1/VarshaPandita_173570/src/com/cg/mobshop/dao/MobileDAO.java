package com.cg.mobshop.dao;

import java.util.List;
import java.util.Map;

import com.cg.mobshop.Exception.RecordNotFoundException;
import com.cg.mobshop.dto.Mobiles;

public interface MobileDAO {

	List<Mobiles> sortList(int criteria) throws RecordNotFoundException;

	

	
}
