package com.cg.mobshop.dao;

import java.awt.Label;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeSet;

import com.cg.mobshop.Exception.RecordNotFoundException;
import com.cg.mobshop.Util.Util;
import com.cg.mobshop.dto.Mobiles;

public class MobileDAOImpl implements MobileDAO {
	// Map<Integer, Mobiles> map = new HashMap<Integer, Mobiles>();
	List<Integer> list = new ArrayList<>();

	Mobiles mobile = new Mobiles();

	public Mobiles deleteMobile(int mobcode) {
		mobile.setMobileId(mobcode);
		Util.getMobileEntries().remove(mobile.getMobileId());
		System.out.println("Deleted Successfully");
		return mobile;
	}

	@Override
	public List<Mobiles> sortList(int criteria) throws RecordNotFoundException {
		TreeSet<String> set = new TreeSet<String>();
		if (criteria == 1) {
			set.add(mobile.getName());
		} else if (criteria == 2) {
			set.add(mobile.getPrice());
		} else if (criteria == 3) {
			set.add(mobile.getQuantity());
		} else {
			throw new RecordNotFoundException("Criteria not Matches");
		}
		return null;
	}

	public Mobiles find(int id) throws RecordNotFoundException {
		Mobiles p = Util.getMobileEntries().get(id);
		if (p != null) {
			return p;
		} else {
			throw new RecordNotFoundException("Record Not Found");
		}
	}
}
