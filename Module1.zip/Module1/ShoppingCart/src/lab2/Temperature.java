package lab2;

public class Temperature {
	public  double celsiusToFahrenheit(double celsius){
		double temp=(9*celsius)/5+32;
		return temp;


	}
	public  double fahrenheitToCelsius(double fahrenhit){
		double temp1= (fahrenhit-32) * 5/9 ;
		return temp1;
}
}
