package lab2;

public class TemperatureConvert {

	public static void main(String[] args) {
		Temperature tm = new Temperature();
	System.out.println(tm.celsiusToFahrenheit(32));
		System.out.println(tm.fahrenheitToCelsius(32));
	}

}
