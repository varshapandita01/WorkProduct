package lab2;

public interface Currency {
	double dollarValue();
}
