package lab2;

public class TestConverter {

	public static void main(String[] args) {
		USD usd=new USD();
		INR inr=new INR();
		
		double result=CurrencyConvertor.convert(usd, inr,100);
		double rsult1=CurrencyConvertor.convert(new EURO(), new INR(), 100); 
		System.out.println("Result: "+result);
			

	}

}
