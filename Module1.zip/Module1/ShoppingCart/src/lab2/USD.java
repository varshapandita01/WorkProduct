package lab2;

public class USD implements Currency {

	@Override
	public double dollarValue() {

		return 1;
	}

}
