package lab2;


import static lab2.TemperatureConversion.*;

public class Fahrenhiet {
	
public static void main(String[] args) {
	
	
	System.out.println(convert(celsius, Fahreinhet, 1));
	System.out.println(convert(Fahreinhet,celsius, 1));
	System.out.println(convertFahrenhiet(1));
	System.out.println(convertCelsius(1));
}


}

/*System.out.println(convertFahrenhiet(1));
System.out.println(convertCelsius(2));*/
/*

static double convertFahrenhiet(double celsius){
	return (9*celsius)+(5+32);
	
}
static double convertCelsius(double Fahrenhiet){
	return (Fahrenhiet-32) * 5/9 ;
	
}*/