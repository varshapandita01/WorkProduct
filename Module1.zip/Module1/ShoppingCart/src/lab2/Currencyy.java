package lab2;
@FunctionalInterface
public interface Currencyy {
	double dollarValue();
	static double convert(Currency source,Currency Target,double amount){
		return amount*(Target.dollarValue()/source.dollarValue());
		
	}
	Currency USD = ()->1.0;
	Currency INR = ()->70.50;
	Currency AED = ()->3.70;
}
