package lab2;
@FunctionalInterface
public interface TemperatureConversion {
	double temperature();
	static double convert(TemperatureConversion source,TemperatureConversion Target,double value){
		return (Target.temperature())*(((value*(9/5))+32));
		
	}
	TemperatureConversion celsius = ()->1;
	TemperatureConversion Fahreinhet = ()->33.8;
	static double convertFahrenhiet(double celsius){
		return (9*celsius)+(5+32);
		
	}
	static double convertCelsius(double Fahrenhiet){
		return (Fahrenhiet-32) * 5/9 ;
		
	}
	

}
