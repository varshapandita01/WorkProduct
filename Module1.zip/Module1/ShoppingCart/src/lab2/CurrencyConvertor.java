package lab2;

public final class CurrencyConvertor {
 public static double convert(Currency source ,Currency target,double amount) {
	double rate=target.dollarValue()/source.dollarValue();
	return amount*rate;
			
}
}
