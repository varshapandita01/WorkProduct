public abstract class Product {
	private static int code;
	private String name;
	private int price;
	private int stock;
	private int hascode=100;
	public Product(String name, int price, int stock) {
		super();
		this.name = name;
		this.price = price;
		this.stock = stock;
		this.code = hascode++;
	}
	public String getName() {
		return name;
	}
	public int getPrice() {
		return price;
	}
	public int getStock() {
		return stock;
	}
	public void updateStock(int qty){
			stock+=qty;
			
	}
	
	public void display(){
		System.out.println(" code\t Name\t Stock\t Price");
		System.out.println(code+"\t"+name+"\t"+stock+"\t"+price);
	}
}
