import java.util.HashMap;


public class ShoppingCart {
	HashMap<Product, Integer>cart=new HashMap<Product, Integer>();
	private int total;
	public void addItem(Product p,int qty) throws OutOfStockException{
		if(p.getStock()<=qty){
		cart.put(p,qty);
		p.updateStock(qty);
		total+=p.getPrice()*qty;
	} 
		else {
			throw new OutOfStockException("You have ordered out of Stock exception!!!");
		}
		}
	public void removeItem(Product p){
		int qty=cart.get(p);
		cart.remove(p);
		p.updateStock(qty);
	}
	public void checkout(){
		System.out.println("SHOPPING CART SUMMARY");
		for (Product  p : cart.keySet()) {
			int qty=cart.get(p);
			p.display();
			System.out.println("Order Quality:::"+qty);
			System.out.println("Quantitiy Amount:::"+p.getPrice()*qty);
			
		}
		System.out.println("Cart Total::::"+total);
	}
		

}
