
public class Shoe extends Product {
private int size;

public Shoe(String name, int price, int stock, int size) {
	super(name, price, stock);
	this.size = size;
}
public void display(){
	super.display();;
	System.out.println("\tSize");
	System.out.println(size);
}
}
