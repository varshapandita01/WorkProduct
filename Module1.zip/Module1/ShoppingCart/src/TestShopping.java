
public class TestShopping {

	public static void main(String[] args) {
	ShoppingCart amazon=new ShoppingCart();
	Shoe s1=new Shoe("Nike", 2400, 2,8);
	Watch w1=new Watch("G-Stock", 6600, 5, "Chrono");
try{
		amazon.addItem(s1, 1);
}catch(OutOfStockException e){
	System.out.println(e.getMessage());
}
try{		
		amazon.addItem(w1,2);
}
catch(OutOfStockException e){
	System.out.println(e.getMessage());
}
		amazon.checkout();
	}

}
