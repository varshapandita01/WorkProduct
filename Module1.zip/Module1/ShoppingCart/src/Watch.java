
public class Watch extends Product {
	public Watch(String name, int price, int stock, String type) {
		super(name, price, stock);
		this.type = type;
	}


	private String type;

	
	public void display(){
		super.display();;
		System.out.println("\tType");
		System.out.println(type);
	}
	

}
