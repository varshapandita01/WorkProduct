package com.capgemini.xyz.dao;

public interface QueryMapper {
	// insert user data
	String insertDetails = "insert into customer_bank_details"
			+ "(accountNumber,customer_name," + "age,address,"
			+ "email,pincode,mobile,balance)" + " values" + "(?,?,?,?,?,?,?,?)";

	String updateDetails = "update customer_bank_details set balance = ? where accountNumber=?";

	String selectbalance = "select * from customer_bank_details where accountNumber=?";
}
