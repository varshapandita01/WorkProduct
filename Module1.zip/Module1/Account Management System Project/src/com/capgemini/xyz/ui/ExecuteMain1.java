package com.capgemini.xyz.ui;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.Scanner;





import com.capgemini.test.bean.CustomerInfo;
import com.capgemini.xyz.exception.RecordNotFoundException;
import com.capgemini.xyz.service.ServiceAccount;
import com.capgemini.xyz.utility.JdbcUtil;

public class ExecuteMain1 {

	public static void main(String[] args) {
		ServiceAccount service = new ServiceAccount();
		CustomerInfo person = new CustomerInfo();
		String ch;
		boolean isValid;
		String name;
		String email;
		String mobile;
		String userAccId;
		String amount;
		String age;
		String address;
		String pincode;
		String sourceAccId;
		String targetAccId;
		System.out.println("XYZ Bank welcomes you");
		Scanner scan = new Scanner(System.in);

		while (true) {
			while (true) {

				System.out
						.println("1.	Create Account\n2.	Show Balance\n3.	Deposite\n4.	Withdraw"
								+ "\n5.	Fund Transfer\n6.	Show Transaction\n7.Find Details using id\n8. Exit");
				ch = scan.next();
				isValid = service.validateChoice(ch);
				if (isValid)
					break; // if user enter valid input then break
				else
					System.out.println("Please enter Valid Choice 1 or 6");
			}
			switch (ch) {
			case "1":
				System.out.println("Welcome");
				while (true) {

					System.out.println("Enter name");
					name = scan.next();

					isValid = service.validateUserName(name); // to validate
																// UserName
					if (isValid)
						break; // if user enter valid input then break
					else
						System.out
								.println("Please enter Valid Name.\nName should have minimum 1 or max 10 character \nFirst letter must be capital");
				}

				while (true) {

					System.out.println(" Enter Customer Age");
					age = scan.next();

					isValid = service.validateUserAge(age);
					if (isValid)
						break;
					else
						System.out.println("Age above 22  is valid");
				}

				while (true) {

					System.out.println(" Enter Customer Address");
					address = scan.next();

					isValid = service.validateAddress(address);
					if (isValid)
						break;
					else
						System.out.println("Max 35 Characters");
				}

				while (true) {

					System.out.println("Enter Customer Email");
					email = scan.next();

					isValid = service.validateEmail(email);
					if (isValid)
						break;
					else
						System.out
								.println("EmailID should have 1 @ and . abd letters before @must not less than  4");
				}

				while (true) {

					System.out.println("Enter Customer Mobile Number");
					mobile = scan.next();
					isValid = service.validateMobile(mobile);
					if (isValid)
						break;
					else
						System.out.println("Number Should be max 10 digits");
				}

				while (true) {

					System.out.println("Enter Customer Pincode");
					pincode = scan.next();

					isValid = service.validatePincode(pincode);
					if (isValid)
						break;
					else
						System.out.println("Pincode should be max 6 digit");
				}

				
				person.setAge(Integer.parseInt(age));
				person.setName(name);
				person.setAddress(address);
				person.setEmail(email);
				person.setPincode(pincode);
				person.setMobile(mobile);
				person.getAccountNumber();

				try {
					service.createAccountDetails(person);
				} catch (ClassNotFoundException e1) {

					e1.printStackTrace();
				} catch (RecordNotFoundException e1) {

					e1.printStackTrace();
				} catch (SQLException e1) {

					e1.printStackTrace();
				}
				System.out.println("Your AccountNumber is:" +person.getAccountNumber());
				break;
				
			case "2":
				while (true) {
					System.out.println("Enter Account Id");
					userAccId = scan.next();
					isValid = service.validateAccId(userAccId);
					if (isValid)
						break; 										// if user enter valid input then break
					else
						System.out
								.println("Please enter Valid Account Id eg.1234567");
				}
			
				try {
					System.out
							.println("Your Balanace is" + service.showBalance(Integer.parseInt(userAccId)));
				} catch (NumberFormatException | RecordNotFoundException
						| SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (ClassNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
									
			
				break;
			case "3":
				while (true) {
					System.out.println("Enter Account Id");
					userAccId = scan.next();
					isValid = service.validateAccId(userAccId);
					if (isValid)
						break; 										// if user enter valid input then break
					else
						System.out
								.println("Please enter Valid Account Id eg.1234567");
				}
				int id=Integer.parseInt(userAccId);
				person.setAccountNumber(id);
				//while (true) {
					System.out.println("Enter Amount");
					amount = scan.next();
					/*isValid = service.validateAmount(amount);
					if (isValid)
						break; 										// if user enter valid input then break
					else
						System.out.println("Please enter Amount eg.4000");
				}*/
				try {
					
					service.depositBalance(Integer.parseInt(userAccId),
							Double.parseDouble(amount));
					System.out.println("Transaction Successful");
				} catch (NumberFormatException | RecordNotFoundException e) {
					System.out.println(e);
				} catch (ClassNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

				break;
	/*		case "4":
				while (true) {
					System.out.println("Enter Account Id");
					userAccId = sc.next();
					isValid = userInput.validateAccId(userAccId);
					if (isValid)
						break; 										// if user enter valid input then break
					else
						System.out
								.println("Please enter Valid Account Id eg.1234567");
				}
				while (true) {
					System.out.println("Enter Amount");
					amount = sc.next();
					isValid = userInput.validateAmount(amount);
					if (isValid)
						break; 										// if user enter valid input then break
					else
						System.out.println("Please enter Amount eg.4000");
				}
				try {
					userInput.withdraw(Integer.parseInt(userAccId),
							Double.parseDouble(amount));
					System.out.println("Transaction Successful");
				} catch (NumberFormatException | BalanceException
						| RecordNotFoundException e) {
					System.out.println(e);
				}
				
				break;
			case "5":
				while (true) {
					System.out.println("Enter your Account Id");
					sourceAccId = sc.next();
					isValid = userInput.validateAccId(sourceAccId);
					if (isValid)
						break; 									// if user enter valid input then break
					else
						System.out
								.println("Please enter Valid Account Id eg.1234567");
				}
				while (true) {
					System.out.println("Enter receipent Account Id");
					targetAccId = sc.next();
					isValid = userInput.validateAccId(targetAccId);
					if (isValid)
						break; 									// if user enter valid input then break
					else
						System.out
								.println("Please enter Valid Account Id eg.1234567");
				}
				while (true) {
					System.out.println("Enter Fund transfer Amount");
					amount = sc.next();
					isValid = userInput.validateAmount(amount);
					if (isValid)
						break; // if user enter valid input then break
					else
						System.out.println("Please enter Amount eg.4000");
				}
				userInput.fundTransfer(Integer.parseInt(sourceAccId),
						Integer.parseInt(targetAccId),
						Double.parseDouble(amount));
				System.out.println("Transaction Successful");
				break;
			case "6":
				while (true) {
					System.out.println("Enter Account Id");
					userAccId = sc.next();
					isValid = userInput.validateAccId(userAccId);
					if (isValid)
						break; // if user enter valid input then break
					else
						System.out
								.println("Please enter Valid Account Id eg.1234567");
				}
				try {
					userInput.Showtransaction(Integer.parseInt(userAccId));
				} catch (NumberFormatException | RecordNotFoundException e) {
					System.out.println(e);
				}
				break;
			case "7" :
				System.out.println("Enter Account Id");
				System.out.println("Your Account Details are: "+d.findDetails(sc.nextInt()));
				
			
			case "8":
				System.out.println("Exited from the System");

				System.exit(0);
				break;
			*/
						default:
				break;
			}
		
	}}
}
