



import java.util.Map;




public class AccountTest {
	StoreUserdata accountDao = null;

	@Before
	public void setUp() throws Exception {

		accountDao = new StoreUserdata();
	}

	@After
	public void tearDown() throws Exception {
		accountDao = null;
	}

	@Test
	public void testShowbalanceValidDetails() {
		Account acc=new Account("Mayuresh", 9167968584L, "Shinde@gmail.com");
		accountDao.openAccount(acc);
		try {
			double amount = accountDao.showBalance(acc.getAccNo());
			Assert.assertNotNull(amount);
		} catch (RecordNotFoundException e) {
			System.out.println(e);
		}
	}
	@Test
	public void testShowbalanceInvalidDetails() {
		Account acc=new Account("Mayuresh", 9167968584L, "Shinde@gmail.com");
		accountDao.openAccount(acc);
		try {
			double amount = accountDao.showBalance(12345);
			Assert.assertNull(amount);
		} catch (RecordNotFoundException e) {
			System.out.println(e);
		}
	}
	@Test
	public void testDepositValidDetails() {
		Account acc=new Account("Mayuresh", 9167968584L, "Shinde@gmail.com");
		accountDao.openAccount(acc);
		try {
			double amount = acc.getBalance();
			accountDao.deposit(acc.getAccNo(), 4000);
			double upadatedAmount=acc.getBalance();
			amount+=4000;
			Assert.assertTrue(amount==upadatedAmount);;
		} catch (RecordNotFoundException e) {
			System.out.println(e);
		}
	}
	@Test
	public void testDepositInvalidDetails() {
		Account acc=new Account("Mayuresh", 9167968584L, "Shinde@gmail.com");
		accountDao.openAccount(acc);
		try {
			double amount = acc.getBalance();
			accountDao.deposit(acc.getAccNo(), 4000);
			Assert.assertFalse(amount==amount+2000);
		} catch (RecordNotFoundException e) {
			System.out.println(e);
		}
	}
	@Test
	public void testWithdrawValidDetails() {
		Account acc=new Account("Mayuresh", 9167968584L, "Shinde@gmail.com");
		accountDao.openAccount(acc);
		try {
			double amount = acc.getBalance();
			accountDao.withdraw(acc.getAccNo(), 4000);
			double upadatedAmount=acc.getBalance();
			amount-=4000;
			Assert.assertTrue(amount==upadatedAmount);;
		} catch (RecordNotFoundException | BalanceException e) {
			System.out.println(e);
		}
	}
	@Test
	public void testWithdrawInvalidDetails() {
		Account acc=new Account("Mayuresh", 9167968584L, "Shinde@gmail.com");
		accountDao.openAccount(acc);
		try {
			double amount = acc.getBalance();
			accountDao.deposit(acc.getAccNo(), 4000);
			Assert.assertFalse(amount==amount-2000);
		} catch (RecordNotFoundException e) {
			System.out.println(e);
		}
	}
}
