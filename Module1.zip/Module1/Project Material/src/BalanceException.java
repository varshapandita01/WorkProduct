package com.capgemini.mayuresh.exception;
public class BalanceException extends Exception {

	public BalanceException() {
	}

	public BalanceException(String message) {
		super(message);
	}

}
