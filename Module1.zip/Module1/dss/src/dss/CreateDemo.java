package dss;

import java.util.Iterator;
import java.util.List;
import java.util.TreeSet;

class DemoCmp implements Comparable// line 1
{
	int number;

	public DemoCmp(int num) {
		number = num;
	}
	public int compareTo(Object obj)
	{
	return number-obj.number;
	}
}

public class CreateDemo {
	public static void main(String[] args) {
		TreeSet<DemoCmp> set = new TreeSet<DemoCmp>();
		set.add(new Demo(8));
		set.add(new Demo(2));
		set.add(new Demo(3));
		
		
		List<String> i;
		i.listIterator();
		
	}
}