package dss;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class Crivitch {
	public static void main(String[] args) {
		int x = 0; // insert code here
		int y = 11;
		do {
		} while (x++ < y);
		System.out.println(x);
		List<Map<String, Map<String, Integer>>>m=new ArrayList<Map<String,Map<String,Integer>>>();
	}
}
