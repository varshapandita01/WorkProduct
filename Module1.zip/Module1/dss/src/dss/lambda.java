package dss;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;

class List1 {
	public static void listProblem() {
	 
		List p = new ArrayList();
		p.add(7);

		p.add(5);
		p.add(1);
		p.add(1);
		p.remove(1); // remove number from the index 1
		System.out.println(p);
	}
}

class Business {
}

class Hotel extends Business {
}

class Inn extends Hotel {
}

class Travel {
	List<Hotel> go() {

		// insert code here
		// Find out
		return null;
	}

}

public class lambda {

	public static void main(String[] args) {
		String arr[] = { "Java", "c++", "Pascal", "DevD", "Linux" };
		String arr1[] = {};
		// List1.listProblem();

		String[] s = { "map", "pen", "marble", "key" };
		Othello o = new Othello();
		Arrays.sort(s, o);
		for (String s2 : s)
			System.out.print(s2 + " ");
		System.out.println(Arrays.binarySearch(s, "map"));

	}

	static class Othello implements Comparator<String> {
		public int compare(String a, String b) {
			return b.compareTo(a);
		}
	}

}
