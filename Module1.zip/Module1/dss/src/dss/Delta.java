package dss;

import java.util.regex.Pattern;


interface Greek { } 

class Alpha implements Greek { } 

class Beta extends Alpha {} 

public class Delta extends Beta 
 { 
    public static void main() 
     { 
     //  Beta obj = new Beta(); // insert code here 
       
       //Greek objGrk = obj;
      //Alpha objAlpha = obj;
    //  Greek objGrk = (Beta)obj;
       // Beta objBeta = (Beta)(Alpha)obj;
     //  Greek objGrk = (Delta)obj;
    	
    	/*String str = "Hello World";
    	int []arr = {1,2,3,4,5};
    	display(str,arr);
    	}
    	public static void display(String str,int ...arr)
    	{
    	for(int num:arr){System.out.println(num);}
    	System.out.println(str);}*/
    	
    	System.out.println("hh");
    	
     }
 }
