package dss;
interface a{

		
	
}
public class eef {
	 eef(){
		
	}
	 private void s1(){
		 System.out.println("dsd");
	 }
public static void main(String[] args) {
	eef e=new eef();
	e.s1();
	
	int [][] a={{1,2,3}{1,2,4,5}};
}
}
