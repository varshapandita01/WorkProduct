package dss;

import java.util.ArrayList;
import java.util.List;

public class Colection {

	public static void main(String[] args) {
	
		List<List<Integer>> list=new ArrayList<List<Integer>>();
		list.add(1, null);
		

	}

}
