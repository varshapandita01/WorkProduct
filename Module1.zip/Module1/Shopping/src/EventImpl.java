public class EventImpl implements Event {

	@Override
	public void doSomething() {
		System.out.println("First event");

	}

	static class InnerEventImpl implements Event {

		@Override
		public void doSomething() {
			System.out.println("Second event");

		}

	}

	private class InnerEventImpl1 implements Event {

		@Override
		public void doSomething() {
			System.out.println("Third event");

		}

	}

	public void secondImpl() {
		Event e = new InnerEventImpl1();
		e.doSomething();

	}

	public void thirdImpl() {
		class NestedEventImpl implements Event {

			@Override
			public void doSomething() {
				System.out.println("Fourth event");

			}
		}
		Event e = new NestedEventImpl();
		e.doSomething();
	}

	public void oneMoreImpl() {
		Event e = new Event() {

			@Override
			public void doSomething() {
				System.out.println("Fifith event");

			}
		};
		e.doSomething();
	}

	public void oneLastImpl() {
		Event e=() ->System.out.println("Sixth Event");
		e.doSomething();
	}

	public static void main(String[] args) {
		EventImpl e = new EventImpl();
		e.doSomething();
		/*
		 * Event eI = e.new InnerEventImpl(); eI.doSomething();
		 */
		Event ie = new InnerEventImpl();
		ie.doSomething();
		e.secondImpl();
		e.thirdImpl();
		e.oneMoreImpl();
		e.oneLastImpl();
	}

}
