
public class MainShopping {

	public static void main(String[] args) {
		ShoppingCart Cart=new ShoppingCart();
		Cart.addProduct(new Product("Piza", 67));
		Cart.addProduct(new Product("Burger", 77));
		Cart.addProduct(new Product("Coke", 50));
		Cart.checkout();
	}

}
