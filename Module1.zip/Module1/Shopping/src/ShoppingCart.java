public class ShoppingCart {
	
	private Product[] cart /* Product */;
	public int idx;
	int total=0;
	

	public ShoppingCart() {
		cart=new Product[10];
		// TODO Auto-generated constructor stub
	}

	public void addProduct(Product product) {
		
			cart[idx++ ]=product;
		//}
	}

	public void checkout() {
		for(int i=0;i<idx;i++){
			System.out.println(cart[i].getName()+"\t"+cart[i].getPrice());
			total=total+cart[i].getPrice();
		}
		System.out.println("Total Amount Rs." +total);
	}
}
