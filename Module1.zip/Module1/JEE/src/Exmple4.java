import java.util.Scanner;


public class Exmple4 {

	public static void main(String[] args) {
		Scanner scan= new Scanner(System.in);
		 System.out.println("Enter the Cricketer Name:: and Score");
		String[] cricketerName =new String[5];
		int[]  Totalscore =new int[5];
		int ctr;
		for( ctr=0;ctr<5;ctr++){
			cricketerName[ctr]=scan.next();
			Totalscore[ctr]=scan.nextInt();
			
		}
		System.out.println("   Cricketer        Score");
		for( ctr=0;ctr<5;ctr++){
			System.out.print(ctr+1+"   ");
			System.out.print(cricketerName[ctr]  +"       ");
			
				System.out.println(Totalscore[ctr]);
			
		}
	}

}
