import java.util.Scanner;


public class Example6 {

	public static void main(String[] args) {
		Scanner scan= new Scanner(System.in);
		 System.out.println("Enter the first number::");
		int num1=scan.nextInt();
		 System.out.println("Enter the Second number::");
		int num2=scan.nextInt();
		 System.out.println("Enter the Operator 1.'+' 2.'-' 3.'*' 4.'/'::");
			 String operator=scan.next();
			 
			 switch(operator){
			 
			 case "+" : int addition=num1+num2;
			 			System.out.println("Addition is::"+addition);
			 			break;
			 			
			 case "-" : int subtraction=num1-num2;
	 			System.out.println("Subtraction is:::"+subtraction);
	 			break;
	 			
			 case "*" : int multiplication=num1*num2;
	 			System.out.println("Multiplication:::"+multiplication);
	 			break;
			 case "/" : int division=num1/num2;
	 			System.out.println("Division:::"+division);
	 			break;
			 }
		
		

	}

}
