import java.util.Scanner;


public class Example2 {

	public static void main(String[] args) {
		Scanner scan= new Scanner(System.in);
		 System.out.println("Enter the word::");
		 String word=scan.next();
		 System.out.println("Enter the letter::");
		 String letter=scan.next();
		 int count=0;
		 for(int i=0;i<word.length();i++){
			 char ch= word.charAt(i);
			 char ch1=letter.charAt(0);
			 if(ch==ch1){
				count++; 
			 }
		 }
System.out.println("Count of Letter:::"+count);
	}

}
