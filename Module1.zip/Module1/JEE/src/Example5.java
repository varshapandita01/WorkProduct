import java.util.Scanner;


public class Example5 {

	public static void main(String[] args) {
		Scanner scan =new Scanner (System.in);
		int number[]=new int[10];
		int even[]=new int[10];
		int odd[]=new int[10];
		System.out.println("Enter THe number");
		for(int ctr=0;ctr<10;ctr++)
		{
			number[ctr]=scan.nextInt();
			
		}
		for(int ctr=0;ctr<10;ctr++)
		if(number[ctr]%2==0){
			even[ctr]=number[ctr];
			System.out.println("Even:"+ even[ctr]);
		}
		else{
			odd[ctr]=number[ctr];
			System.out.println("Odd:"+ odd[ctr]);
		}
	
	}
}
