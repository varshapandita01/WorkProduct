import java.util.Scanner;

public class Example3 {
    	void example(){
		Scanner scan= new Scanner(System.in);
		 System.out.println("Enter the word::");
		 String word=scan.next();
		 int letter=0;
		 int digit=0;
		 for(int i=0;i<word.length();i++){
			 char ch= word.charAt(i);
			 if(Character.isLetter(ch)){
				 letter++;
			 }
			 if(Character.isDigit(ch)){
				 digit++;
			 }
		 }
		 System.out.println("Letters are::::"+letter);
		 System.out.println("Digits are:::::"+digit);
	
	}
	
	public static void main(String[] args) {
		Example3 obj=new Example3();
		obj.example();
		}

}
