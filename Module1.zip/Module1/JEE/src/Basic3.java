public class Basic3 {
public static void main(String[] args) {
	
}
}
