import java.util.Scanner;


public class Basic {

	public static void main(String[] args) {
		System.out.println("Hello");
		int num=1;
		System.out.println(num);
		String name="varsha";
		System.out.println(name);
		float height=1.1f;
		System.out.println(height);
		long mobileNumber=12345687900L;
		System.out.println(mobileNumber);
		
		Scanner Scan = new Scanner(System.in);
		int num1=Scan.nextInt();
		int num2=Scan.nextInt();
		int num3=Scan.nextInt();
		if(num1>num2 && num1>num3){
			System.out.println(num1 + " is Greater");
		}
		else if(num1<num2 && num2>num3){
			System.out.println(num2 + " is Greater");
	}
		else {
			System.out.println(num3 + " is Greater");
		}
}
}