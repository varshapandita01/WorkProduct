import java.util.Scanner;


public class Basic1 {
public static void main(String[] args) {
	Scanner Scan = new Scanner(System.in);
	System.out.println("Enter Number");
	int num1=Scan.nextInt();
	System.out.println("*****Write Table of " +num1);
	for(int num =1;num<11;num++){
		int result= num1*num;
		System.out.println(num1 +" * "+num+" = "+result);
	}
	System.out.println();
	System.out.println("*****Write Table of " +num1);
	int num=1;
	while(num<11){
		int result= num1*num;
		System.out.println(num1 +" * "+num+" = "+result);
		num++;
	}
	System.out.println();
	System.out.println("fdsbjhesgjbjs");
	System.out.println("*****Write Table of " +num1);
	int num2;
	String choice;
	do{
	System.out.println("enter user name");
	String username=Scan.next();
	System.out.println("hello " + username);
	System.out.println("do u wish to continue y or n");
	 choice=Scan.next();
	}while(choice.equals("y"));
}
}
