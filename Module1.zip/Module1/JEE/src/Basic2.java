import java.util.Scanner;


public class Basic2 {

	public static void main(String[] args) {
		Scanner Scan = new Scanner(System.in);
		int num[]=new int[5];
		for(int temp:num){
			temp=Scan.nextInt();
			//System.out.println(temp);
		}
		String username=Scan.next();
		String Password=Scan.next();
		
if(username.equalsIgnoreCase("Capgemini")){
	if(Password.equals("1234567")){
		System.out.println("wELCOME");
	}
	else{
		System.out.println("WRONG PASSWORD");
	}
}
	else{
		System.out.println("WRONG USERNAME");
		
	}
}
	

}
