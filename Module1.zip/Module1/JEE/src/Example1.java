import java.util.Scanner;


public class Example1 {

	public static void main(String[] args) {
	 Scanner scan= new Scanner(System.in);
	 System.out.println("Enter the word::");
	 String word=scan.next();
	 int vowels=0;
	 int consonant=0;
	 for(int ctr=0;ctr<word.length();ctr++){
		 char ch= word.charAt(ctr);
		 if(ch=='a' || ch=='e' || ch=='i' || ch=='o' || ch=='u'){
			 vowels++;
		}
		
		 else{
			 consonant++;
			
		 }
		 
	 }
	 System.out.println("Vowels:::"+vowels);
	 System.out.println("Consonants:::"+consonant);
	 
	}

}
