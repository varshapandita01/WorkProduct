import java.io.FileWriter;
import java.io.IOException;


public class FileWrite {
public static void main(String[] args) throws IOException {
		FileWriter writer=
				new FileWriter("Varsha.txt",true);
		//the above will create a file
		
		
		writer.write("/n..........hi");
	//	System.out.println();
		writer.close();
}
}
