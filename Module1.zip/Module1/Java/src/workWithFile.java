

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class workWithFile {

	public static void main(String[] args) throws IOException {
		try {
			FileReader fRead= new FileReader("Varsha.txt");
			char read[]=new char[(int) new File("Varsha.txt").length()];
			fRead.read(read);
			for(char temp:read){
				System.out.print(temp);
			}
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
