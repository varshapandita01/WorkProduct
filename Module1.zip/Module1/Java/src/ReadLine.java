import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;


public class ReadLine {
public static void main(String[] args) throws IOException {
	FileReader fRead= new FileReader("Varsha.txt");
	BufferedReader Read =new BufferedReader(fRead);
	String line=Read.readLine();
	while(line!=null){
		System.out.println(line);
		 line=Read.readLine();
	}
}
}
