import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;


public class InputStrem {

	public static void main(String[] args) {
		FileReader read;
		try {
			read = new FileReader("Varsha.txt");
		
		while(true){
			int ch=read.read();
			if(ch==-1){
				break;
			}
		}
		} catch (FileNotFoundException e) {
			System.out.println("  file not found ");		
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
