package day3;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public class SaveOuputStream {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		Employee emp=new Employee(13,"TOYOTO","BENZ");
		FileOutputStream fileInputStream =new FileOutputStream("Varsha.txt");
		ObjectOutputStream objectInputStream =new ObjectOutputStream(fileInputStream);
		objectInputStream.writeObject(emp);
		System.out.println("Object File Saved");
		fileInputStream.close();
		objectInputStream.close();
	}

}
