package day3;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class RegexMatches {
private static String regex="dog";
private static String input="The dog says meow."+"All dogs say meow";
private static String replace="cat";

	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Pattern p= Pattern.compile(regex);
		Matcher m=p.matcher(input);
		String INPUT = m.replaceAll(replace);
		System.out.println(input);
	}

}
