package day3;

public class df {
//	enum EnumDemo{A}
//	class Test{
//		enum EnumD{B}
//		void my_method(){
//		//	enumEnumC{D}
//		}
//	}
	static void methodA(short i){
		System.out.println("methodA(short)called");
	}
	static void methodA(int i){
		System.out.println("methodA(short)called");
	}
	static void methodB(float f){
		System.out.println("methodA(short)called");
	}
public static void main(String[] args) {
methodA(5);
//methodB(5.2);


	
	}
}
