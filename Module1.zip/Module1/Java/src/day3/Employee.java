package day3;


public class Employee {//extends Object
	
private String empName;
public String getEmpName() {
	return empName;
}

//setter method 
public void setEmpName(String empName) {
	this.empName = empName;
}

public int getEmpId() {
	return empId;
}

public void setEmpId(int empId) {
	this.empId = empId;
}

public boolean isOnBench() {
	return onBench;
}

public void setOnBench(boolean onBench) {
	this.onBench = onBench;
}

public char getGender() {
	return gender;
}

public void setGender(char gender) {
	this.gender = gender;
}

public float getSalary() {
	return salary;
}

public void setSalary(float salary) {
	this.salary = salary;
}

private int empId;
private boolean onBench;
private char gender;
private float salary;

//if the access specifier is not mentioned
//the default is package level scope 

public Employee(){
	
	System.out.println("default emp constrcutor ");
}
public Employee(int  id,String name,String name1){}
public Employee(String name, int id, char gender, 
		float salary, boolean bench) {
	//job of a constructor is to assign 
	//values to hte properties of the class 
	empName= name;
	empId=id;
	this.gender = gender;
	this.salary = salary;
	onBench=bench;
	
	
	
	
	// TODO Auto-generated constructor stub
}

//overriding 
//inheritance
//method is of java.lang.Object
public String toString(){
	
	//u write the logic so that 
	//all property values get printed 
	return "test";
	
}
}


