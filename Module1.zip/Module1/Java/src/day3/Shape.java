package day3;
public abstract class   Shape {
public abstract double CalArea() ;
Shape(){}

public abstract double calArea();
public class Triangle extends Shape
{
int base,height;
public Triangle(int base,int height){
this.base = base;
this.height=height;
}
public double calArea(){
return 0.5*base*height;
}
public void main(String []args){
Shape ref = new Triangle(3,4);
System.out.println(ref.calArea());
}
@Override
public double CalArea() {
	// TODO Auto-generated method stub
	return 0;
}
}
}