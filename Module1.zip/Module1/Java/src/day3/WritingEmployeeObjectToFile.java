package day3;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.StreamCorruptedException;



public class WritingEmployeeObjectToFile {
	
	public static void main(String[] args) {
		
		Employee emp =
				new Employee();
		emp.setEmpId(120);
		emp.setEmpName("hds");
		//populate this object with values 
		//either via setter or constructor 
		//injection 
		
		
		//writeObject of ObjectOutputStream
		
		
		//output is that the entire emp obj
		//contents will be written to a file
		
		
		//the file contents wont be readable
		//to prove that the writing has been 
		//done correctly
		//read from the file and display on console
		
		//readObject //ObectInputStream
		
		
		try {
			FileInputStream fileInputStream =new FileInputStream("Varsha.txt");
			ObjectInputStream objectInputStream =new ObjectInputStream(fileInputStream);
			
			try{
				emp= (Employee) objectInputStream.readObject();
				System.out.println(emp.toString());
			}
			 catch (ClassNotFoundException c) {
					// TODO Auto-generated catch block
					c.printStackTrace();
				}
			finally{
				fileInputStream.close();
				objectInputStream.close();
			}
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	
		
		
		
	}

}
