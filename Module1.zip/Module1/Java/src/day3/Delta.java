package day3;



interface Greek { } 

class Alpha implements Greek { } 

class Beta extends Alpha {} 

class Delta extends Beta 
 { 
    public static void main( String[] args ) 
     { 
       Beta obj = new Beta(); // insert code here 
      // Greek objGrk = (Delta)obj;
   //    Beta objBeta = (Beta)(Alpha)obj;
      // Greek objGrk = (Alpha)obj;
       //Alpha objAlpha = obj;
       Greek objGrk = (Beta)(Alpha)obj;
     }
 }
