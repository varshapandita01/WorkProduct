package day3;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.util.Scanner;

public class UsingScannerClassToReadFile {


	
	public static void main(String[] args) throws FileNotFoundException {
		
		FileInputStream fis=
				new FileInputStream("Varsha.txt");
		
		
		Scanner scan = new Scanner(fis);
	
		  while (scan.hasNextLine()) {
				String line = scan.nextLine();
	            System.out.println(line);
	        }
	}
}