import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.Scanner;


public class PrintWrite {

	public static void main(String[] args) throws FileNotFoundException {
	Scanner scan = new Scanner(System.in);
	PrintWriter print=new PrintWriter("Varsha.txt");
	String  choice;
	do{
	System.out.println("enter name");
	String name=scan.next();
	System.out.println("enter age");
	int age=scan.nextInt();
	//print.append(name + "" + age);
	print.println(name + "" + age);
	System.out.println("do u wish to continue yes or no");
	choice=scan.next();
	}while(choice.equals("yes"));
	print.close();
	}
}
