package Lab10;
public class FileProgram {
public static void main(String[] args) {
	
	String src="file.txt";
	String target="copy.txt";
	CopyDataThread cdt=new CopyDataThread(src,target);
	cdt.start();
	
}
}
