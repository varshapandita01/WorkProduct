package Lab9;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class Exercise3 {
public static Map getSquares(int size){
	int []number=new int[5];
	int[] number1=new int[5];
	Scanner scan=new Scanner(System.in);
	System.out.println("Enter the Array");
	for(int i=0;i<5;i++){
		number[i]=scan.nextInt();
	}
	for(int i=0;i<5;i++){
		number1[i]=number[i]*number[i];
	}
	HashMap<Integer, Integer> map = new HashMap<>();
	for(int i=0;i<5;i++){
	map.put(number[i],number1[i]);
	}
	return map;
}
	public static void main(String[] args) {
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter the size");
		int size=scan.nextInt();
		
		HashMap<Integer, Integer> map = (HashMap<Integer, Integer>) getSquares(size);
		
		System.out.println(map);
	}

}
