package Lab9;


import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

public class Exercise1 {
	public List getValues (HashMap<String, Integer> map){
		 List<Integer> mapValues = new ArrayList<>(map.values());
		 Collections.sort(mapValues);
		return mapValues;
		
	}

	public static void main(String[] args) {
		HashMap<String, Integer> map = new HashMap<>();
		map.put("jack",23);
		map.put("scott", 31);
		map.put("java", 21);
		map.put("lili", 25);
		Exercise1 Exercise1=new Exercise1();
		System.out.println(Exercise1.getValues(map));
	}

}
