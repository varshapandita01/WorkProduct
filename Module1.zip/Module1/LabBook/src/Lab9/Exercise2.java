package Lab9;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

import Lab3.Exercise4;

public class Exercise2 {
	 static final int MAX_CHAR = 256; 
public static Map countCharacter (char c1[]){
	
	Scanner scan = new Scanner(System.in);
	
	
	
	int len=c1.length;

	 int[] count = new int [MAX_CHAR];

	 for (int i = 0; i < len; i++) {
            count[c1[i]]++; 
      
        }
	 
        for (int i = 0; i < len; i++) { 
        	int find = 0; 
            for (int j = 0; j <= i; j++) { 
  
                // If any matches found 
                if (c1[i] == c1[j])  
                    find++;  
            //  System.out.println("find"+find);
            } 
  
            if (find == 1)  
                System.out.println("Number of Occurrence of " + 
                 c1[i] + " is:" + count[c1[i]]);  
            
        }
           HashMap<Character, Integer> map= new HashMap<Character, Integer>();
           for(int i=0;i<len;i++){
          map.put(  c1[i], count[c1[i]]);
        }
          
		return map; 
    
}
	public static void main(String[] args) {
		char c1[]={'a','c','d','a','a'};
		Exercise2 obj=new Exercise2 ();
		System.out.println("final\t"+obj.countCharacter(c1));

	}

}
