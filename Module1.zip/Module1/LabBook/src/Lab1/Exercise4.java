package Lab1;
import java.util.Scanner;


public class Exercise4 {
	boolean checkNumber(int number){
		boolean checkNumber =false;
		while(number%2==0){
			number=number/2;
			if(number==1){
				checkNumber=true;
			}
			else{
				checkNumber=false;
			}
		}
		return checkNumber;
	}
	public static void main(String[] args) {
		Scanner scan= new Scanner(System.in);
		System.out.println("Enter the number");
		int num=scan.nextInt();
		Exercise4 obj=new Exercise4();
		System.out.println("Power of 2:::"+obj.checkNumber(num));
	}

}
