package Lab1;

import java.util.Scanner;

public class Exercise1 {
	int calculateSum(int n) {

		int sum = 0;
		for (int ctr = 1; ctr <= n; ctr++) {
			if (ctr % 3 == 0 || ctr % 5 == 0) {// if divisible by 3 or 5 then
												// sum
				sum += ctr;
			}
		}
		return sum;
	}

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter the size");
		int size = scan.nextInt();// enter size
		Exercise1 obj = new Exercise1();
		System.out.println("Sum of numbers Divisible by 3 and 5 is::::"
				+ obj.calculateSum(size));

	}

}
