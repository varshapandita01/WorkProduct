package Lab1;

import java.util.Scanner;

public class Exercise3 {

	boolean checkNumber(int number) {
		boolean checkNumber = false;
		while ((number % 10 > 0)) { 
			int newNumber = number % 10;
			number = number / 10;
			int otherNumber = number % 10;
			if (newNumber >= otherNumber) {
				checkNumber = true;
				continue;
			} else {
				checkNumber = false;
				break;
			}
		}
		// if(number==0){
		// checkNumber=true;
		// }
		return checkNumber;
	}

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter the number");
		int num = scan.nextInt();
		Exercise3 obj = new Exercise3();
		System.out.println("Is Number  in increasing order::"
				+ obj.checkNumber(num));
	}

}
