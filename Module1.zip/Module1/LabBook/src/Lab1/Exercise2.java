package Lab1;

import java.util.Scanner;

public class Exercise2 {
	int calculateDifference(int n) {

		int sum = 0;
		int sumOfNumbers = 0;
		for (int ctr = 1; ctr <= n; ctr++) {
			sumOfNumbers += ctr;
		}
		double sumOfSquares = Math.pow(sumOfNumbers, 2);
		System.out.println(sumOfSquares);
		double squareOfSum = 0;
		for (int ctr = 1; ctr <= n; ctr++) {
			double Squares = Math.pow(ctr, 2);
			squareOfSum += Squares;
		}
		System.out.println(squareOfSum);
		double difference = squareOfSum - sumOfNumbers;
		return (int) difference;

	}

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter the size");
		int size = scan.nextInt();
		Exercise2 obj = new Exercise2();
		System.out
				.println("Difference  between the sum of the squares and sqaure of sum is::"
						+ obj.calculateDifference(size));

	}

}
