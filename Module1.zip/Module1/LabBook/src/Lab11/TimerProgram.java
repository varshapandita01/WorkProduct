package Lab11;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class TimerProgram {
	
	static int counter = 0;
	
	public static void main(String[] args) {
		ExecutorService executor = Executors.newFixedThreadPool(3);
		Runnable rable = () -> {
			while (true) { // run infinitely
				try {
					Thread.sleep(1000); // sleep it 1 second for reset
					if (counter < 10) {
						counter++;
						// print current time
						System.out.println("Time is " + counter);
					} else {
						counter = 0;
						System.out.println("Timer Reset");
					}
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
		};
		
		executor.execute(rable);
		executor.shutdown();
	}
}
