package Lab11;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class Exercise1ExecutorService {

	public static void main(String[] args) {
		ExecutorService executorService = Executors.newSingleThreadExecutor();// Concurrency
		// Used here
		// only single
		// will be
		// executed

		ExecutorService executorService1 = Executors.newFixedThreadPool(2);
		Runnable runnable = () -> System.out.println("Hello Pool");

		Runnable runnable1 = () -> System.out.println("Two Pools");
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
		}

		executorService.execute(runnable);
		executorService.execute(runnable);

		executorService.shutdown();

		executorService1.execute(runnable1);
		executorService1.execute(runnable1);

		executorService1.shutdown();

	}

}
