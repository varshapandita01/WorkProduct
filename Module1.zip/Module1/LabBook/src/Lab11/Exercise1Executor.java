package Lab11;

import java.util.concurrent.Executor;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class Exercise1Executor {

	public static void main(String[] args) {
		 Executor executor = Executors.newSingleThreadExecutor();
		// this is
		// also ryt but in this execution keeps on runnung so for shutdown we
		// use Executor service
		
		// Used here
		// only single
		// will be
		// executed

	
		Runnable runnable = () -> System.out.println("Hello Pool");
		
		Runnable runnable1 = () -> System.out.println("Two Pools");
		try {
			Thread.sleep(3000);
		}catch (InterruptedException e) {}
		
		executor.execute(runnable);
		executor.execute(runnable);
		
		

	}

}
