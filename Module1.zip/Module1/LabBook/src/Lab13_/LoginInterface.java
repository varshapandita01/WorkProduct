package Lab13_;

@FunctionalInterface
public interface LoginInterface {

	String showData();
}
