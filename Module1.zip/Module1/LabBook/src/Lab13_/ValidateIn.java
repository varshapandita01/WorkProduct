package Lab13_;

public interface ValidateIn {

	boolean isValid(String userName,String password);
}
