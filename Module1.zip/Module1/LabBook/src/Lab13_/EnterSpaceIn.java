package Lab13_;

public interface EnterSpaceIn {

	 String enterSpace(String s);
}
