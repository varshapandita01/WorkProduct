package Lab4;

import java.util.Scanner;

public class Exercise1 {
	static int getSumOfCubes(int n) {
		double sumOfCube = 0;
		while (n > 0) {
			if (n % 10 != 0) {
				int n1 = n % 10;

				sumOfCube += Math.pow(n1, 3);
			}
			n = n / 10;

		}

		return (int) sumOfCube;
	}

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter length");
		int length = scan.nextInt();
		int sumOfCubes = getSumOfCubes(length);
		System.out.println(sumOfCubes);
	}

}
