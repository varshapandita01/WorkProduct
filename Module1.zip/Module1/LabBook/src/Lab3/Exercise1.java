package Lab3;

import java.util.Arrays;
import java.util.Scanner;

public class Exercise1 {
	void getSecondSmallest (int size){
		int array[]=new int[size];
		System.out.println("Enter the array");
		Scanner scan=new Scanner(System.in);
		
		for(int i=0;i<size;i++){
				array[i]=scan.nextInt();
		}
	
		/*for(int i=0;i<size-1;i++){
			for(int j=0;j<size-i-1;j++){
				if(array[j]>array[j+1]){
					int temp=array[j];
					array[j]=array[j+1];
					array[j+1]=temp;
				}
			}
		}*/
		Arrays.sort(array);
		System.out.println("Sorted Array:::");
		for(int i=0;i<size;i++){
			System.out.println(array[i]);
	}
		System.out.print("Second Smallest Number is:::");
		System.out.println(array[1]);
	
	}
	public static void main(String[] args) {
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter the size");
		int size=scan.nextInt();
		Exercise1 obj=new Exercise1();
		obj.getSecondSmallest(size);
	}

}
