package Lab3;

import java.util.Arrays;
import java.util.Scanner;

public class Exercise2 {
	public void stringAlphabetically() {
		Scanner scan = new Scanner(System.in);
		
		System.out.println("Enter the size");
		int size = scan.nextInt();
	
		String s1[] = new String[size];
		System.out.println("Enter array ");
		for (int i = 0; i < size; i++) {
			s1[i] = scan.next();
		}
		for (int i = 0; i < size; i++) {
			for (int j = i + 1; j < size; j++) {

				if (s1[i].compareTo(s1[j]) > 0) {
					String temp = s1[i];
					s1[i] = s1[j];
					s1[j] = temp;
				}
			}
		}
		for (String string : s1) {
			System.out.println(string);
		}
		
		if (s1.length % 2 == 0) {
			for (int i = 0; i < s1.length / 2; i++) {
				s1[i] = s1[i].toUpperCase();
			}
			for (int i = s1.length / 2; i < s1.length; i++) {
				s1[i] = s1[i].toLowerCase();
			}
		} else {
			for (int i = 0; i < (s1.length / 2) + 1; i++) {
				s1[i] = s1[i].toUpperCase();
			}
			for (int i = (s1.length / 2) + 1; i < s1.length; i++) {
				s1[i] = s1[i].toLowerCase();
			}
		}
		for (String string : s1) {
			System.out.println(string);
		}
	}

	public static void main(String[] args) {
		Exercise2 obj = new Exercise2();
		obj.stringAlphabetically();
	}

}
