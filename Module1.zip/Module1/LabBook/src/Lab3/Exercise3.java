package Lab3;

import java.lang.reflect.Array;
import java.util.Arrays;
import java.util.Scanner;

public class Exercise3 {

	public static int[] getSorted() {

		Scanner scan = new Scanner(System.in);

		System.out.println("Enter the size");
		int size = scan.nextInt();
		int arr[] = new int[size];
		int temp = size;
		System.out.println("Enter array elements");
		for (int i = 0; i < size; i++) {
			arr[i] = scan.nextInt();
		}
		for (int i = 0; i < size; i++) {
			arr[temp - 1] = arr[i];
			temp = temp - 1;
		}
		for (int i = 0; i < size - 1; i++) {
			for (int j = 0; j < size - i - 1; j++) {
				if (arr[j] > arr[j + 1]) {
					int temp1 = arr[j];
					arr[j] = arr[j + 1];
					arr[j + 1] = temp1;
				}
			}
		}

		return arr;

	}

	public static void main(String[] args) {
		// Exercise2 obj=new Exercise2();
		int[] arr = getSorted();
		System.out.println(Arrays.toString(arr));

	}

}
