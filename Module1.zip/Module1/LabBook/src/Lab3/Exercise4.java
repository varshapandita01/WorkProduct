package Lab3;

import java.util.Scanner;

public class Exercise4 {
    static final int MAX_CHAR = 256; 
		public void characterTypeRepeat(){
			Scanner scan = new Scanner(System.in);
			
			
			char c1[]={'a','c','d','a','a'};
			int len=c1.length;
		
			 int[] count = new int [MAX_CHAR];
		
			 for (int i = 0; i < len; i++) {
		            count[c1[i]]++; 
		      System.out.println(c1[i]+" "+count[c1[i]]);
		        }
			 
		        for (int i = 0; i < len; i++) { 
		        	int find = 0; 
		            for (int j = 0; j <= i; j++) { 
		  
		                // If any matches found 
		                if (c1[i] == c1[j])  
		                    find++;  
		            //  System.out.println("find"+find);
		            } 
		  
		            if (find == 1)  
		                System.out.println("Number of Occurrence of " + 
		                 c1[i] + " is:" + count[c1[i]]);             
		        } 
		    } 

	
	public static void main(String[] args) {
		Exercise4 obj=new Exercise4 ();
		obj.characterTypeRepeat();
	}

}
