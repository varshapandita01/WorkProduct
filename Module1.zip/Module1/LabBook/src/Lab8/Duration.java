package Lab8;
import java.time.LocalDate;
import java.time.Period;
import java.util.Scanner;


public class Duration {
	public void calculateDuration(LocalDate d1, LocalDate d2) {
		Period p = Period.between(d1, d2);
		System.out.println("No of years: " + p.getYears());
		System.out.println("No of months: " + p.getMonths());
		System.out.println("No of days: " + p.getDays());
	}
	public static void main(String[] args) {
		LocalDate date1 = LocalDate.now();
		System.out.println("Today: " + date1);
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter date:");
		String input = sc.nextLine();
		LocalDate date2 = LocalDate.parse(input);
		Duration d = new Duration();
		d.calculateDuration(date1,date2);
	}
}
