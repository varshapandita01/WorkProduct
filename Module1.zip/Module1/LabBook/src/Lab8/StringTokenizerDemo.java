package Lab8;
import java.util.Scanner;
import java.util.StringTokenizer;


public class StringTokenizerDemo {
	
	public void displayAndCount(String input){
		int total=0,n=0;
		StringTokenizer st1 = new StringTokenizer(input); 
		System.out.println("Numbers");
        while (st1.hasMoreTokens()) {
        	n = Integer.parseInt(st1.nextToken());
	    	total +=n;  
	    	System.out.println(n);
        }
        System.out.println("\nTotal: " + total);
	}
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter integers: ");
		String input = sc.nextLine();
		StringTokenizerDemo sd = new StringTokenizerDemo();
		sd.displayAndCount(input);
	}
}
