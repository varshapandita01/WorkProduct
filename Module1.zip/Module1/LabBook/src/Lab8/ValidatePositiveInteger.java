package Lab8;
import java.util.Scanner;
public class ValidatePositiveInteger {
	
	public boolean validate(String input){
		int flag=0;
		for (int i = 1; i < input.length(); i++) {
			if (input.codePointAt(i-1) > input.codePointAt(i)) {
				flag=1;
				break;
			}
		}
		if (flag==0) {
			return true;
		} else {
			return false;
		}
	}
	
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter a string:");
		String input = sc.next();
		ValidatePositiveInteger vpi = new ValidatePositiveInteger();
		if ( vpi.validate(input) ){
			System.out.println(input + " is a positive integer");
		} else{
			System.out.println(input + " is not a positive integer");
		}
	}
}
