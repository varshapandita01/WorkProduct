package Lab5;

import java.util.Scanner;

public class Exercise5 {
public void  validate(int age) throws AgeValidationException{
	if(age>15){
		System.out.println("Validated and Age is :"+age);
	}
	else{
		throw new AgeValidationException("Age must be above 15");
	}
}
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter Age");
		int age=scan.nextInt();
		scan.close();
		Exercise5 obj=new Exercise5();
		try{
			obj.validate(age);
		}
		catch(AgeValidationException e){
			System.out.println(e.getMessage());
		}
	}

	

}
