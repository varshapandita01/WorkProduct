package Lab5;

public class EmployeeException extends Exception {

	public EmployeeException() {
		
	}

	public EmployeeException(String msg) {
		super(msg);
	}
}
