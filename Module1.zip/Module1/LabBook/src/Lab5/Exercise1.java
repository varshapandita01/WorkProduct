package Lab5;

import java.util.Scanner;

public class Exercise1 {

	public static void main(String[] args)  {

		Scanner scan = new Scanner(System.in);
		System.out.println("Enter the Color choice: ");
		String choice = scan.next();
		switch (choice) {
		case "Red":
			System.out.println("Stop");
			break;
		case "Yellow":
			System.out.println("Ready");
			break;
		case "Green":
			System.out.println("Go");
			break;
		default:
			try {
				throw new WrongChoiceException(
						"You have entered a wrong color choice");
			} catch (WrongChoiceException e) {
				System.out.println(e);
				
			}

		}

	}

}
