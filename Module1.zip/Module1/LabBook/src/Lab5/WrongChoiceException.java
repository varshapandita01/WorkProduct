package Lab5;

public class WrongChoiceException extends Exception {

	public WrongChoiceException() {
		super();

	}

	public WrongChoiceException(String msg) {
		super(msg);

	}

}
