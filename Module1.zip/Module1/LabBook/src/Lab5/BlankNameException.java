package Lab5;

public class BlankNameException extends Exception {

	public BlankNameException() {
	
	}
	public BlankNameException(String message) {
		super(message);
		
	}
}
