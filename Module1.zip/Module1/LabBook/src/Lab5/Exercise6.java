package Lab5;

import java.util.Scanner;

public class Exercise6 {
	public static void Employee(Double sal) throws EmployeeException {
		if(sal<3000){
			throw new EmployeeException("No eligible");
		}
		else{
			System.out.println("Eligible");
		}
	}
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Employee Salary");
		Double sal=sc.nextDouble();
		try {
			Exercise6.Employee(sal);
		} catch (EmployeeException e) {
			System.out.println(e);
		}

	}

}
