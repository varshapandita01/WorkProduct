package Lab5;

import java.util.Scanner;

public class Exercise4 {
		public  void check(String firstName,String lastName) throws BlankNameException {
			if((!(firstName.isEmpty()&& lastName.isEmpty())&&  firstName.lastIndexOf(0)!=-1 && lastName.lastIndexOf(0)!=-1 )){
				System.out.println("Full Name: "+firstName+" "+lastName);
				
			}
			else{
				throw new BlankNameException ("First Name and Last Name cannot be blank ");
			}
		}
	public static void main(String[] args)  {
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter first Name");
		String firstName=scan.nextLine();
		System.out.println("Enter Last Name");
		String lastName=scan.nextLine();
		scan.close();
		Exercise4 obj=new Exercise4();
		try{
			obj.check(firstName, lastName);
		}
		catch(BlankNameException e){
			System.out.println(e.getMessage());
		}
	}
	

}
