package Lab5;

public class AgeValidationException extends Exception {

	public AgeValidationException() {
	
	}

	public AgeValidationException(String message) {
		super(message);
		
	}


}
