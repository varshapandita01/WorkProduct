package Lab13;

import java.util.Scanner;

interface StringSpace {
    void operation(String a);   
}
public class Exercise2 {

	public static void main(String[] args) {
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter String");
		String string=scan.next();
		StringSpace space = (String a)->System.out.println(a.replace("", " ").trim()); 
		  
		space.operation(string); 
		

	}

}
