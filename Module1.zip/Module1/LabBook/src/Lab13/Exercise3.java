package Lab13;

import java.util.Scanner;



interface EmailValidator {
    void validator(String email,String password);   
}
public class Exercise3 {

	public static void main(String[] args) {
		String email1="varshap";
		String passcode="1234567";
		Scanner scanner=new Scanner(System.in);
		System.out.println("Enter Email");
		String a=scanner.next();
		System.out.println("Enter Password");
		String b=scanner.next();
		EmailValidator validator = (String email,String password)->System.out.println((email1==email && passcode==password ? true : false )); 
		  
		validator.validator(a,b); 

	}

}
