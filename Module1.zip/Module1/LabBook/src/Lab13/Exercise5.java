package Lab13;

import java.util.Scanner;

@FunctionalInterface
interface factorials {
	public void fact();
}

public class Exercise5 {
	public void factorial() {
		Scanner scanner=new Scanner(System.in);
		System.out.println("Enter First value");
		int a=scanner.nextInt();
		int fact = 1;
		while (a > 0) {
			fact *= a;
			a--;
		}
		System.out.println(fact);

	}

	public static void main(String[] args) {
		Exercise5 obj = new Exercise5();
		factorials fact = obj::factorial;
		fact.fact();

	}

}
