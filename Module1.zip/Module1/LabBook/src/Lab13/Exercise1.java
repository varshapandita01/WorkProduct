package Lab13;

import java.util.Scanner;



interface IntegerMath {
    void operation(int x, int y);   
}
public class Exercise1 {

	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		System.out.println("Enter First value");
		int a=scanner.nextInt();
		System.out.println("Enter SEcond Value");
		int b=scanner.nextInt();
		
		IntegerMath raisedPower = (int x,int y)->System.out.println(Math.pow(x, y)); 
		  
		raisedPower.operation(a,b); 
	}

}
