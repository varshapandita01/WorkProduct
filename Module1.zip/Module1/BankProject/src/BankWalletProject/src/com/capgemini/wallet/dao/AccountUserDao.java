package com.capgemini.wallet.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

import com.capgemini.wallet.bean.AccountUser;
import com.capgemini.wallet.bean.Transaction;
import com.capgemini.wallet.exception.WalletException;
import com.capgemini.wallet.utility.JdbcUtil;

public class AccountUserDao implements IAccountUserDao {

	AccountUser au = new AccountUser();

	private Map<Integer, AccountUser> Accuser = new HashMap<>();

	private Map<Integer, Double> Wallet = new HashMap<>();

	Transaction[] txns;
	int idxx;

	@Override
	public void createUser(String name, String age, String address, String email)
			throws WalletException {

		au.setName(name);
		au.setAge(Integer.parseInt(age));
		au.setAddress(address);
		au.setEmail(email);
		double amount = 0;
		txns = new Transaction[10];

		// txns[idxx++] = new Transaction("CR", au.getBalance(), amount);

	}

	@Override
	public void storeIntoMap() {
		Connection connection = null;
		PreparedStatement statement = null;
		int code = (int) (Math.random() * 1000);
		au.setCode(code);
		Accuser.put(code, au);
		System.out.println("Your account created successfully :");
		System.out.println("Your account number is " + au.getCode());
		System.out.println(Accuser);
		try {
			connection = JdbcUtil.getConnection();
		} catch (ClassNotFoundException | WalletException we) {
			we.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			statement = connection.prepareStatement(QueryMapper.insertDetails);

			statement.setString(1, au.getName());
			statement.setInt(2, au.getAge());
			statement.setString(3, au.getAddress());
			statement.setString(4, au.getEmail());
			statement.setInt(5, au.getCode());
			statement.setDouble(6, au.getBalance());

			statement.executeUpdate();

		} catch (SQLException e) {
			System.err.println("Unable to fetch data" + e);

		} finally {

			try {
				try {
					statement.close();
				} catch (SQLException e) {

					throw new WalletException(
							"unable to close statement object");
				}
			} catch (Exception e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}

			try {
				try {
					connection.close();
				} catch (SQLException e) {

					throw new WalletException(
							"unable to close connection object");
				}
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

	}

	@Override
	public Map<Integer, AccountUser> displayAccountUser() {

		return null;
	}

	@Override
	public void storeIntoWalletMap() {

		Wallet.put(au.getCode(), au.getBalance());

	}

	@Override
	public Map<Integer, AccountUser> displayWalletDetails() {

		return null;
	}

	@Override
	public double showBalance(int Accno) throws WalletException {
		// System.out.println("Your balance is :" + au.getBalance());
		Connection connection = null;
		PreparedStatement statement = null;
		ResultSet resultSet = null;
		/*
		 * if(Accuser.containsKey(Integer.parseInt(Accno))) return true; else
		 * throw new WalletException("You need to register first");
		 */

		try {
			connection = JdbcUtil.getConnection();
			statement = connection.prepareStatement(QueryMapper.ShowBalance);
			statement.setInt(1, Accno);

			resultSet = statement.executeQuery();
			if (resultSet.next())
				return resultSet.getDouble("balance");
			// takes the record pointer to the first row and then on next row

		} catch (SQLException | WalletException we) {
			we.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {

			try {
				statement.close();
			} catch (SQLException e) {

				throw new WalletException("unable to close statement object");
			}

			try {
				connection.close();
			} catch (SQLException e) {

				throw new WalletException("unable to close connection object");
			}

		}
		return 0;

	}

	@Override
	public void depositMoney(double amount, int accno) throws WalletException {
		Connection connection = null;
		PreparedStatement statement = null;

		/*
		 * au.setBalance(amount + au.getBalance()); Wallet.put(au.getCode(),
		 * au.getBalance());
		 * System.out.println(amount+"Rs. credited to you account"
		 * +au.getCode()+"successfully "); txns[idxx++] = new
		 * Transaction("CR",amount, au.getBalance());
		 */
		try {
			connection = JdbcUtil.getConnection();
			statement = connection.prepareStatement(QueryMapper.Balance);
			statement.setDouble(1, amount);
			statement.setInt(2, accno);

			ResultSet resultSet = statement.executeQuery();

			insertIntoTransaction(accno, "CR", amount, showBalance(accno));
			if (resultSet.next())
				System.out.println(amount + "Rs. credited to you account"
						+ accno + "successfully ");

		} catch (ClassNotFoundException | WalletException we) {
			we.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {

			try {
				statement.close();
			} catch (SQLException e) {

				throw new WalletException("unable to close statement object");
			}

			try {
				connection.close();
			} catch (SQLException e) {

				throw new WalletException("unable to close connection object");
			}
		}
		return;

	}

	@Override
	public void withdrawMoney(double amount, int Accno) throws WalletException {

		/*
		 * if (amount > au.getBalance()) {
		 * System.out.println("Insufficient Funds :-( "); } else {
		 * au.setBalance(au.getBalance() - amount); Wallet.put(au.getCode(),
		 * au.getBalance()); System.out .println(amount +
		 * "\tWas Debited on your Account \nif the transaction was invalid please contact your branch soon  "
		 * );
		 * 
		 * txns[idxx++] = new Transaction("DR", amount,au.getBalance()); }
		 */

		Connection connection = null;
		PreparedStatement statement = null;

		/*
		 * au.setBalance(amount + au.getBalance()); Wallet.put(au.getCode(),
		 * au.getBalance());
		 * System.out.println(amount+"Rs. credited to you account"
		 * +au.getCode()+"successfully "); txns[idxx++] = new
		 * Transaction("CR",amount, au.getBalance());
		 */
		try {
			connection = JdbcUtil.getConnection();
			statement = connection.prepareStatement(QueryMapper.WithDraw);
			statement.setDouble(1, amount);
			statement.setInt(2, Accno);

			ResultSet resultSet = statement.executeQuery();
			insertIntoTransaction(Accno, "DR", amount, showBalance(Accno));
			if (resultSet.next())
				System.out.println(amount + "Rs. debited to you account"
						+ Accno + "successfully ");

		} catch (ClassNotFoundException | WalletException we) {
			we.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {

			try {
				statement.close();
			} catch (SQLException e) {

				throw new WalletException("unable to close statement object");
			}

			try {
				connection.close();
			} catch (SQLException e) {

				throw new WalletException("unable to close connection object");
			}
		}

	}

	@Override
	public void fundTransfer(double amount) {

		/*
		 * if (amount > au.getBalance()) {
		 * System.out.println("Insufficient Funds :-( "); } else {
		 * au.setBalance(au.getBalance() - amount); Wallet.put(au.getCode(),
		 * au.getBalance()); System.out .println(amount +
		 * "\tWas Debited on your Account \nif the transaction was invalid please contact your branch soon  "
		 * ); txns[idxx++] = new Transaction("FT", amount, au.getBalance()); }
		 */

	}

	@Override
	public void printTransaction(int Accno) throws WalletException {
		Connection connection = null;
		PreparedStatement statement = null;
		/*
		 * for (int i = 0; i < idxx; i++) {
		 * System.out.println(txns[i].printDetails());
		 * 
		 * }
		 */
		try {
			connection = JdbcUtil.getConnection();
			statement = connection.prepareStatement(QueryMapper.PrintTrans);
			statement.setInt(1, Accno);

			ResultSet resultSet = statement.executeQuery();
			while (resultSet.next()) {
				System.out.println(resultSet.getString("type") + "\t"
						+ resultSet.getDouble("amount") + "\t"
						+ resultSet.getDouble("balance"));

			}

		} catch (ClassNotFoundException | WalletException we) {
			we.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {

			try {
				statement.close();
			} catch (SQLException e) {

				throw new WalletException("unable to close statement object");
			}

			try {
				connection.close();
			} catch (SQLException e) {

				throw new WalletException("unable to close connection object");
			}
		}

	}

	@Override
	public boolean validateAccountNo(int Accno) throws WalletException {
		Connection connection = null;
		PreparedStatement statement = null;

		/*
		 * if(Accuser.containsKey(Integer.parseInt(Accno))) return true; else
		 * throw new WalletException("You need to register first");
		 */

		try {
			connection = JdbcUtil.getConnection();
			statement = connection.prepareStatement(QueryMapper.Accno);
			statement.setInt(1, Accno);

			ResultSet resultSet = statement.executeQuery();
			if (resultSet.next())
				return true;// takes the record pointer to the first row and
							// then on next row
			else
				throw new WalletException("Please register for a new account ");
		} catch (ClassNotFoundException | WalletException we) {
			we.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {

			try {
				statement.close();
			} catch (SQLException e) {

				throw new WalletException("unable to close statement object");
			}

			try {
				connection.close();
			} catch (SQLException e) {

				throw new WalletException("unable to close connection object");
			}
		}
		return false;

	}

	@Override
	public void insertIntoTransaction(int Accno, String type, double amount,
			double balance) {
		Connection connection = null;
		PreparedStatement statement = null;
		try {
			connection = JdbcUtil.getConnection();
		} catch (ClassNotFoundException | WalletException we) {
			we.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			statement = connection.prepareStatement(QueryMapper.Transaction);

			statement.setInt(1, Accno);
			statement.setString(2, type);
			statement.setDouble(3, amount);
			statement.setDouble(4, balance);

			statement.executeUpdate();

		} catch (SQLException e) {
			System.err.println("Unable to fetch data" + e);

		} finally {

			try {
				try {
					statement.close();
				} catch (SQLException e) {

				}
			} catch (Exception e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}

			try {
				try {
					connection.close();
				} catch (SQLException e) {

				}
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

}
