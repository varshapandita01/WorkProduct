
public class Person {
	private String name;
	private int age;
	static{//static initaializer block--executes when class loads
		System.out.println("Person class Loaded.... ");
		
	}
	{
		//instance block-- executes when initiated
		System.out.println("Person class initiated");
	}
	public Person() {
		
	}
	public Person(String name, int age) {
		
		this.name = name;
		this.age = age;
	}
	public static void main(String[] args) {
		Person p1=new Person("Polo",21);
		Person p2=new Person("Lili",19);
		Person p3=new Person("Polo",21);
		
		System.out.println(p1.hashCode());
		System.out.println(p2.hashCode());
		System.out.println(p3.hashCode());
		System.out.println(p1);//implicitly calls toString()
		System.out.println(p2);
		System.out.println(p1.equals(p2));
		System.out.println(p1.equals(p3));
	}
	@Override
	public boolean equals(Object obj) {
		if(obj instanceof Person){
			Person p=(Person)obj;// DownCasting
			if(p.name.equals(this.name) && age==p.age){
				return true;
			}
		}
		return false;
	}
	@Override
	public String toString() {

		return "Name: "+name +"\tAge: " +age;
	}
	
}
