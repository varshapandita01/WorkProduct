import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;


public class PersonReflection {

	public static void main(String[] args) {
		Person p=new Person("Polo",21);
		System.out.println(p);
		System.out.println(p.getClass());
		Class pc= p.getClass();
		System.out.println(pc.getName());
		
		Constructor[] constructors=pc.getConstructors();
		System.out.println("---List of constructors-----");
		for (Constructor constructor : constructors) {
			System.out.println(constructor);
		}
		Method[] methods =pc.getMethods();
		System.out.println("-----List of Methods---");
		for (Method method : methods) {
			System.out.println(method);
		}
		
		Method[] dcMethods =pc.getDeclaredMethods();
		System.out.println("----List of Declared Methods---");
		for (Method method : dcMethods) {
			System.out.println(method);
		}
		Field[] Field= pc.getFields();
		System.out.println("----List of Fieelds");
		for (Field field2 : Field) {
			System.out.println(field2);
			
		}
		
		Field[] Field1= pc.getDeclaredFields();
		System.out.println("----List of Fieelds");
		for (Field field2 : Field1) {
			System.out.println(field2);
			
		}
		
	}

}
