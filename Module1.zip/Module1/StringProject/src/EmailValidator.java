public class EmailValidator {
	void validator() {
		String email = "varsha@gmail.com";
		int ioat = email.indexOf('@');
		System.out.println(ioat);
		int idot = email.indexOf('.');
		System.out.println(idot);
		if (ioat == email.lastIndexOf('@') && idot == email.lastIndexOf('.')
				&& ioat >= 4 && (idot - ioat) > 3
				&& (email.length() - idot) > 2) {
			System.out.println("Valid Email");
		} else
			System.out.println("Invalid Email");
	}

	public static void main(String[] args) {
		String email = "varsha@gmail.com";
		int email1 = email.indexOf("@");
		int email2 = email.indexOf('.');
		int diff = email2 - email1;
		int diff1 = email.length() - email2;
		if (email1 == email.lastIndexOf('@')
				&& email2 == email.lastIndexOf('.') && email1 >= 4 && diff > 3
				&& diff1 > 2) {

			System.out.println("Email is validated successfully");
		}

		else {
			System.out.println("Not validated");
		}

		EmailValidator EmailValidator = new EmailValidator();
		EmailValidator.validator();
	}

}
