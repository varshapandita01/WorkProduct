
public class StringBufferDemo {
	public static void main(String[] args) {
		StringBuffer s1=new StringBuffer("hello");
		StringBuffer s2=new StringBuffer("hello");
		System.out.println(s1.append("World"));
		System.out.println(s1);
		System.out.println(s1==s2);
		System.out.println(s1.equals(s2));
		
		System.out.println("String Builder");
		StringBuilder s3=new StringBuilder("hello");
		
		StringBuilder s4=new StringBuilder("hello");
		System.out.println(s3.append("World"));
		System.out.println(s3);
		System.out.println(s3==s4);
		System.out.println(s3.equals(s4));
	}
}
