import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;

public class ResultDemo {

	public static void main(String[] args) {
		String sql = "select * from person";
		Connection conn = null;
		try {
			conn = JdbcFactory.getConnection();

			Statement stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery(sql);
			ResultSetMetaData meta = rs.getMetaData();
			System.out.println(meta.getColumnName(1) + "\t"
					+ meta.getColumnName(2) + "\t" + meta.getColumnName(3));
			while (rs.next()) {
				System.out.println(rs.getString(1) + "\t" + rs.getInt("age")
						+ "\t" + rs.getString(3));
			}
		} catch (SQLException e) {
			System.out.println("Connection Failed due to...");// optional
		} finally {
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {

					e.printStackTrace();
				}
			}
		}

	}

}
