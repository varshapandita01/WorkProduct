import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class PersonDaoImpl implements PersonDao {

	@Override
	public void save(Person p) {
		String sql = "insert into person values(?,?,?)";
		Connection conn = null;
		try {
			conn = JdbcFactory.getConnection();
			PreparedStatement stmt = conn.prepareStatement(sql);
			// replacing placeholder with cmd line args values
			stmt.setString(1, p.getName());
			stmt.setInt(2, p.getAge());
			stmt.setString(3, p.getCity());

			stmt.executeUpdate();
			System.out.println("Record Inserted...");
		} catch (SQLException e) {
			System.out.println("Connection Failed due to...");// optional
		} finally {
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {

					e.printStackTrace();
				}
			}
		}

	}

	@Override
	public List<Person> fetch() {
		String sql = "select * from person";
		Connection conn = null;
		List<Person> persons = new ArrayList<Person>();
		try {
			conn = JdbcFactory.getConnection();

			Statement stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery(sql);
			ResultSetMetaData meta = rs.getMetaData();
			System.out.println(meta.getColumnName(1) + "\t"
					+ meta.getColumnName(2) + "\t" + meta.getColumnName(3));
			while (rs.next()) {// instantiating person object
				// Setting vlues from result-set Record
				Person p = new Person();
				p.setName(rs.getString(1));
				p.setAge(rs.getInt("age"));
				p.setCity(rs.getString(3));
				persons.add(p);// adding person object to list
			}
			return persons;
		} catch (SQLException e) {
			// System.out.println("Connection Failed due to...");// optional
			return null;
		} finally {
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {

					e.printStackTrace();
				}
			}
		}

	}

}
