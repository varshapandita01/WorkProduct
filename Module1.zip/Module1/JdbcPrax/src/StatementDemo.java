import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

import oracle.jdbc.driver.OracleDriver;

public class StatementDemo {

	public static void main(String[] args) {

		String url = "jdbc:oracle:thin:@10.51.103.201:1521:orcl11g";
		String sql = "insert into person values('Polo',21,'Pune')";
		Connection conn = null;

		try {

			// Requesting connection from Driver Manager
			conn = JdbcFactory.getConnection();
			System.out.println("Connected Successfully");
			Statement stmt = conn.createStatement();
			stmt.executeUpdate(sql);// performing DML operation
			System.out.println("Record Inserted");

		} catch (SQLException e) {
			System.out.println("Connection Failed due to...");// optional
		} finally {
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {

					e.printStackTrace();
				}
			}
		}

	}

}
