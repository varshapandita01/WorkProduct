import java.util.List;

public interface PersonDao {
	void save(Person p);

	List<Person> fetch();
}
