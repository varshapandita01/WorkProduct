interface Holder{
	void viewQuote();
}
interface Broker extends Holder{
	void getQuote();
}
interface Exchange extends Broker{
	void setQuote();
}
public class Stock implements Exchange {
	@Override
	public void getQuote() {
	System.out.println("getQuote");
		
	}

	@Override
	public void viewQuote() {
		System.out.println("viewQuote");
		
	}

	@Override
	public void setQuote() {
		System.out.println("setQuote");
		
	}
	public static void main(String[] args) {
		/*Stock capgemini =new Stock();*/
		Holder h=StockSingleton.getStock();
		Broker b=StockSingleton.getStock();
		Exchange e=StockSingleton.getStock();
		h.viewQuote();
		b.viewQuote();
		b.getQuote();
		e.viewQuote();
		e.getQuote();
		e.setQuote();

	}



}
