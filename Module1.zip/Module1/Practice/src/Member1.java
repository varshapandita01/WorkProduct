
public class Member1 {
	private String name;
	private Book book;

	public Member1(Book book) {
		super();
		this.book = book;
	}

	public Member1(String name) {
		super();
		this.name = name;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	public void status() {
		 if(book==null){
			 System.out.println(name+ " issued no book");
		 }
		 else{
			
			 System.out.println(name+" issued "+book.title);
		 }
	}

	public void book(String title) {
		// TODO Auto-generated method stub
		
	}
}
