
public class Library1 {
public static void main(String[] args) {
	Book1  book=new Book1("Capgemini");
	book.status();
	Member1 member=new Member1("Varsha");
	member.status();
	book.issueBook(member);
	book.status();
	member.status();
	System.out.println("------------------");
	book.returnBook(member);
	book.status();
	member.status();
}
}
