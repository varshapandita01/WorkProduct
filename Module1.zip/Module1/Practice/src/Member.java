public class Member {
	
	String name;
	private Book bk;
	public Member(){}
	public Member(String name){
		this.name=name;
	}
	public void Book(Book bk){
		this.bk=bk;
	}
	public void status() {
		 if(bk!=null){
			 System.out.println(name+" issued "+bk.title);
		 }
		 else{
			 System.out.println(name+ " issued no book");
		 }
	}
//	public void book(String title) {
//		// TODO Auto-generated method stub
//		
//	}
	public void book(String title) {
		// TODO Auto-generated method stub
		
	}
}
