public class Book1 {
private String title;
private Member1 member;
public String getTitle() {
	return title;
}
public Book1(Member1 member) {
	
	this.member = member;
}
public Book1(String title) {
	
	this.title = title;
}
public void status(){
	if(member==null){
		System.out.println(title+" is not issued by anyone");
		
	}
	else{
		System.out.println(title+" is inserted by "+member.getName());
	}
	
}

public  void issueBook(Member1 member) {
	// TODO Auto-generated method stub
	this.member=member;
	member.book(title);
}

public void returnBook(Member1 member) {
	// TODO Auto-generated method stub
	this.member=null;
	member.book(null);
}
}
