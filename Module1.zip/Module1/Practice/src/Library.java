
public class Library {

	public static void main(String[] args) {
		Book  book=new Book("Capgemini");
		book.status();
		Member member=new Member("Varsha");
		member.status();
		book.issueBook(member);
		book.status();
		member.status();
		System.out.println("------------------");
		book.returnBook(member);
		book.status();
		member.status();
	}

}
