
public class Book {
	String title;
	private Member mem=null;

	public Book(){}
	public Book(String title){
		this.title=title;
	}
	public void member(Member mem){
		this.mem=mem;
		
	}
	public void status(){
		if(mem!=null){
			System.out.println(title+" is inserted by "+mem.name);
		}
		else{
			System.out.println(title+" is not issued by anyone");
		}
		
	}
	public  void issueBook(Member mem) {
		// TODO Auto-generated method stub
		this.mem=mem;
		mem.book(title);
	}

	public void returnBook(Member mem) {
		// TODO Auto-generated method stub
		this.mem=null;
		mem.book(null);
	}

	
}
