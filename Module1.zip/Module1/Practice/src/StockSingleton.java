
public class StockSingleton {

	private StockSingleton() {
		
	}
	private static Stock capgemini;
	public static Stock getStock() {
		if(capgemini==null)
			capgemini=new Stock();
		return capgemini;
		
		
	}

}
 
  