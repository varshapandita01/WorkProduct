import java.time.LocalDate;
import java.util.ArrayList;

class Phone {
	/*String keyword = "in-built";
	static String a = "hi";

	void call() {
		String a = "hio";
		if (8 > 2) {
			// String a="hyy";
			System.out.println(a);
		}
		System.out.println("Call-Phone");
	}*/

	void Phone() {
	}

	void Phone(SmartPhone a) {
	}
}

public class SmartPhone extends Phone {
	/*boolean choose = false;

	void call() throws ClassCastException {
		System.out.println("SmartCall-Phone");
	}*/

	public static void main(String[] args) {
		Phone phone = new Phone();
		Phone smartphone = new Phone();
		// phone.call();
		// System.out.println(smartphone.keyword +":"+ smartphone.choose());
		/*
		 * int a=10;int b=20;boolean c=false; if(b>a) if(++a==10) if(c!=true)
		 * System.out.println(1); else System.out.println(2); else
		 * System.out.println(3);
		 */

		/*
		 * ArrayList<Object> list=new ArrayList<Object>(); list.add(new
		 * String("1234")); list.add(new Phone()); list.add(new SmartPhone());
		 * list.add(new String[]{"abcd","xyz"});
		 * list.add(LocalDate.now().plus(1));
		 */
		/*
		 * phone.a=100; smartphone.a=200;
		 * System.out.println(phone.a+"   "+smartphone.a);
		 */

		/*
		 * try { ((SmartPhone)phone).call(); }
		 * 
		 * catch (Throwable e) { // TODO Auto-generated catch block
		 * e.printStackTrace();} catch (Exception e) { // TODO Auto-generated
		 * catch block e.printStackTrace(); }} catch (ClassCastException e) { //
		 * TODO Auto-generated catch block e.printStackTrace(); }
		 * 
		 * catch (NullPointerException e) { // TODO Auto-generated catch block
		 * e.printStackTrace(); }
		 * 
		 * }
		 */
	}
}
