package com.cg.step;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import com.cg.bean.Education;

import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class EducationalStepDefinition {

	private WebDriver driver;
	private Education education;

	@Before
	public void init() throws InterruptedException {
		// Instatntiate driver
		System.setProperty("webdriver.chrome.driver", "mydriver\\chromedriver.exe");
		
	}

	@Given("^User is on 'EducationalDetails' Page$")
	public void user_is_on_EducationalDetails_Page() throws Throwable {
		driver = new ChromeDriver();

		String url = "file:///C:/Users/varpandi/workspaceBDD/ConferencePractice/html/EducationalDetails.html";
		driver.get(url);
		education = new Education();
		PageFactory.initElements(driver, education);

	}
	@Then("^Page Title matched successfully$")
	public void page_Title_matched_Successfully() throws Throwable {
		String title= driver.getTitle();
		if(title.equals("Educational Details")) {
			System.out.println("correcte Title");
		}
		else {
			System.out.println("incorect title");
		}
	}
	
	@When("^user not select graduation$")
	public void user_not_select_graduation() throws Throwable {
		education.selectGraduation(0);
	}

	@Then("^display 'Please select Graduation'$")
	public void display_Please_select_Graduation() throws Throwable {

		education.clickLogin();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
		driver.close();
	}

	@When("^user enters invalid percentage$")
	public void user_enters_invalid_percentage() throws Throwable {
		education.selectGraduation(1);
		education.setPercentage("");
	}

	@Then("^display 'Please fill the percentage'$")
	public void display_Please_fill_the_percentage() throws Throwable {

		education.clickLogin();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
		driver.close();
	}

	@When("^user enters invalid passing year$")
	public void user_enters_invalid_passing_year() throws Throwable {
		education.selectGraduation(1);
		education.setPercentage("88");
		education.setPassingYear("");
	}

	@Then("^display 'Please fill the valid passing year'$")
	public void display_Please_fill_the_valid_passing_year() throws Throwable {

		education.clickLogin();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
		driver.close();
	}

	@When("^user enters invalid project Name$")
	public void user_enters_invalid_project_Name() throws Throwable {
		education.selectGraduation(1);
		education.setPercentage("88");
		education.setPassingYear("2011");
		education.setProjectName("");
	}

	@Then("^display 'Please fill the  project name'$")
	public void display_Please_fill_the_project_name() throws Throwable {

		education.clickLogin();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
		driver.close();
	}

	@When("^user not select technolgoes$")
	public void user_not_select_technolgoes() throws Throwable {
		education.selectGraduation(1);
		education.setPercentage("88");
		education.setPassingYear("2011");
		education.setProjectName("GPS");
		education.selectTechnologies(0);
	}

	@Then("^display 'Please Select Technologies'$")
	public void display_Please_Select_Technologies() throws Throwable {
		education.clickLogin();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
		driver.close();

	}

	@When("^user not checks other$")
	public void user_not_checks_other() throws Throwable {
		education.selectGraduation(1);
		education.setPercentage("88");
		education.setPassingYear("2011");
		education.setProjectName("GPS");
		education.selectTechnologies(3);

	}

	@Then("^display 'Please check for others'$")
	public void display_Please_check_for_others() throws Throwable {
		education.clickLogin();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
		driver.close();

	}

	@When("^User click on Add$")
	public void user_click_on_Add() throws Throwable {
		education.selectGraduation(1);
		education.setPercentage("88");
		education.setPassingYear("2011");
		education.setProjectName("GPS");
		education.selectTechnologies(2);
		education.selectOther();
	}

	@Then("^Educational Details are validated and accepted successfully$")
	public void educational_Details_are_validated_and_accepted_successfully() throws Throwable {

		education.clickLogin();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
		driver.close();
	}


}
