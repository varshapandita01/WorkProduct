package com.cg.bean;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

public class Personal {
	@FindBy(id = "fname")
	private WebElement fname;

	@FindBy(id = "lname")
	private WebElement lname;

	@FindBy(id = "email")
	private WebElement email;

	@FindBy(id = "cnumber")
	private WebElement cnumber;

	@FindBy(id = "address1")
	private WebElement address1;

	@FindBy(id = "address2")
	private WebElement address2;

	@FindBy(id = "state")
	private WebElement state;

	@FindBy(id = "city")
	private WebElement city;

	@FindBy(id = "login")
	private WebElement login;

	public String getFirstname() {
		return fname.getAttribute("value");
	}

	public void setFirstname(String fname) {
		this.fname.sendKeys(fname);
	}

	public String getLastName() {
		return lname.getAttribute("value");
	}

	public void setLastName(String lname) {
		this.lname.sendKeys(lname);

	}

	public String getEmail() {
		return email.getAttribute("value");
	}

	public void setEmail(String email) {
		this.email.sendKeys(email);
	}

	public String getContact() {
		return cnumber.getAttribute("value");
	}

	public void setContact(String cnumber) {
		this.cnumber.sendKeys(cnumber);

	}

	public String getAddress1() {
		return address1.getAttribute("value");
	}

	public void setAddress1(String address1) {
		this.address1.sendKeys(address1);

	}

	public String getAddress2() {
		return address2.getAttribute("value");
	}

	public void setAddress2(String address2) {
		this.address2.sendKeys(address2);

	}

	public void selectCity(int idx) {
		Select select = new Select(city);
		select.selectByIndex(idx);
	}

	public void selectState(int idx) {
		Select select = new Select(state);
		select.selectByIndex(idx);
	}

	public void clickLogin() {
		login.click();
	}
}
