package com.cg.project.stepdefinations;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.PageFactory;

import com.cg.project.beans.ConferenceRegistration;

import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class ConferenceRegistrationStepDefination {

	private WebDriver driver;
	private ConferenceRegistration conference;
	
	@Before
	public void setUpStepEnv() {
		System.setProperty("webdriver.gecko.driver","C:\\Users\\varpandi\\workspaceBDD\\PaymentProject\\lib\\geckodriver.exe" );
	}
	
	@Given("^User is on 'ConferenceRegistration' Page$")
	public void user_is_on_ConferenceRegistration_Page() throws Throwable {
		driver = new FirefoxDriver();
		driver.get("file:///C:\\Users\\varpandi\\workspaceBDD\\PaymentProject\\htmlFiles\\ConferenceRegistartion.html");
		conference = new ConferenceRegistration();
		PageFactory.initElements(driver, conference);
	}

	@When("^user enters valid details$")
	public void user_enters_valid_details() throws Throwable {
	    conference.setFirstName("Nishitha");
	    conference.setLastName("Juvvadi");
	    conference.setEmail("nishitharaojuvvadi@gmail.com");
	    conference.setPhoneNumber("9490406126");
	    conference.clickPeople();
	    conference.setAddress("Plot no:14");
	    conference.setArea("Hinjewadi");
	    conference.clickCity();
	    conference.clickState();
	    conference.clickMemberStatus();
	    conference.clickNextButton();
	}

	@Then("^display 'Personal details are validated'$")
	public void display_Personal_details_are_validated() throws Throwable {
		String expectedMessage="Personal details are validated.";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
	}
	@When("^user enetrs url$")
	public void user_enetrs_url() throws Throwable {
	    
	}

	@Then("^page should be loaded$")
	public void page_should_be_loaded() throws Throwable {
		String expectedPageTitle="Conference Registartion";
		String actualPageTitle=driver.getTitle();
		Assert.assertEquals(expectedPageTitle, actualPageTitle);
		driver.close();
	}


	@When("^user enetrs invalid firstName$")
	public void user_enetrs_invalid_firstName() throws Throwable {
		conference.setFirstName("");
		conference.clickNextButton();
	}

	@Then("^display 'Please fill the First Name'$")
	public void display_Please_fill_the_First_Name() throws Throwable {
		String expectedMessage="Please fill the First Name";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^user enetrs invalid lastName$")
	public void user_enetrs_invalid_lastName() throws Throwable {
		conference.setFirstName("Nishitha");
		conference.setLastName("");
		conference.clickNextButton();
	}

	@Then("^display 'Please fill the Last Name'$")
	public void display_Please_fill_the_Last_Name() throws Throwable {
		String expectedMessage="Please fill the Last Name";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^user enetrs invalid email$")
	public void user_enetrs_invalid_email() throws Throwable {
		conference.setFirstName("Nishitha");
		conference.setLastName("Juvvadi");
		conference.setEmail("sjssj@ghsj");
		conference.clickNextButton();
	}

	@Then("^display 'Please fill the Email'$")
	public void display_Please_fill_the_Email() throws Throwable {
		String expectedMessage="Please enter valid Email Id.";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
	}
	@When("^user does not enter  email$")
	public void user_does_not_enter_email() throws Throwable {
		conference.setFirstName("Nishitha");
		conference.setLastName("Juvvadi");
		conference.clickNextButton();
	}

	@Then("^display 'Please fill the Email id '$")
	public void display_Please_fill_the_Email_id() throws Throwable {
		String expectedMessage="Please fill the Email";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().dismiss();
		driver.close();
	}

	@When("^user does not enter contact number$")
	public void user_does_not_enter_contact_number() throws Throwable {
		conference.setFirstName("Nishitha");
		conference.setLastName("Juvvadi");
		conference.setEmail("nishitha@gmail.com");
		conference.clickNextButton();
	}

	@Then("^display 'Please fill valid Contact number\\.'$")
	public void display_Please_fill_valid_Contact_number() throws Throwable {
		String expectedMessage="Please fill the Contact No.";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().dismiss();
		driver.close();
	}

	@When("^user enetrs invalid contact number$")
	public void user_enetrs_invalid_contact_number() throws Throwable {
		conference.setFirstName("Nishitha");
		conference.setLastName("Juvvadi");
		conference.setEmail("nishitha@gmail.com");
		conference.setPhoneNumber("123311");
		conference.clickNextButton();
	}

	@Then("^display 'Please fill valid Contact no\\.'$")
	public void display_Please_fill_valid_Contact_no() throws Throwable {
		String expectedMessage="Please enter valid Contact no.";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().dismiss();
		driver.close();
	}

	@When("^user enetrs invalid Number of People attending$")
	public void user_enetrs_invalid_Number_of_People_attending() throws Throwable {
		conference.setFirstName("Nishitha");
		conference.setLastName("Juvvadi");
		conference.setEmail("nishitha@gmail.com");
		conference.setPhoneNumber("9490406126");
		conference.clickNextButton();
	}

	@Then("^display 'Number of people attending'$")
	public void display_Number_of_people_attending() throws Throwable {
		String expectedMessage="Please fill the Number of people attending";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^user enetrs invalid Building name and room no$")
	public void user_enetrs_invalid_Building_name_and_room_no() throws Throwable {
		
		conference.setFirstName("Nishitha");
		conference.setLastName("Juvvadi");
		conference.setEmail("nishitha@gmail.com");
		conference.setPhoneNumber("9490406126");
		conference.clickPeople();
		conference.setAddress("");
		conference.clickNextButton();
	}

	@Then("^display 'Please fill Building name and room no'$")
	public void display_Please_fill_Building_name_and_room_no() throws Throwable {
		String expectedMessage="Please fill the Building & Room No";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^user enetrs invalid Area name$")
	public void user_enetrs_invalid_Area_name() throws Throwable {
		conference.setFirstName("Nishitha");
		conference.setLastName("Juvvadi");
		conference.setEmail("nishitha@gmail.com");
		conference.setPhoneNumber("9490406126");
		conference.clickPeople();
		conference.setAddress("Plot no:14");
		conference.setArea("");
		conference.clickNextButton();
	}

	@Then("^display 'Please fill Area name'$")
	public void display_Please_fill_Area_name() throws Throwable {
		String expectedMessage="Please fill the Area name";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^user enetrs invalid City$")
	public void user_enetrs_invalid_City() throws Throwable {
		conference.setFirstName("Nishitha");
		conference.setLastName("Juvvadi");
		conference.setEmail("nishitha@gmail.com");
		conference.setPhoneNumber("9490406126");
		conference.clickPeople();
		conference.setAddress("Plot no:14");
		conference.setArea("Hinjewadi");
		conference.clickNextButton();
	}

	@Then("^display 'Please fill City'$")
	public void display_Please_fill_City() throws Throwable {
		String expectedMessage="Please select city";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();  
	}

	@When("^user enetrs invalid State$")
	public void user_enetrs_invalid_State() throws Throwable {
		conference.setFirstName("Nishitha");
		conference.setLastName("Juvvadi");
		conference.setEmail("nishitha@gmail.com");
		conference.setPhoneNumber("9490406126");
		conference.clickPeople();
		conference.setAddress("Plot no:14");
		conference.setArea("Hinjewadi");
		conference.clickCity();
		conference.clickNextButton();
	}

	@Then("^display 'Please fill the State'$")
	public void display_Please_fill_the_State() throws Throwable {
		String expectedMessage="Please select state";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();  
	}

	@When("^user enetrs invalid Member Status$")
	public void user_enetrs_invalid_Member_Status() throws Throwable {
		conference.setFirstName("Nishitha");
		conference.setLastName("Juvvadi");
		conference.setEmail("nishitha@gmail.com");
		conference.setPhoneNumber("9490406126");
		conference.clickPeople();
		conference.setAddress("Plot no:14");
		conference.setArea("Hinjewadi");
		conference.clickCity();
		conference.clickState();
		conference.clickNextButton();
	}

	@Then("^display 'Please fill the Member Status'$")
	public void display_Please_fill_the_Member_Status() throws Throwable {
		String expectedMessage="Please Select MemeberShip status";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();  
	}
}