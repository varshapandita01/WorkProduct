package com.cg.step;

import static org.testng.Assert.assertEquals;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import com.cg.bean.Education;
import com.cg.bean.Personal;

import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class PersonalStepDefinition {

	private WebDriver driver;
	private Personal personal;

	@Before
	public void init() throws InterruptedException {
		// Instatntiate driver
		System.setProperty("webdriver.chrome.driver", "mydriver\\chromedriver.exe");
		driver = new ChromeDriver();

	}

	@Given("^User is on 'PersonalDetails' Page$")
	public void user_is_on_PersonalDetails_Page() throws Throwable {
		String url = "file:///C:\\Users\\varpandi\\workspaceBDD\\ConferencePractice\\html\\PersonalDetails.html";
		driver.get(url);
		personal = new Personal();
		PageFactory.initElements(driver, personal);
	}

	@Then("^Page Title Matched successfully$")
	public void page_Title_matched_Successfully() throws Throwable {
		String title= driver.getTitle();
		if(title.equals("Personal Details")) {
			System.out.println("correcte Title");
		}
		else {
			System.out.println("incorect title");
		}	}

	@When("^user enters invalid firstName$")
	public void user_enters_invalid_firstName() throws Throwable {
		personal.setFirstname("");
	}

	@Then("^display 'Please fill the valid First Name'$")
	public void display_Please_fill_the_valid_First_Name() throws Throwable {
		personal.clickLogin();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
	}

	@When("^user enters invalid lastName$")
	public void user_enters_invalid_lastName() throws Throwable {
		personal.setFirstname("Varsha");
		personal.setLastName("");
	}

	@Then("^display 'Please fill the valid Last Name'$")
	public void display_Please_fill_the_valid_Last_Name() throws Throwable {
		personal.clickLogin();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
	}

	@When("^user enters invalid email$")
	public void user_enters_invalid_email() throws Throwable {
		personal.setFirstname("Varsha");
		personal.setLastName("Pandita");
		personal.setEmail("varsha");
	}

	@Then("^display 'Please fill the valid Email'$")
	public void display_Please_fill_the_valid_Email() throws Throwable {
		personal.clickLogin();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
	}

	@When("^user enters invalid contact$")
	public void user_enters_invalid_contact() throws Throwable {
		personal.setFirstname("Varsha");
		personal.setLastName("Pandita");
		personal.setEmail("varsha@gmail.com");
		personal.setContact("12");
	}

	@Then("^display 'Please fill the  Contact'$")
	public void display_Please_fill_the_Contact() throws Throwable {
		personal.clickLogin();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
	}

	@When("^user enters invalid address$")
	public void user_enters_invalid_address() throws Throwable {
		personal.setFirstname("Varsha");
		personal.setLastName("Pandita");
		personal.setEmail("varsha@gmail.com");
		personal.setContact("7758038348");
		personal.setAddress1("a");

	}

	@Then("^display 'Please fill the valid Address'$")
	public void display_Please_fill_the_valid_Address() throws Throwable {
		personal.clickLogin();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
	}

	@When("^user enters invalid addressLine$")
	public void user_enters_invalid_addressLine() throws Throwable {
		personal.setFirstname("Varsha");
		personal.setLastName("Pandita");
		personal.setEmail("varsha@gmail.com");
		personal.setContact("7758038348");
		personal.setAddress1("Airoli");
		personal.setAddress2("d");
	}

	@Then("^display 'Please fill the valid AddressLine'$")
	public void display_Please_fill_the_valid_AddressLine() throws Throwable {
		personal.clickLogin();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
	}

	/*
	 * @Then("^display 'Please fill the valid Contact'$") public void
	 * display_Please_fill_the_valid_Contact() throws Throwable {
	 * personal.clickLogin(); Thread.sleep(2000);
	 * driver.switchTo().alert().accept(); Thread.sleep(2000); }
	 */

	@When("^user enters invalid city$")
	public void user_enters_invalid_city() throws Throwable {
		personal.setFirstname("Varsha");
		personal.setLastName("Pandita");
		personal.setEmail("varsha@gmail.com");
		personal.setContact("7758038348");
		personal.setAddress1("Airoli");
		personal.setAddress2("Mumbai");
		personal.selectCity(0);
	}

	@Then("^display 'Please select City'$")
	public void display_Please_select_City() throws Throwable {
		personal.clickLogin();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
	}

	@When("^user enters invalid state index$")
	public void user_enters_invalid_state_index() throws Throwable {
		personal.setFirstname("Varsha");
		personal.setLastName("Pandita");
		personal.setEmail("varsha@gmail.com");
		personal.setContact("7758038348");
		personal.setAddress1("Airoli");
		personal.setAddress2("Mumbai");
		personal.selectCity(2);
		personal.selectState(0);
	}

	@Then("^display 'Please select state'$")
	public void display_Please_select_state() throws Throwable {
		personal.clickLogin();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
	}

	@When("^User click on Next$")
	public void user_click_on_Next() throws Throwable {
		personal.setFirstname("Varsha");
		personal.setLastName("Pandita");
		personal.setEmail("varsha@gmail.com");
		personal.setContact("7758038348");
		personal.setAddress1("Airoli");
		personal.setAddress2("Mumbai");
		personal.selectCity(2);
		personal.selectState(1);
	}

	@Then("^Personal Details are validated and accepted successfully$")
	public void personal_Details_are_validated_and_accepted_successfully() throws Throwable {
		personal.clickLogin();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
	}

	
	private Education education;

	

	@Given("^User is on 'EducationalDetails' Page$")
	public void user_is_on_EducationalDetails_Page() throws Throwable {
		String url = "file:///C:/Users/varpandi/workspaceBDD/ConferencePractice/html/EducationalDetails.html";
		driver.get(url);
		education = new Education();
		PageFactory.initElements(driver, education);

	}
	@Then("^Page Education Title matched successfully$")
	public void page_Title_matched_Successfullyy() throws Throwable {
		String title= driver.getTitle();
		if(title.equals("Educational Details")) {
			System.out.println("correcte Title");
		}
		else {
			System.out.println("incorect title");
		}
	}
	
	@When("^user not select graduation$")
	public void user_not_select_graduation() throws Throwable {
		education.selectGraduation(0);
	}

	@Then("^display 'Please select Graduation'$")
	public void display_Please_select_Graduation() throws Throwable {

		education.clickLogin();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
	}

	@When("^user enters invalid percentage$")
	public void user_enters_invalid_percentage() throws Throwable {
		education.selectGraduation(1);
		education.setPercentage("");
	}

	@Then("^display 'Please fill the percentage'$")
	public void display_Please_fill_the_percentage() throws Throwable {

		education.clickLogin();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
	}

	@When("^user enters invalid passing year$")
	public void user_enters_invalid_passing_year() throws Throwable {
		education.selectGraduation(1);
		education.setPercentage("88");
		education.setPassingYear("");
	}

	@Then("^display 'Please fill the valid passing year'$")
	public void display_Please_fill_the_valid_passing_year() throws Throwable {

		education.clickLogin();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
	}

	@When("^user enters invalid project Name$")
	public void user_enters_invalid_project_Name() throws Throwable {
		education.selectGraduation(1);
		education.setPercentage("88");
		education.setPassingYear("2011");
		education.setProjectName("");
	}

	@Then("^display 'Please fill the  project name'$")
	public void display_Please_fill_the_project_name() throws Throwable {

		education.clickLogin();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
	}

	@When("^user not select technolgoes$")
	public void user_not_select_technolgoes() throws Throwable {
		education.selectGraduation(1);
		education.setPercentage("88");
		education.setPassingYear("2011");
		education.setProjectName("GPS");
		education.selectTechnologies(0);
	}

	@Then("^display 'Please Select Technologies'$")
	public void display_Please_Select_Technologies() throws Throwable {
		education.clickLogin();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);

	}

	@When("^user not checks other$")
	public void user_not_checks_other() throws Throwable {
		education.selectGraduation(1);
		education.setPercentage("88");
		education.setPassingYear("2011");
		education.setProjectName("GPS");
		education.selectTechnologies(3);

	}

	@Then("^display 'Please check for others'$")
	public void display_Please_check_for_others() throws Throwable {
		education.clickLogin();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
		

	}

	@When("^User click on Add$")
	public void user_click_on_Add() throws Throwable {
		education.selectGraduation(1);
		education.setPercentage("88");
		education.setPassingYear("2011");
		education.setProjectName("GPS");
		education.selectTechnologies(2);
		education.selectOther();
	}

	@Then("^Educational Details are validated and accepted successfully$")
	public void educational_Details_are_validated_and_accepted_successfully() throws Throwable {

		education.clickLogin();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
		
	}
	@After
	public void destroy() {
		driver.quit();
	}

}
