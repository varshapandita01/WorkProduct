package com.cg.bean;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

public class Coaching {

	@FindBy(id = "fname")
	private WebElement fname;

	@FindBy(id = "lname")
	private WebElement lname;

	@FindBy(id = "emails")
	private WebElement email;

	@FindBy(id = "mobile")
	private WebElement mobile;

	@FindBy(name = "D6")
	private WebElement tuition;

	@FindBy(name = "D5")
	private WebElement city;

	@FindBy(name = "D4")
	private WebElement training;

	@FindBy(id = "enqdetails")
	private WebElement enquiry;

	@FindBy(id = "Submit1")
	private WebElement submit;

	public String getFirstname() {

		return fname.getAttribute("value");
	}

	public void setFirstname(String fname) {

		this.fname.sendKeys(fname);
	}

	public String getLastName() {
		return lname.getAttribute("value");
	}

	public void setLastName(String lname) {
		this.lname.sendKeys(lname);

	}

	public String getEmail() {
		return email.getAttribute("value");
	}

	public void setEmail(String email) {
		this.email.sendKeys(email);
	}

	public String getMobile() {
		return mobile.getAttribute("value");
	}

	public void setMobile(String number) {
		this.mobile.sendKeys(number);

	}

	public void selectTuition(int idx) {
		Select select = new Select(tuition);
		select.selectByIndex(idx);
	}

	public void selectCity(int idx) {
		Select select = new Select(city);
		select.selectByIndex(idx);
	}

	public void selecttraining(int idx) {
		Select select = new Select(training);
		select.selectByIndex(idx);
	}

	public String getEnquiry() {
		return enquiry.getAttribute("value");
	}

	public void setEnquiry(String enquiry) {
		this.enquiry.sendKeys(enquiry);

	}

	public void clickSubmit() {
		submit.click();
	}
}
