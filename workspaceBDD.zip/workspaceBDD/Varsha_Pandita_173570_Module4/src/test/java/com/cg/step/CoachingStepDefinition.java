package com.cg.step;

import java.util.concurrent.TimeUnit;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import com.cg.bean.Coaching;

import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class CoachingStepDefinition {
	private WebDriver driver;
	private Coaching coaching;

	// Instantiate the driver
	@Before
	public void init() throws InterruptedException {
		// Instatntiate driver
		System.setProperty("webdriver.chrome.driver", "mydriver\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
	}

	// Coaching class Html Page opens
	@Given("^User is on CoachingEnquiry Page$")
	public void user_is_on_CoachingEnquiry_Page() throws Throwable {

		String url = "file:///C:\\Users\\varpandi\\workspaceBDD\\Varsha_Pandita_173570_Module4\\html\\Coaching_Class_Enquiry.html";
		driver.get(url);
		coaching = new Coaching();
		PageFactory.initElements(driver, coaching);
	}

	// Title matches Successfully or not
	@Then("^Page Title Successfully Matched$")
	public void page_Title_Matched_successfully() throws Throwable {
		String title = driver.getTitle();
		if (title.equals("Online Coaching Class Enquiry Form")) {
			System.out.println("correcte Title");
		} else {
			System.out.println("incorect title");
		}

	}

	// Text Matched Successfully or not
	@Then("^Page Text Matched successfully$")
	public void page_Text_Matched_successfully() throws Throwable {
		String actualMessage = driver.findElement(By.tagName("body")).getText();
		System.out.println(actualMessage);
		String expectedMessage = "Tuition Enquiry Details Form";
		Assert.assertTrue("Tuition Enquiry Details Form", actualMessage.contains(expectedMessage));

	}

	// First Name Validation
	@When("^user kept blank firstName$")
	public void user_kept_blank_firstName() throws Throwable {
		coaching.setFirstname("");
	}

	@Then("^display 'First Name must be filled out'$")
	public void display_First_Name_must_be_filled_out() throws Throwable {
		coaching.clickSubmit();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);

	}

	// Last Name Validation
	@When("^user enters invalid lastName$")
	public void user_enters_invalid_lastName() throws Throwable {
		coaching.setFirstname("Varsha");
		coaching.setLastName("");
	}

	@Then("^display 'Last Name must be filled out''$")
	public void display_Last_Name_must_be_filled_out() throws Throwable {
		coaching.clickSubmit();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);

	}

	// Email Validation
	@When("^user enters invalid email$")
	public void user_enters_invalid_email() throws Throwable {
		coaching.setFirstname("Varsha");
		coaching.setLastName("Pandita");
		coaching.setEmail("");
	}

	@Then("^display 'Email must be filled out'$")
	public void display_Email_fill() throws Throwable {
		coaching.clickSubmit();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);

	}

	// Mobile Validation for improper format
	@When("^user enters invalid mobile format$")
	public void user_enters_invalid_mobile_format() throws Throwable {
		coaching.setFirstname("Varsha");
		coaching.setLastName("Pandita");
		coaching.setEmail("varsha@gmail.com");
		coaching.setMobile("abc");
	}

	@Then("^display 'Enter numeric value'$")
	public void display_Enter_numeric_value() throws Throwable {
		coaching.clickSubmit();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);

	}

	// Mobile Validation for improper length

	@When("^user enters invalid mobile length$")
	public void user_enters_invalid_mobile_length() throws Throwable {
		coaching.setFirstname("Varsha");
		coaching.setLastName("Pandita");
		coaching.setEmail("varsha@gmail.com");
		coaching.setMobile("980755");
	}

	@Then("^display 'Enter (\\d+) digit mobile number'$")
	public void display_Enter_digit_mobile_number(int arg1) throws Throwable {
		coaching.clickSubmit();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);

	}

	// Enquity Validation for blank
	@When("^user kept enquirybox as empty$")
	public void user_kept_enquirybox() throws Throwable {
		coaching.setFirstname("Varsha");
		coaching.setLastName("Pandita");
		coaching.setEmail("varsha@gmail.com");
		coaching.setMobile("9758038348");
		coaching.selectTuition(1);
		coaching.selectCity(1);
		coaching.selecttraining(2);
		coaching.setEnquiry("");
	}

	@Then("^display 'EnquiryBox details must be filled out'$")
	public void display_enquiryDetails() throws Throwable {
		coaching.clickSubmit();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);

	}

	// Validation Successfully Done
	@When("^user enters whole enquiry form and submits$")
	public void user_enters_whole_enquiry_form_and_submits() throws Throwable {
		coaching.setFirstname("Varsha");
		coaching.setLastName("Pandita");
		coaching.setEmail("varsha@gmail.com");
		coaching.setMobile("9758038348");
		coaching.selectTuition(1);
		coaching.selectCity(1);
		coaching.selecttraining(2);
		coaching.setEnquiry("Good");
	}

	@Then("^display 'Thank You submiting the online Coaching Class Enquiry'$")
	public void display_Thank_You_submiting_the_online_Coaching_Class_Enquiry() throws Throwable {
		coaching.clickSubmit();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);

	}

	// Text validation
	@Then("^Page Text Matched successfully after submission$")
	public void page_Text_Matched_successfully_after_submission() throws Throwable {
		/*
		 * String expectedMessage = "Our Counselor will contact you soon."; String
		 * actualMessage = driver.findElement(By.tagName("script")).getText();
		 * Assert.assertTrue("Our Counselor will contact you soon.",
		 * actualMessage.contains(expectedMessage));
		 */

	}

	@After
	public void destroy() {
		driver.quit();
	}

}
