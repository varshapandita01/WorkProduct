package com.cg.step;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class LoginStepDefinitions {
	/*private WebDriver driver;

	@Before
	public void init() throws InterruptedException {
		// Instatntiate driver
		System.setProperty("webdriver.chrome.driver", "mydriver\\chromedriver.exe");
		driver = new ChromeDriver();
		
	}

	@Given("^User is on login page$")
	public void user_is_on_login_page() throws Throwable {
		String url = "file:///C:\\Users\\varpandi\\workspaceBDD\\HelloBDD\\html\\login.html";
		driver.get(url);
		
	}

	@When("^User enters username details$")
	public void user_enters_username_details() throws Throwable {
		WebElement uname = driver.findElement(By.id("username"));
		uname.sendKeys("Varsha");
		Thread.sleep(2000);
	}

	@Then("^Validate username$")
	public void validate_username() throws Throwable {
		WebElement form = driver.findElement(By.id("login"));
		form.click();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
	}

	@When("^User enters password details$")
	public void user_enters_password_details() throws Throwable {
		WebElement pwd = driver.findElement(By.id("password"));
		pwd.sendKeys("ora");
		Thread.sleep(2000);
	}

	@Then("^Validate password$")
	public void validate_password() throws Throwable {
		WebElement form = driver.findElement(By.id("login"));
		form.click();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
	}

	@When("^User click on submit form$")
	public void user_click_on_submit_form() throws Throwable {

	}

	@Then("^Show successfully submitted$")
	public void show_successully_submitted() throws Throwable {
		WebElement form = driver.findElement(By.id("login"));
		form.click();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
	}

	@After
	public void destroy() {
		driver.quit();
	}
*/
}
