package com.cg.bean;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

public class Login {
	@FindBy(id = "user")
	private List<WebElement> user;

	@FindBy(id = "username")
	private WebElement username;

	@FindBy(id = "password")
	private WebElement password;

	// @FindBy(xpath="/html/body/form/table/tbody/tr[3]/td[2]/select")
	@FindBy(id = "role")
	private WebElement role;

	@FindBy(id = "remember")
	private WebElement remember;
	
	@FindBy(id = "login")
	private WebElement login;

	public void selectUser(int idx) {
		this.user.get(idx).click();
	}
	
	public String getUsername() {
		return username.getAttribute("value");
	}

	public void setUsername(String username) {
		this.username.sendKeys(username);
	}

	public String getPassword() {
		return password.getAttribute("value");
	}

	public void setPassword(String password) {
		this.password.sendKeys(password);
		
	}

	public void clickRole(int idx) {
		Select select = new Select(role);
		select.selectByIndex(idx);
	}
	
	public void selectRemember() {
		this.remember.click();
	}

	public void clickLogin() {
		login.click();
	}

}
