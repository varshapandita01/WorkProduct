package cg.web;

import java.io.IOException;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import cg.bean.LoginBean;
import cg.service.ILoginService;
import cg.service.LoginService;

public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private ILoginService service;
		
	
	@Override
	public void init() throws ServletException {
		service= new LoginService();
	}

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		//creating session reference - If session id found in request header 
		//Existing session object reference is returned otherwise
		//A fresh new session object created in server and returned.
		HttpSession session= request.getSession();
		
		//Getting referer header to identify source of request
		String referer=request.getHeader("referer");
		
		if(referer.contains("login.jsp")){ //handling login request
		
		// Reading request/form parameters
		LoginBean login=new LoginBean();
		login.setUsername(request.getParameter("username"));
		login.setPassword(request.getParameter("password"));

		//Getting servlet's config reference
		ServletConfig config=getServletConfig();
		//Reading servlet's init-parameters
		String initUser=config.getInitParameter("USER");
		String initPass=config.getInitParameter("PASS");
		
		// Logic for login authentication
		if (service.authenticate(login)) {
			// login successful - send to success page
			//Adding username in session  map for future reference
			session.setAttribute("User", login.getUsername());
			response.sendRedirect("success.jsp");
		} else {
			// login failed - send back to login page
			response.sendRedirect("login.jsp?invalid=true");
		}
		}
		else{//handling logout request
			//destroying session
			session.invalidate();
			//logout successful -- sent back to login page
			response.sendRedirect("login.jsp?logout=true");
		}
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// delegating call to get method
		doGet(request, response);
	}

}
