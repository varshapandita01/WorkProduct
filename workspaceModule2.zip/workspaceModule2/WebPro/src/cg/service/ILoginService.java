package cg.service;

import cg.bean.LoginBean;

public interface ILoginService {
public boolean authenticate(LoginBean login) ;
	

}
