package cg.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import cg.bean.LoginBean;

public class LoginDao implements ILoginDao {

	@Override
	public boolean validate(LoginBean login) {
		String sql = "select * from login where username=? and password=?";

		Connection conn = null;

		try {
			conn = JdbcFactory.getConnection();
			PreparedStatement stmt = conn.prepareStatement(sql);

			stmt.setString(1, login.getUsername());
			stmt.setString(2, login.getPassword());

			ResultSet rs = stmt.executeQuery();

			return rs.next();
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		} finally {
			try {
				if (conn != null)
					conn.close();
			} catch (SQLException e) {
				e.printStackTrace();

			}
		}
	}

}
