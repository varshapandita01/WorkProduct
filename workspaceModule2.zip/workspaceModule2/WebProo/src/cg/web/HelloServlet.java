package cg.web;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebInitParam;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet(
		name = "Hello", 
		urlPatterns = { "/Hello.vp" ,"/Greet.vsp" }, 
		initParams = { 
				@WebInitParam(name = "Author", value = "Varsha Pandita")
		})
public class HelloServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//Setting MIME type for response
				response.setContentType("text/html");
				
				//Getting output stream of response to write HTML
				PrintWriter out=response.getWriter();
				
				//Writing HTML on Output stream
				out.println("<h1>HelloWorld</h1><hr>");
				out.println("<h2>Welcome to Java Servlet</h2>");
	}

}
