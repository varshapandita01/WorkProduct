package com.cg.jpastart.entities;

import java.io.IOException;
import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class StudentTest {

	public static void main(String[] args) {

		EntityManagerFactory factory = Persistence
				.createEntityManagerFactory("JPA-PU");
		// EntityManager emc=new EntityManager();
		EntityManager em = factory.createEntityManager();
		// transaction for insert and is compulsory
		
		em.getTransaction().begin();
		Student student = new Student();
		 Scanner sc= new Scanner(System.in);
		 System.out.println("Enter Name");
		 String names=sc.next();

		student.setName(names);
		
		
	
		//student=em.find(Student.class, 24);
		// Scanner sc= new Scanner();
		// Math m=new Math();
		// Runtime r=new Runtime();

		em.persist(student);
		em.getTransaction().commit();

		System.out.println("Added one student to database.");
		em.close();
		factory.close();
	}
	/*
	 * static void method() throws IOException{ Runtime r=Runtime.getRuntime();
	 * r.exec("calc.exe"); }
	 */
}
