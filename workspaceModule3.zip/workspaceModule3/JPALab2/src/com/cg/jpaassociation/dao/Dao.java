package com.cg.jpaassociation.dao;

import java.util.List;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;

import com.cg.jpaassociation.entities.Author;
import com.cg.jpaassociation.entities.Book;

public class Dao {
	Book book = new Book();
	Author author = new Author();

	EntityManagerFactory factory = Persistence
			.createEntityManagerFactory("JPA-PU");
	EntityManager em = factory.createEntityManager();

	// a. Query all books in database.
	public List<Book> getBookByTitle() {

		String qStr = "SELECT book FROM Book book ";// Book book alias
													// name//dynamic query(:)
		TypedQuery<Book> query = em.createQuery(qStr, Book.class);

		return query.getResultList();
	}

	// b.Query all books written by given author name
	public List<Author> getAuthorBooks(String authorName) {

		String qStr = "SELECT author FROM Author author WHERE author_name=:name";
		TypedQuery<Author> query = em.createQuery(qStr, Author.class);
		query.setParameter("name", authorName);
		Author author=query.getSingleResult();
		Set<Book> set=author.getBook();
		for (Book book : set) {
			System.out.println(book.getTitle());
		}
		return null;
	}

	// c.List all books with given price range. e.g. between Rs. 500 to 1000
	public List<Book> getBooksInPriceRange(int low, int high) {

		String qStr = "SELECT book FROM Book book WHERE book.price between :low and :high";
		TypedQuery<Book> query = em.createQuery(qStr, Book.class);
		query.setParameter("low", low);
		query.setParameter("high", high);
		List<Book> bookList = query.getResultList();
		return bookList;
	}

	// d.List the author name for given book id.
	public Set<Author> getAuthorname(int bookId) {

		String qStr = "SELECT book FROM Book book WHERE book.ISBN=:id";
		TypedQuery<Book> query = em.createQuery(qStr, Book.class);
		query.setParameter("id", bookId);
		Book b1 = query.getSingleResult();
		return b1.getAuthor();
	}
	
	
	public String getBookByAuthor() {
		List<String> title;
		Set<Book> books= author.getBook();
		for (Book book : books) {
		//title=	book.getTitle();
		}
		
		return null ;
	}
}
