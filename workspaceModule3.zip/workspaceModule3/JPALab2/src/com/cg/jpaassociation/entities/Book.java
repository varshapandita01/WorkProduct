package com.cg.jpaassociation.entities;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;





@Entity
@Table(name="book_table")
public class Book {
	@Id
	@Column(name="book_isbn")
	private int ISBN;
	
	@Column(name="book_title" ,length=50 )
	private String title;
	
	@Column(name="book_price",length=5)
	private int price;
	
	@ManyToMany(cascade = CascadeType.ALL)
	@JoinTable(name="author_book" ,joinColumns={@JoinColumn(name="book_id")}, 
			inverseJoinColumns = { @JoinColumn(name = "author_id") })
	private Set<Author> author=new HashSet<>(); // required to avoid
												// NullPointerException

	public int getISBN() {
		return ISBN;
	}

	public void setISBN(int iSBN) {
		ISBN = iSBN;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	public Set<Author> getAuthor() {
		return author;
	}

	public void setAuthor(Set<Author> author) {
		this.author = author;
	}
	
	public void addAuthor(Author author) {
		this.getAuthor().add(author);
	}

	@Override
	public String toString() {
		return "ISBN=" + ISBN + ", title=" + title + ", price=" + price;
				
	}
	

}
