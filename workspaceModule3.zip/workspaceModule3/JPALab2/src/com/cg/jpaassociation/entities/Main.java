package com.cg.jpaassociation.entities;

import java.util.List;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;

import com.cg.jpaassociation.dao.Dao;

public class Main {
	Dao d1 = new Dao();

	/*
	 * public Book getBookById(int id) { Book book =
	 * entityManager.find(Book.class, id); return book.getAuthor().; }
	 */

	public static void main(String[] args) {
		Dao Main = new Dao();

		// a. Query all books in database.
		List<Book> allBooks = Main.getBookByTitle();
		System.out.println("---------Books in the Database---------------");
		for (Book book : allBooks) {
			System.out.println("Books are:\n"+book);
		}

		// b.Query all books written by given author name
		
		System.out.println("----------Books by given Author name:--------");
		String author = "JK Rowling";
		System.out.println("Author Name: "+author);
		List<Author> allBooks1 = Main.getAuthorBooks(author);
		// System.out.println(allBooks1);
		// for (Author book : allBooks1) {
		// System.out.println("12"+book.getBook());
		// }

		// c.List all books with given price range. e.g. between Rs. 500 to 1000
		System.out.println("---------All books under given range----------");
		int low = 100;
		int high = 500;
		List<Book> allBooks11 = Main.getBooksInPriceRange(low, high);
		for (Book book : allBooks11) {
			System.out.println("Range of Price is between"+low+" and"+high+" is: "+book);
		}

		// d.List the author name for given book id.
		System.out.println("----------Author Name by given Book Id-----------" );
		int id = 103;
		Set<Author> author1 = Main.getAuthorname(id);
		for (Author author2 : author1) {
			System.out.println("Book ID: "+id+"Author Name: "+author2.getName());
		}

		
/* ------------END-------------------------------------------------------------------*/		
		
		/*
		 * int id=103; Set<Author> author =Main.getAuthorname(id);
		 * System.out.println(author);
		 */

		/*
		 * int low=100; int high=500; List<Book>allBooks=
		 * Main.getBooksInPriceRange( low, high); for (Book book : allBooks) {
		 * System.out.println(book); }
		 */

		/*
		 * String author="Shakespeare"; List<Author>allBooks=
		 * Main.getAuthorBooks(author); for (Author book : allBooks) {
		 * System.out.println(book); }
		 */

		/*
		 * EntityManagerFactory factory = Persistence
		 * .createEntityManagerFactory("JPA-PU"); EntityManager em =
		 * factory.createEntityManager(); EntityTransaction txn =
		 * em.getTransaction(); txn.begin();
		 * 
		 * // first define some authors Author auth = new Author();
		 * auth.setId(11); auth.setName("Chetan Bhagat");
		 * 
		 * Author auth1 = new Author(); auth1.setName("JK Rowling");
		 * auth1.setId(12);
		 * 
		 * Author auth2 = new Author(); auth2.setName("Shakespeare");
		 * auth2.setId(13);
		 * 
		 * //add authors to book and create new table using join Book book = new
		 * Book(); book.setISBN(101); book.setPrice(130);
		 * book.setTitle("3 mistakes of my life"); book.addAuthor(auth);
		 * em.persist(book);
		 * 
		 * 
		 * Book book1 = new Book(); book1.setISBN(102); book1.setPrice(330);
		 * book1.setTitle("Half Girlfriend"); book1.addAuthor(auth);
		 * em.persist(book1);
		 * 
		 * Book book2 = new Book(); book2.setISBN(103); book2.setPrice(230);
		 * book2.setTitle("Harry Potter"); book2.addAuthor(auth1);
		 * em.persist(book2);
		 * 
		 * Book book3 = new Book(); book3.setISBN(104); book3.setPrice(530);
		 * book3.setTitle(" Harry Potter and the Philosopher's Stone");
		 * book3.addAuthor(auth1); em.persist(book3);
		 * 
		 * Book book4 = new Book(); book4.setISBN(105); book4.setPrice(630);
		 * book4.setTitle("Romeo and Juliet"); book4.addAuthor(auth2);
		 * em.persist(book4);
		 * 
		 * txn.commit(); em.close(); factory.close();
		 */

	}

}
