package com.capgemini.wallet.bean;

public class Transaction {

	private double amount;
	private double balance;
	private String type;
	
	
	public Transaction(String type, double amount, double balance) {
		
		this.amount = amount;
		this.balance = balance;
		this.type = type;
	}

	public Transaction() {
	}

	public String printDetails() {
		return type+"\t"+ amount +"\t"+ balance;
	}
	
}
