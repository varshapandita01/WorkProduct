package com.capgemini.wallet.dao;

import java.sql.SQLException;
import java.util.Map;

import com.capgemini.wallet.bean.AccountUser;
import com.capgemini.wallet.exception.WalletException;

public interface IAccountUserDao {

	void storeIntoMap();

	Map<Integer, AccountUser> displayAccountUser();

	void storeIntoWalletMap();

	Map<Integer, AccountUser> displayWalletDetails();

	double showBalance(int Accno) throws WalletException, SQLException;

	void depositMoney(double amount,int accno) throws WalletException;

	void withdrawMoney(double amount,int Accno) throws WalletException;

	void fundTransfer(double amount);

	void createUser(String name, String age, String address, String email)
			throws WalletException;

	void printTransaction(int Accno) throws WalletException;

	boolean validateAccountNo(int Accno) throws WalletException;

	void insertIntoTransaction(int Accno,String type,double amount,double balance);
	
}
