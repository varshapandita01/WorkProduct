package com.capgemini.xyz.service;

import java.sql.SQLException;
import java.util.Map;

import com.capgemini.test.bean.CustomerInfo;
import com.capgemini.xyz.exception.BalanceException;
import com.capgemini.xyz.exception.RecordNotFoundException;

public interface IServiceAccount {
	String userAccountNumber = "ABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890";
	String userNamePattern = "[A-Z][a-z]{1,}";
	String userAgePattern = "[0-9]{2}";
	String userAddressPattern = "[A-Z a-z 0-9]{1,35}";
	String userEmailPattern = "[A-Za-z]{4,}[@]{1}[A-Za-z]{3,15}[.]{1}[A-Z a-z]{2,4}";
	String userMobilePattern = "[0-9]{10}";
	String userPincodePattern = "[0-9]{6}";
	String choicePattern = "[1-8]{1}";
	String ACC_NO = "[0-9]{1,7}";

	boolean validateChoice(String userChoice);

	boolean validateUserName(String userNamePattern);

	boolean validateUserAge(String userAgePattern);

	boolean validateEmail(String userEmailPattern);

	boolean validateAddress(String userAddressPattern);

	boolean validateMobile(String userMobilePattern);

	boolean validatePincode(String userPincodePattern);
	
	boolean validateAccId(String userAccId);

	// String createUserAccountNumber();
	void createAccount(CustomerInfo customer1);

	Map<Integer, CustomerInfo> displayPersons();

	// void showBalance();

	// void deposit(double amount);

	// void withdraw(double amount) throws BalanceException;

	// void fundTransfer(int custId, double amount);

	void createAccountDetails(CustomerInfo person)
			throws RecordNotFoundException, ClassNotFoundException,
			SQLException;
}
