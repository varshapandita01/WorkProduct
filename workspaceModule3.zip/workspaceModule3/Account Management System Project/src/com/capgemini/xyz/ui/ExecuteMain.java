package com.capgemini.xyz.ui;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.Scanner;

import com.capgemini.test.bean.CustomerInfo;
import com.capgemini.xyz.exception.BalanceException;
import com.capgemini.xyz.exception.RecordNotFoundException;
import com.capgemini.xyz.service.ServiceAccount;
import com.capgemini.xyz.utility.JdbcUtil;

public class ExecuteMain {
static Connection connection=null;
	public static void main(String[] args) {
		
		try {
			connection=JdbcUtil.getConnection();
		} catch (ClassNotFoundException e2) {
			// TODO Auto-generated catch block
			e2.printStackTrace();
		} catch (RecordNotFoundException e2) {
			// TODO Auto-generated catch block
			e2.printStackTrace();
		}
		
		System.out.println("XYZ Bank welcomes you");
		Scanner scan = new Scanner(System.in);
		System.out.println("1. CREATE ACCOUNT");
		System.out.println("2. EXIT");
		ServiceAccount service = new ServiceAccount();
		String Choice;
		while (true) {
			System.out
					.println("ENTER YOUR CHOICE:: 1->CREATE ACCOUNT  2->EXIT");

			Choice = scan.next();
			boolean isValid = service.validateChoice(Choice);
			if (isValid)
				break;

			else {
				System.out.println("Your have taken Wrong choice");
			}
		}
		// BufferedReader br=new BufferedReader(new
		// InputStreamReader(System.in));
		if (Choice.equalsIgnoreCase("1")) {

			String name;
			String age;
			String address;
			String email;
			String mobile;
			String pincode;
			while (true) {

				System.out.println("Create Account");
				System.out.println("Enter Customer Name");
				name = scan.next();
				boolean isValid = service.validateUserName(name);
				if (isValid)
					break;

				else
					System.out
							.println("Customer Name should have atmost 10 letters and first letter must be Capital");
			}

			while (true) {

				System.out.println(" Enter Customer Age");
				age = scan.next();

				boolean isValid = service.validateUserAge(age);
				if (isValid)
					break;
				else
					System.out.println("Age above 22  is valid");
			}

			while (true) {

				System.out.println(" Enter Customer Address");
				address = scan.next();

				boolean isValid = service.validateAddress(address);
				if (isValid)
					break;
				else
					System.out.println("Max 35 Characters");
			}

			while (true) {

				System.out.println("Enter Customer Email");
				email = scan.next();

				boolean isValid = service.validateEmail(email);
				if (isValid)
					break;
				else
					System.out
							.println("EmailID should have 1 @ and . abd letters before @must not less than  4");
			}

			while (true) {

				System.out.println("Enter Customer Mobile Number");
				mobile = scan.next();
				boolean isValid = service.validateMobile(mobile);
				if (isValid)
					break;
				else
					System.out.println("Number Should be max 10 digits");
			}

			while (true) {

				System.out.println("Enter Customer Pincode");
				pincode = scan.next();

				boolean isValid = service.validatePincode(pincode);
				if (isValid)
					break;
				else
					System.out.println("Pincode should be max 6 digit");
			}

			// System.out.println(service.createUserAccountNumber());
			CustomerInfo person = new CustomerInfo();
			person.setAge(Integer.parseInt(age));
			person.setName(name);
			person.setAddress(address);
			person.setEmail(email);
			person.setPincode(pincode);
			person.setMobile(mobile);
			person.getAccountNumber();

			//service.createAccount(person);
			
			try {
				service.createAccountDetails(person);
			} catch (ClassNotFoundException e1) {
				
				e1.printStackTrace();
			} catch (RecordNotFoundException e1) {
				
				e1.printStackTrace();
			} catch (SQLException e1) {
				
				e1.printStackTrace();
			}
			System.out.println(service.displayPersons());
			System.out.println("Done");

			while (true) {
				System.out.println("-----Choose a service------");
				System.out.println("1.Show Balance");
				System.out.println("2.Deposit");
				System.out.println("3.WithDraw");
				System.out.println("4.Fund Transfer");
				System.out.println("5.Print Transaction");
				System.out.println("6. Exit Transaction");

				System.out.println("\nEnter the Choice");

				int choice4;
				choice4 = scan.nextInt();

				switch (choice4) {
				case 1:
					System.out.println("----SHOW BALANCE-----");
					System.out.println("Your Balance is: ");
					service.showBalance();
					break;
				case 2:
					System.out.println("----Deposit Amount-----");
					System.out.println("Enter the amount you want to deposit");
					double amount = scan.nextDouble();
				//	service.deposit(amount);
					break;
				case 3:
					System.out.println("----WithDraw Amount-----");
					System.out.println("Enter the amount you want to withdraw");
					double amount1 = scan.nextDouble();
					try {
					//	service.withdraw(amount1);
						
					} catch (BalanceException e) {
						System.out.println(e);
					}
					break;
				case 4:
					System.out.println("----Fund Transfer-----");
					System.out
							.println("Enter person CustomerId you want to transfer Fund..");
					int custId = scan.nextInt();
					System.out.println("Enter the amount you want to transfer");
					double amount2 = scan.nextDouble();
//					service.fundTransfer(custId, amount2);

					break;
				case 5:
					System.out.println("---PRINT TRANSACTION----");
					service.printTransaction();
					break;
				case 6:
					System.exit(0);
					break;
				default:
					break;
				}

				// Validate accountNumber
				System.out.println("Enter Customer AccountNumber");
				int id = scan.nextInt();

				try {
					System.out.println(service.find(id));
				} catch (RecordNotFoundException e) {

					System.out.println(e);
				}
			}
		} else {
			System.out.println("Account is not created....");
		}
	}
}
