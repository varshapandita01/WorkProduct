package com.capgemini.xyz.dao;

import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;








import com.capgemini.test.bean.CustomerInfo;
import com.capgemini.test.bean.Transaction;
import com.capgemini.xyz.exception.RecordNotFoundException;
import com.capgemini.xyz.exception.BalanceException;

public class DaoAccountClass implements IDaoAccountInterface {
	CustomerInfo customers = new CustomerInfo();
	int idx;
	Transaction[] txns;
	JdbcDaoClass jdao=new JdbcDaoClass();
	double amount;

	private Map<Integer, CustomerInfo> customer = new HashMap<>();
	private Map<Integer, Double> balance = new HashMap<>();

	// create account
	@Override
	public void createAccount(CustomerInfo customers) {
		int accountNumber = (int) (Math.random() * 1000000);
		customers.setAccountNumber(accountNumber);
		//customer.put(accountNumber, customers);
		txns = new Transaction[10];

		txns[idx++] = new Transaction("CR", amount, customers.getBalance());

	}

	public Map<Integer, CustomerInfo> displayCustomerDetails() {
		return customer;
	}

	public void showBalance() {
		System.out.println(customers.getBalance());
	}

	// To deposit

	public void deposit(double amount) {
		customers.setBalance((customers.getBalance() + amount));
		//balance.put(customers.getAccountNumber(), customers.getBalance());
		txns[idx++] = new Transaction("CR", amount, customers.getBalance());
	}

	// For WithDraw
	public void withdraw(double amount) throws BalanceException {

		if (amount <= customers.getBalance()) {
			customers.setBalance(customers.getBalance() - amount);
		//	balance.put(customers.getAccountNumber(), customers.getBalance());
			txns[idx++] = new Transaction("DR", amount, customers.getBalance());
		} else
			throw new BalanceException("Insufficient Funds!!!!");
	}

	public void fundTransfer(int custId, double amount) {

		if (amount <= customers.getBalance()) {
			customers.setBalance(customers.getBalance() - amount);
			//balance.put(customers.getAccountNumber(), customers.getBalance());
			System.out
					.println("Amount Transferred Successfully.../n CustomerId : "
							+ custId + " Amount Transferred : " + amount);
			txns[idx++] = new Transaction("FT", amount, customers.getBalance());
		} else
			System.out.println("Insuficient Balance you cannot transfer....");

	}

	public void printTransaction() {
		for (int i = 0; i < idx; i++) {
			System.out.println(txns[i].print());

		}
	}

	public CustomerInfo find(int id) throws RecordNotFoundException {
		CustomerInfo c = customer.get(id);
		if (c != null) {
			return c;
		} else {
			throw new RecordNotFoundException("Record Not Found");
		}
	}

	
	
	@Override
	public double showBalance(int accId) throws RecordNotFoundException, SQLException, ClassNotFoundException {
		CustomerInfo acc = jdao.displayresult(accId);
		if (acc != null)
			return acc.getBalance();
		else
			throw new RecordNotFoundException(
					"Accound Record not found.\nFirst Open Account");
	}
	
	@Override
	public void depositBalance(int accId, double amount)
			throws ClassNotFoundException, RecordNotFoundException {
	
		customers.setBalance((customers.getBalance() + amount));
	jdao.updateBalance(accId, customers.getBalance());
	}
	
}
