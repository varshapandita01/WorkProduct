package com.capgemini.xyz.dao;

import java.sql.SQLException;

import com.capgemini.test.bean.CustomerInfo;
import com.capgemini.xyz.exception.RecordNotFoundException;

public interface JdbcDaoInterface {
	public void createAccountDetails(CustomerInfo person)
			throws RecordNotFoundException, ClassNotFoundException,
			SQLException;

	void updateBalance( int accId,double amount)
			throws ClassNotFoundException, RecordNotFoundException ;
}
