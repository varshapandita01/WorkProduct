package com.capgemini.xyz.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Map;
import java.util.logging.Logger;

import com.capgemini.test.bean.CustomerInfo;
import com.capgemini.xyz.exception.RecordNotFoundException;
import com.capgemini.xyz.utility.JdbcUtil;

public class JdbcDaoClass implements JdbcDaoInterface {
	Connection connection = null;
	PreparedStatement statement = null;

	/**
	 * method name : insertCustomerDetail argument : CabRequest class object
	 * return type : int author : Capgemini date : 19-02-2019
	 * 
	 * description : This method will take the CabRequest Class(in bean package)
	 * object as an argument and returns the generated id to the user
	 * 
	 * @throws ClassNotFoundException
	 */
	@Override
	public void createAccountDetails(CustomerInfo person)
			throws RecordNotFoundException, ClassNotFoundException,
			SQLException {

		connection = JdbcUtil.getConnection();

		try {
			statement = connection.prepareStatement(QueryMapper.insertDetails);

			int key = (int) (Math.random() * 1000);
			person.setAccountNumber(key);
			person.setBalance(1000);
			statement.setInt(1, person.getAccountNumber());
			statement.setString(2, person.getName());
			statement.setInt(3, person.getAge());
			statement.setString(4, person.getAddress());
			statement.setString(5, person.getEmail());
			statement.setString(6, person.getPincode());
			statement.setString(7, person.getMobile());
			statement.setDouble(8, person.getBalance());
			statement.executeUpdate();

		} catch (SQLException e) {
			System.err.println("Unable to fetch data" + e);

		}

	}

	@Override
	public void updateBalance(int accId, double balance)
			throws ClassNotFoundException, RecordNotFoundException {
		CustomerInfo person1 = new CustomerInfo();
		
		
		connection = JdbcUtil.getConnection();

		try {
			statement = connection.prepareStatement(QueryMapper.updateDetails);
			
			statement.setInt(1, accId);
			statement.setDouble(2, balance);

			statement.executeUpdate();

		} catch (SQLException e) {
			System.err.println("Unable to fetch data" + e);

		}

	}

	public CustomerInfo displayresult(int custID) throws SQLException,
			RecordNotFoundException, ClassNotFoundException {
		CustomerInfo Cust = new CustomerInfo();
		connection = JdbcUtil.getConnection();
		try {
			statement = connection.prepareStatement(QueryMapper.selectbalance);
			statement.setInt(1, custID);
			ResultSet resultSet = statement.executeQuery();
			while (resultSet.next()) {
				// takes the record pointer to the first row
				// and then on next row
				Cust.setAccountNumber(resultSet.getInt(1));
				Cust.setName(resultSet.getString(2));
				Cust.setAge(resultSet.getInt(3));
				Cust.setAddress(resultSet.getString(4));
				Cust.setEmail(resultSet.getString(5));
				Cust.setPincode(resultSet.getString(6));
				Cust.setMobile(resultSet.getString(7));
				Cust.setBalance(resultSet.getInt(8));

			}
		}

		catch (SQLException e) {
			System.err.println("Unable to fetch data" + e);

		} finally {

			try {
				statement.close();
			} catch (SQLException e) {

				throw new RecordNotFoundException(
						"unable to close statement object");
			}

			try {
				connection.close();
			} catch (SQLException e) {

				throw new RecordNotFoundException(
						"unable to close connection object");
			}
		}

		return Cust;

	}

}
