package com.cg.jpaassociation.entities;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class Main {

	public static void main(String[] args) {
		EntityManagerFactory factory = Persistence
				.createEntityManagerFactory("JPA-PU");
		EntityManager em = factory.createEntityManager();
		EntityTransaction txn = em.getTransaction();
		txn.begin();

		// first define some authors
		Author auth = new Author();
		auth.setId(11);
		auth.setName("Chetan Bhagat");

		Author auth1 = new Author();
		auth1.setName("JK Rowling");
		auth1.setId(12);

		Author auth2 = new Author();
		auth2.setName("Shakespeare");
		auth2.setId(13);

		//add authors to book and create new table using join
		Book book = new Book();
		book.setISBN(101);
		book.setPrice(130);
		book.setTitle("3 mistakes of my life");
		book.addAuthor(auth);
		em.persist(book);
		
		
		Book book1 = new Book();
		book1.setISBN(102);
		book1.setPrice(330);
		book1.setTitle("Half Girlfriend");
		book1.addAuthor(auth);
		em.persist(book1);
		
		Book book2 = new Book();
		book2.setISBN(103);
		book2.setPrice(230);
		book2.setTitle("Harry Potter");
		book2.addAuthor(auth1);
		em.persist(book2);
		
		Book book3 = new Book();
		book3.setISBN(104);
		book3.setPrice(530);
		book3.setTitle(" Harry Potter and the Philosopher's Stone");
		book3.addAuthor(auth1);
		em.persist(book3);
		
		Book book4 = new Book();
		book4.setISBN(105);
		book4.setPrice(630);
		book4.setTitle("Romeo and Juliet");
		book4.addAuthor(auth2);
		em.persist(book4);
		
		txn.commit();
		em.close();
		factory.close();
		
		
	}

}
