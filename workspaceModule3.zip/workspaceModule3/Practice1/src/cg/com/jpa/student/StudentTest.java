package cg.com.jpa.student;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class StudentTest {

	public static void main(String[] args) {
		EntityManagerFactory factory = Persistence
				.createEntityManagerFactory("JPA-PU");
		EntityManager em = factory.createEntityManager();
		em.getTransaction().begin();
		Student student = new Student();
		student.setName("John");
		em.persist(student);
		em.getTransaction().commit();
		System.out.println("DataAdded Successfully");
		em.close();
		factory.close();

	}

}
