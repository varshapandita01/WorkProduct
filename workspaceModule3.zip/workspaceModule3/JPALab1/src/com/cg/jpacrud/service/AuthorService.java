package com.cg.jpacrud.service;

import com.cg.jpacrud.entities.Author;
import com.cg.jpacrud.exception.IdNotFoundException;



public interface AuthorService {

	public abstract void addAuthor(Author author);

	public abstract void updateAuthor(Author author);

	public abstract void removeAuthor(Author author);

	public abstract boolean findAuthorById(int id) throws IdNotFoundException;



}