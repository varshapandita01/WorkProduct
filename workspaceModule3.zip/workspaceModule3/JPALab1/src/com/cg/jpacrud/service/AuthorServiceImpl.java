package com.cg.jpacrud.service;

import com.cg.jpacrud.dao.AuthorDao;
import com.cg.jpacrud.dao.AuthorDaoImpl;
import com.cg.jpacrud.entities.Author;
import com.cg.jpacrud.exception.IdNotFoundException;




public class AuthorServiceImpl implements AuthorService {

	private AuthorDao dao;

	public AuthorServiceImpl() {
		dao = new AuthorDaoImpl();
	}

	@Override
	public void addAuthor(Author author) {
		try {
			dao.beginTransaction();
			dao.addAuthor(author);
			dao.commitTransaction();
		} catch (Exception e) {
			dao.rollBackTransaction();
		}
	}
	
	@Override
	public void updateAuthor(Author author) {
		dao.beginTransaction();
		dao.updateAuthor(author);
		dao.commitTransaction();
	}
	
	@Override
	public void removeAuthor(Author author) {
		dao.beginTransaction();
		dao.removeAuthor(author);
		dao.commitTransaction();
	}
	
	@Override
	public boolean findAuthorById(int id) throws IdNotFoundException {
		//no need of transaction, as it's an read operation
		boolean author  = dao.getAuthorById(id);
		return author;
	}
	
	
}
