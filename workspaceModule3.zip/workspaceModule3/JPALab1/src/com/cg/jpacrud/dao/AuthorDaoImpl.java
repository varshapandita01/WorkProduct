package com.cg.jpacrud.dao;

import javax.persistence.EntityManager;

import com.cg.jpacrud.entities.Author;
import com.cg.jpacrud.exception.IdNotFoundException;

public class AuthorDaoImpl implements AuthorDao {

	private EntityManager entityManager;

	/**
	 * Contructor for EntityManager
	 */
	public AuthorDaoImpl() {
		entityManager = JPAUtil.getEntityManager();
	}

	/**
	 * Fetch data by id
	 */
	@Override
	public boolean getAuthorById(int id) throws IdNotFoundException {
		Author author = entityManager.find(Author.class, id);
		if(author!= null){
			return true;
		}
		else{
			return false;
			//throw new  IdNotFoundException("Id not Found");
			
		}
		//return author;
	}

	/**
	 * Insert data by persist
	 */
	@Override
	public void addAuthor(Author author) {
		entityManager.persist(author);
	}
	/**
	 * Delete Data by remove
	 */
	@Override
	public void removeAuthor(Author author) {
		entityManager.remove(author);
	}

	/**
	 * update data by merge
	 */
	@Override
	public void updateAuthor(Author author) {
		entityManager.merge(author);
	}
	/**
	 * Begin Transaction
	 */
	@Override
	public void beginTransaction() {
		entityManager.getTransaction().begin();
	}
	/**
	 * Commit Transaction
	 */

	@Override
	public void commitTransaction() {
		entityManager.getTransaction().commit();
	}

	@Override
	public void rollBackTransaction() {
		entityManager.getTransaction().rollback();
	}

}
