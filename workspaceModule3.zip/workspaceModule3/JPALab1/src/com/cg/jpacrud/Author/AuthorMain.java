package com.cg.jpacrud.Author;

import java.util.Scanner;

import com.cg.jpacrud.entities.Author;
import com.cg.jpacrud.exception.IdNotFoundException;
import com.cg.jpacrud.service.AuthorService;
import com.cg.jpacrud.service.AuthorServiceImpl;

public class AuthorMain {

	public static void main(String[] args) {
		// Debug this program as Debug -> Debug as Java Application

		AuthorService service = new AuthorServiceImpl();
		Scanner scan = new Scanner(System.in);
		Author author = new Author();
		// User Defined Data
		int choice;
		int id;
		while (true) {
			while (true) {
				System.out
						.println("DO YOU WANT TO PERFORM WHICH OPERATION: \n 1."
								+ "Add Author Data \n 2.Find Data by Id and Update Author Data"
								+ " Data \n 3.Delete Author Data "
								+ "\n 4.Exit");
				choice = scan.nextInt();
				break;
			}

			if (choice == 1) {
				System.out.println("Enter First Name");
				String fname = scan.next();

				System.out.println("Enter Middle Name");
				String mname = scan.next();

				System.out.println("Enter Last Name");
				String lname = scan.next();

				System.out.println("Enter Phone Number");
				String pnumber = scan.next();

				/**
				 * Set parameters of author
				 */
				author.setFirstName(fname);
				author.setMiddleName(mname);
				author.setLastName(lname);
				author.setNumber(pnumber);

				/**
				 * Add Details
				 */
				service.addAuthor(author);
				System.out.println("Author Id is:" + author.getAuthorId());
				System.out.println(" Full Name:" + author.getFirstName() + " "
						+ author.getMiddleName() + " " + author.getLastName());

			}

			if (choice == 2) {
				System.out.println("Enter Id");
				id = scan.nextInt();
				// at this breakpoint, we have added one record to table
				try {
					service.findAuthorById(id);
				//	System.out.println(author);
					System.out.print("ID:" + author.getAuthorId());
					System.out.println(" Full Name:" + author.getFirstName() + " "
							+ author.getMiddleName() + " " + author.getLastName());
				} catch (IdNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				

				/**
				 * Updated Records
				 */
				System.out.println("Do You Want to Update \n 1.Update 2.No");
				int choice1 = scan.nextInt();
				if (choice1 == 1) {
					System.out.println("Enter Updated Phone Number");
					String unumber = scan.next();
					author.setNumber(unumber);
					service.updateAuthor(author);
				} else {
					System.out.println("Not Updated");
				}

			}

			/**
			 * Delete Data
			 */
			if (choice == 3) {
				System.out.println("Enter Id");
				id = scan.nextInt();
				// at this breakpoint, we have updated record added in first
				// section
				try {
					 service.findAuthorById(id);
					System.out.print("ID:" + author.getAuthorId());
					System.out.println(" Full Name:" + author.getFirstName() + " "
							+ author.getMiddleName() + " " + author.getLastName());
					// at this breakpoint, record is removed from table
					service.removeAuthor(author);
					System.out.println("End of program...");
				} catch (IdNotFoundException e) {
					System.out.println(e);
				}

			}
			if (choice == 4) {
				System.exit(0);
			}
		}
	}
}
