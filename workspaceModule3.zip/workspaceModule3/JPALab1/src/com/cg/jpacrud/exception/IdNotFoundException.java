package com.cg.jpacrud.exception;

public class IdNotFoundException extends Exception {

	public IdNotFoundException(String msg) {
		super(msg);
	
	}

}
